<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use App\Models\RlUser;
use App\Models\TwoFactorAuth;
use App\Models\UserLoginLog;

class LoginController extends Controller
{
    /**
     * Show login page
     */
    public function showLoginForm()
    {
        return view('login')
            ->with('success', session('success'))
            ->with('error', session('error'))
            ->with('info', session('info'));
    }

    /**
     * Handle login submission
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|max:191',
            'password' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->with('error', 'Invalid credentials format.')
                ->withInput();
        }

        $emailOrPhone = $request->input('email');
        $password = $request->input('password');

        $user = RlUser::where('email', $emailOrPhone)
            ->orWhere('phone', $emailOrPhone)
            ->first();

        if (!$user) {
            return back()->with('error', 'Invalid credentials.')->withInput();
        }

        if (!$user->isActive()) {
            return back()->with('error', 'Your account is inactive. Contact administrator.');
        }

        if (!Hash::check($password, $user->password)) {
            $user->increment('failed_attempts');
            return back()->with('error', 'Incorrect password.')->withInput();
        }

        $user->update(['failed_attempts' => 0]);

        // ✅ If user has 2FA enabled
        if ($user->hasTwoFactorEnabled()) {
            $otp = random_int(100000, 999999);

            TwoFactorAuth::where('user_id', $user->id)->delete();

            $twoFA = TwoFactorAuth::create([
                'user_id' => $user->id,
                'otp' => $otp,
                'expires_at' => now()->addMinutes(5),
                'is_used' => false,
            ]);

            Session::put('2fa:user_id', $user->id);
            Session::put('2fa:otp', $otp);
            Session::put('2fa:phone', $user->phone);
            Session::put('2fa:expires_at', $twoFA->expires_at);

            return redirect()->route('verify.otp.form')
                ->with('info', 'OTP sent to your registered number.')
                ->with('success', 'Please verify your OTP to continue.');
        }

        // ✅ Direct login (no 2FA)
        return $this->manualLogin($user, $request);
    }

    /**
     * Show OTP verification form
     */
    public function showOtpForm()
    {
        if (!Session::has('2fa:user_id')) {
            return redirect()->route('login')->with('error', 'Your session expired. Please login again.');
        }

        $otp = Session::get('2fa:otp');
        $expires = Session::get('2fa:expires_at');
        $phone = Session::get('2fa:phone');

        return view('verify_otp', compact('otp', 'expires', 'phone'))
            ->with('info', session('info'))
            ->with('error', session('error'))
            ->with('success', session('success'));
    }

    /**
     * Verify OTP
     */
    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required|digits:6',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->with('error', 'Please enter a valid 6-digit OTP.');
        }

        if (!Session::has('2fa:user_id')) {
            return redirect()->route('login')->with('error', 'Your session expired. Please login again.');
        }

        $userId = Session::get('2fa:user_id');
        $otp = $request->input('otp');

        $user = RlUser::find($userId);
        if (!$user) {
            return redirect()->route('login')->with('error', 'User not found.');
        }

        $twoFA = TwoFactorAuth::where('user_id', $userId)
            ->where('otp', $otp)
            ->where('is_used', false)
            ->where('expires_at', '>', now())
            ->first();

        if (!$twoFA) {
            return back()->with('error', 'Invalid or expired OTP.');
        }

        // ✅ Mark OTP as used
        $twoFA->update(['is_used' => true]);

        // ✅ Flush temporary OTP session data
        Session::forget(['2fa:user_id', '2fa:otp', '2fa:expires_at', '2fa:phone']);

        // ✅ Proceed with manual secure login
        return $this->manualLogin($user, $request);
    }

    /**
     * Resend OTP (Regenerate and show dynamically)
     */
    public function resendOtp(Request $request)
    {
        if (!Session::has('2fa:user_id')) {
            return redirect()->route('login')->with('error', 'Your session expired. Please login again.');
        }

        $userId = Session::get('2fa:user_id');
        $user = RlUser::find($userId);

        if (!$user) {
            return redirect()->route('login')->with('error', 'User not found.');
        }

        // Generate new OTP
        $otp = random_int(100000, 999999);

        // Delete old OTPs
        TwoFactorAuth::where('user_id', $userId)->delete();

        // Create new OTP
        $twoFA = TwoFactorAuth::create([
            'user_id' => $userId,
            'otp' => $otp,
            'expires_at' => now()->addMinutes(5),
            'is_used' => false,
        ]);

        // Update session
        Session::put('2fa:otp', $otp);
        Session::put('2fa:expires_at', $twoFA->expires_at);

        return redirect()->route('verify.otp.form')
            ->with('success', 'A new OTP has been generated. Please verify to continue.');
    }

    /**
     * Manual login system (no Laravel Auth)
     */
    protected function manualLogin(RlUser $user, Request $request)
    {
        $ip = $request->header('CF-Connecting-IP')
            ?? $request->header('X-Forwarded-For')
            ?? $request->ip();

        Session::put('user', [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->role,
            'ip' => $ip,
            'agent' => $request->userAgent(),
            'logged_in_at' => now(),
        ]);

        $user->update([
            'last_login_at' => now(),
            'last_login_ip' => $ip,
            'last_login_user_agent' => $request->userAgent(),
        ]);

        UserLoginLog::create([
            'user_id' => $user->id,
            'ip_address' => $ip,
            'user_agent' => $request->userAgent(),
            'logged_in_at' => now(),
        ]);

        // 🚀 Check if first login and 2FA disabled
        if (!$user->is_two_factor_enabled && $user->last_login_status != 2) {
            return redirect()->route('setup.2fa')
                ->with('info', 'Would you like to enable Two-Factor Authentication for better security?');
        }

        return redirect()->route('dashboard')->with('success', 'Welcome back, ' . $user->name . '!');
    }

    /**
     * Show 2facAuth Pop Up After login
     */
    public function showTwoFactorSetup()
    {
        if (!Session::has('user')) {
            return redirect()->route('login')->with('error', 'Unauthorized access.');
        }

        return view('super_admin.setup_2fa');
    }

    /**
     * Upadte 2facAuth Pop Up After login
     */
    public function handleTwoFactorSetup(Request $request)
    {
        if (!Session::has('user')) {
            return redirect()->route('login')->with('error', 'Session expired.');
        }

        $user = RlUser::find(Session::get('user.id'));
        if (!$user) {
            return redirect()->route('login')->with('error', 'User not found.');
        }

        $choice = $request->input('choice');
        $message = '';

        if ($choice === 'enable') {
            $user->update([
                'is_two_factor_enabled' => 1,
                'last_login_status' => 0,
            ]);
            Session::put('user.is_two_factor_enabled', 1);
            $message = '✅ Two-Factor Authentication enabled successfully.';
        } elseif ($choice === 'skip') {
            $user->update(['last_login_status' => 0]);
            $message = '⚠ You skipped 2FA setup. You can enable it anytime in security settings.';
        } elseif ($choice === 'never') {
            $user->update(['last_login_status' => 2]);
            $message = '🚫 You chose not to enable 2FA and not to be asked again.';
        }

        return redirect()->route('dashboard')->with('info', $message);
    }

    /**
     * Toggle Two Factor Authentication (Enable/Disable)
     */
    public function toggleTwoFactor(Request $request)
    {
        if (!Session::has('user')) {
            return redirect()->route('login')->with('error', 'Unauthorized access.');
        }

        $userData = Session::get('user');
        $user = RlUser::find($userData['id']);

        if (!$user) {
            return back()->with('error', 'User not found.');
        }

        $status = $user->is_two_factor_enabled ? 0 : 1;

        $user->update([
            'is_two_factor_enabled' => $status,
            'updated_at' => now(),
        ]);

        Session::put('user.is_two_factor_enabled', $status);

        $message = $status
            ? 'Two-factor authentication has been enabled successfully.'
            : 'Two-factor authentication has been disabled.';

        return back()->with('success', $message);
    }

    /**
     * Store user location securely after login
     */
    /**
     * Store user location securely after login
     */
    public function updateLocation(Request $request)
    {
        if (!Session::has('user')) {
            return response()->json(['status' => false, 'message' => 'Unauthorized access.'], 401);
        }

        $validated = $request->validate([
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
        ]);

        $user = RlUser::find(Session::get('user.id'));

        if (!$user) {
            return response()->json(['status' => false, 'message' => 'User not found.'], 404);
        }

        // ✅ Get IP safely
        $ip = $request->header('CF-Connecting-IP')
            ?? $request->header('X-Forwarded-For')
            ?? $request->ip();

        // ✅ Update in user profile
        $user->update([
            'latitude' => $validated['latitude'],
            'longitude' => $validated['longitude'],
            'last_login_ip' => $ip,
            'last_login_at' => now(),
        ]);

        // ✅ Also store in user_login_logs for full audit
        UserLoginLog::create([
            'user_id' => $user->id,
            'ip_address' => $ip,
            'user_agent' => $request->userAgent(),
            'latitude' => $validated['latitude'],
            'longitude' => $validated['longitude'],
            'logged_in_at' => now(),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Location stored successfully in user logs.',
        ]);
    }



    /**
     * Logout
     */
    public function logout(Request $request)
    {
        Session::forget('user');
        Session::flush();

        return redirect()->route('login')->with('info', 'You have been logged out successfully.');
    }

    /**
     * Show Change Password Form
     */
    public function showChangePasswordForm()
    {
        if (!Session::has('user')) {
            return redirect()->route('login')->with('error', 'Unauthorized access.');
        }

        return view('super_admin.change_password');
    }

    /**
     * Handle Password Change
     */
    public function changePassword(Request $request)
    {
        if (!Session::has('user')) {
            return redirect()->route('login')->with('error', 'Unauthorized access.');
        }

        $userData = Session::get('user');
        $user = RlUser::find($userData['id']);

        if (!$user) {
            return back()->with('error', 'User not found.');
        }

        // Validate inputs
        $validator = Validator::make($request->all(), [
            'old_password' => 'required|string|min:6|max:191',
            'new_password' => [
                'required',
                'string',
                'min:6',
                'max:191'
            ],
            'confirm_password' => 'required|same:new_password',
        ], [
            'old_password.required' => 'Please enter your current password.',
            'new_password.required' => 'Please enter a new password.',
            'new_password.regex' => 'Password must contain uppercase, lowercase, number, and special character.',
            'confirm_password.same' => 'New password and confirmation do not match.',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput()
                ->with('error', 'Please correct the highlighted errors.');
        }

        // Check old password
        if (!Hash::check($request->old_password, $user->password)) {
            return back()->with('error', 'Your current password is incorrect.');
        }

        // Prevent reusing old password
        if (Hash::check($request->new_password, $user->password)) {
            return back()->with('error', 'New password cannot be the same as the old one.');
        }

        // Update password
        $user->update([
            'password' => Hash::make($request->new_password),
            'updated_at' => now(),
        ]);

        // Optionally clear session
        Session::forget('user');
        Session::flush();

        return redirect()->route('login')->with('success', 'Password changed successfully. Please log in again.');
    }

}

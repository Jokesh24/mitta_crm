<?php

namespace App\Http\Controllers\super_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;

class PayslipController extends Controller
{
    /**
     * Display the Manage Company page
     */
    public function payslip()
    {
        return view('super_admin.payslip');
    }

    /**
     * Display the Add Company page
     */
    public function payroll()
    {
        return view('super_admin.payroll');
    }

    /**
     * Display the Add Company page
     */
    // public function details()
    // {
    //     return view('super_admin.leads_details');
    // }


}

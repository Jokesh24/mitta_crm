<?php

namespace App\Http\Controllers\super_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use App\Models\Company;
use Carbon\Carbon;

class CompanyController extends Controller
{
    /**
     * Display the Add Company page
     */
    public function index()
    {
        return view('super_admin.add_company');
    }

    /**
     * Store new company securely
     */
    public function store(Request $request)
    {
        // ✅ Validate input
        $validator = Validator::make($request->all(), [
            'company_name' => 'required|string|max:191',
            'company_email' => 'required|email|max:191',
            'mobile_number' => 'nullable|digits_between:8,15',
            'gst_number' => 'nullable|string|max:30',
            'company_logo' => 'nullable|mimes:jpg,jpeg,png,svg|max:2048',
            'status' => 'required|in:active,inactive',
            'address' => 'nullable|string|max:500',
            'account_holder_name' => 'nullable|string|max:191',
            'bank_name' => 'nullable|string|max:191',
            'branch_name' => 'nullable|string|max:191',
            'account_number' => 'nullable|string|max:50',
            'ifsc_code' => 'nullable|string|max:50',
            'account_type' => 'nullable|in:saving,current',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->with('error', 'Please fix the highlighted errors.')
                ->withInput();
        }

        // ✅ Handle file upload safely
        $logoPath = null;
        if ($request->hasFile('company_logo')) {
            $file = $request->file('company_logo');

            // Define secure destination path
            $destinationPath = public_path('uploads/company_logo');

            // Create folder if it doesn’t exist
            if (!\File::exists($destinationPath)) {
                \File::makeDirectory($destinationPath, 0755, true, true);
            }

            // Generate a unique filename (safe)
            $filename = 'company_' . time() . '.' . $file->getClientOriginalExtension();

            // Move file securely
            $file->move($destinationPath, $filename);

            // Store relative path (not full server path)
            $logoPath = 'uploads/company_logo/' . $filename;
        }

        // ✅ Current logged-in user (from session)
        $user = Session::get('user');
        $createdBy = $user['id'] ?? null;
        $createdByName = $user['name'] ?? 'System';

        // ✅ Insert company record
        $companyId = DB::table('companies')->insertGetId([
            'company_name' => $request->company_name,
            'company_email' => $request->company_email,
            'mobile_number' => $request->mobile_number,
            'gst_number' => $request->gst_number,
            'company_logo' => $logoPath,
            'status' => $request->status,
            'address' => $request->address,
            'account_holder_name' => $request->account_holder_name,
            'bank_name' => $request->bank_name,
            'branch_name' => $request->branch_name,
            'account_number' => $request->account_number,
            'ifsc_code' => $request->ifsc_code,
            'account_type' => $request->account_type,
            'created_by' => $createdBy,
            'created_at' => now(),
        ]);

        // ✅ Log the creation event in rl_logs_tbl
        DB::table('rl_logs_tbl')->insert([
            'log_message' => "🆕 New Company <strong>{$request->company_name}</strong> created by <strong>{$createdByName}</strong>.",
            'created_at' => now(),
        ]);

        \Log::info("Company created: {$request->company_name} by {$createdByName}");

        return redirect()->route('add-company')->with('success', 'Company added successfully!');
    }

    /**
     * Show manage companies list.
     */
    public function manage(Request $request)
    {
        // Ensure no cached query results
        DB::flushQueryLog();

        // Base query (non-trashed)
        $query = DB::table('companies')->where('trash', 0);

        // Search
        if ($request->filled('search')) {
            $search = trim($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('company_name', 'like', "%{$search}%")
                    ->orWhere('company_email', 'like', "%{$search}%")
                    ->orWhere('mobile_number', 'like', "%{$search}%")
                    ->orWhere('gst_number', 'like', "%{$search}%");
            });
        }

        // Status
        if ($request->filled('status') && in_array($request->status, ['active', 'inactive'])) {
            $query->where('status', $request->status);
        }

        // Fetch data freshly
        $companies = $query->orderBy('id', 'desc')->get();

        // ✅ Compute fresh counts directly using raw queries (faster + reliable)
        $totalCompanies = DB::table('companies')->where('trash', 0)->count();
        $activeCount = DB::table('companies')->where('status', 'active')->where('trash', 0)->count();
        $inactiveCount = DB::table('companies')->where('status', 'inactive')->where('trash', 0)->count();
        $trashedCount = DB::table('companies')->where('trash', 1)->count();

        return view('super_admin.manage_company', compact(
            'companies',
            'totalCompanies',
            'activeCount',
            'inactiveCount',
            'trashedCount'
        ));
    }



    /**
     * Edit company form
     */
    public function edit($id)
    {
        $company = Company::findOrFail($id);
        return view('super_admin.edit_company', compact('company'));
    }

    /**
     * Update company details
     */
    public function update(Request $request, $id)
    {
        $company = Company::findOrFail($id);

        // ✅ Validation
        $validator = Validator::make($request->all(), [
            'company_name' => 'required|string|max:191',
            'company_email' => 'required|email|max:191',
            'mobile_number' => 'nullable|digits_between:8,15',
            'gst_number' => 'nullable|string|max:30',
            'company_logo' => 'nullable|mimes:jpg,jpeg,png,svg|max:2048',
            'status' => 'required|in:active,inactive',
            'address' => 'nullable|string|max:500',
            'account_holder_name' => 'nullable|string|max:191',
            'bank_name' => 'nullable|string|max:191',
            'branch_name' => 'nullable|string|max:191',
            'account_number' => 'nullable|string|max:50',
            'ifsc_code' => 'nullable|string|max:50',
            'account_type' => 'nullable|in:saving,current',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->with('error', 'Please fix the highlighted errors.')->withInput();
        }

        // ✅ Handle file upload (only if new image uploaded)
        $logoPath = $company->company_logo;
        if ($request->hasFile('company_logo')) {
            $file = $request->file('company_logo');
            $filename = 'company_' . time() . '.' . $file->getClientOriginalExtension();
            $path = public_path('uploads/company_logo');

            if (!File::exists($path)) {
                File::makeDirectory($path, 0755, true);
            }

            $file->move($path, $filename);
            $logoPath = 'uploads/company_logo/' . $filename;

            // Delete old logo if exists
            if ($company->company_logo && File::exists(public_path($company->company_logo))) {
                File::delete(public_path($company->company_logo));
            }
        }

        // ✅ Get current user
        $user = Session::get('user');
        $updatedBy = $user['id'] ?? null;
        $updatedByName = $user['name'] ?? 'System';

        // ✅ Update data
        $company->update([
            'company_name' => $request->company_name,
            'company_email' => $request->company_email,
            'mobile_number' => $request->mobile_number,
            'gst_number' => $request->gst_number,
            'company_logo' => $logoPath,
            'status' => $request->status,
            'address' => $request->address,
            'account_holder_name' => $request->account_holder_name,
            'bank_name' => $request->bank_name,
            'branch_name' => $request->branch_name,
            'account_number' => $request->account_number,
            'ifsc_code' => $request->ifsc_code,
            'account_type' => $request->account_type,
            'updated_by' => $updatedBy,
            'updated_at' => now(),
        ]);

        // ✅ Log action
        $logMessage = "✏️ Company <strong>{$request->company_name}</strong> updated by <strong>{$updatedByName}</strong>.";
        DB::table('rl_logs_tbl')->insert([
            'log_message' => $logMessage,
            'created_at' => now(),
        ]);

        Log::info("Company updated: {$request->company_name} by {$updatedByName}");

        return redirect()->route('manage-company')->with('success', 'Company details updated successfully!');
    }

    /**
     * Soft delete company (move to trash)
     */
    public function delete($id)
    {
        $company = Company::find($id);

        if (!$company) {
            return redirect()->route('manage-company')->with('error', 'Company not found.');
        }

        if ($company->trash == 1) {
            return redirect()->route('manage-company')->with('info', 'This company is already in trash.');
        }

        // ✅ Get logged-in user
        $user = Session::get('user');
        $deletedById = $user['id'] ?? null;
        $deletedByName = $user['name'] ?? 'System';
        $deletedByRole = $user['role'] ?? 'Unknown';

        // ✅ Update company (soft delete)
        $company->update([
            'trash' => 1,
            'deleted_by' => $deletedById,
            'deleted_by_role' => $deletedByRole,
            'deleted_at' => now(),
        ]);

        // ✅ Log the delete action
        $logMessage = "🗑️ Company <strong>{$company->company_name}</strong> moved to trash by <strong>{$deletedByName}</strong>.";
        DB::table('rl_logs_tbl')->insert([
            'log_message' => $logMessage,
            'created_at' => now(),
        ]);

        Log::warning("Company moved to trash: {$company->company_name} by {$deletedByName}");



        return redirect()->route('manage-company')->with('success', 'Company moved to trash successfully!');
    }

    /**
     * View specific company details
     */
    public function view($id)
    {
        $company = Company::find($id);

        if (!$company) {
            return redirect()->route('manage-company')->with('error', 'Company not found.');
        }

        // ✅ Log the view action
        $user = Session::get('user');
        $viewedByName = $user['name'] ?? 'System';

        DB::table('rl_logs_tbl')->insert([
            'log_message' => "👁️ Company <strong>{$company->company_name}</strong> details viewed by <strong>{$viewedByName}</strong>.",
            'created_at' => now(),
        ]);

        Log::info("Company viewed: {$company->company_name} by {$viewedByName}");

        return view('super_admin.view', compact('company'));
    }




}

<?php

namespace App\Http\Controllers\super_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use App\Models\Vendor;
use Carbon\Carbon;

class VendorController extends Controller
{
    /**
     * Display Manage Vendors page
     */
    public function index(Request $request)
    {
        // Always query from model — prevents cache/stale data issues
        $query = Vendor::query()->where('trash', 0);

        // ✅ Apply optional filters (if used in future for server-side filtering)
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('vendor_type')) {
            $query->where('vendor_type', $request->vendor_type);
        }

        // ✅ Fetch vendors (sorted latest first)
        // $vendors = $query->orderByDesc('id')->get();

        // ✅ Compute accurate counts directly from DB (no caching)
        $vendors = Vendor::where('trash', 0)->orderBy('id', 'desc')->get();
        $totalVendors = Vendor::where('trash', 0)->count();
        $activeCount = Vendor::where('status', 'active')->where('trash', 0)->count();
        $inactiveCount = Vendor::where('status', 'inactive')->where('trash', 0)->count();
        $trashedCount = Vendor::where('trash', 1)->count();

        return view('super_admin.manage_vendors', compact('vendors', 'totalVendors', 'activeCount', 'inactiveCount', 'trashedCount'));

    }


    /**
     * Show Add Vendor page
     */
    public function add()
    {
        return view('super_admin.add_vendor');
    }

    /**
     * Store Vendor
     */
    public function store(Request $request)
    {
        // ✅ Validate fields
        $validator = Validator::make($request->all(), [
            'business_name' => 'required|string|max:191',
            'email' => 'required|email|max:191',
            'mobile_number' => 'required|digits_between:8,15',
            'gst_number' => 'nullable|string|max:30',
            'pan_number' => 'nullable|string|max:20',
            'vendor_type' => 'required|in:Inward,Outward',
            'address' => 'required|string|max:500',
            'status' => 'required|in:active,inactive',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $user = Session::get('user');
        $createdBy = $user['id'] ?? null;
        $createdByName = $user['name'] ?? 'System';

        // ✅ Insert vendor record
        $vendor = Vendor::create([
            'business_name' => $request->business_name,
            'email' => $request->email,
            'mobile_number' => $request->mobile_number,
            'gst_number' => $request->gst_number,
            'pan_number' => $request->pan_number,
            'vendor_type' => $request->vendor_type,
            'address' => $request->address,
            'status' => $request->status,
            'created_by' => $createdBy,
        ]);

        // ✅ Log the event
        DB::table('rl_logs_tbl')->insert([
            'log_message' => "🆕 New Vendor <strong>{$vendor->business_name}</strong> added by <strong>{$createdByName}</strong>.",
            'created_at' => now(),
        ]);

        Log::info("Vendor created: {$vendor->business_name} by {$createdByName}");

        return redirect()->route('add-vendor')->with('success', 'Vendor added successfully!');
    }

    /**
     * Show edit vendor form
     */
    public function edit($id)
    {
        $vendor = Vendor::findOrFail($id);
        return view('super_admin.edit_vendor', compact('vendor'));
    }

    /**
     * Update vendor data
     */
    public function update(Request $request, $id)
    {
        $vendor = Vendor::findOrFail($id);

        // ✅ Validation
        $validator = Validator::make($request->all(), [
            'business_name' => 'required|string|max:191',
            'email' => 'required|email|max:191',
            'mobile_number' => 'required|digits_between:8,15',
            'gst_number' => 'nullable|string|max:30',
            'pan_number' => 'nullable|string|max:30',
            'vendor_type' => 'required|in:Inward,Outward',
            'address' => 'required|string|max:500',
            'status' => 'required|in:active,inactive',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)
                ->withInput()
                ->with('error', 'Please fix the highlighted errors.');
        }

        // ✅ Logged-in user
        $user = Session::get('user');
        $updatedBy = $user['id'] ?? null;
        $updatedByName = $user['name'] ?? 'System';

        // ✅ Update vendor
        $vendor->update([
            'business_name' => $request->business_name,
            'email' => $request->email,
            'mobile_number' => $request->mobile_number,
            'gst_number' => $request->gst_number,
            'pan_number' => $request->pan_number,
            'vendor_type' => $request->vendor_type,
            'address' => $request->address,
            'status' => $request->status,
            'updated_by' => $updatedBy,
            'updated_at' => now(),
        ]);

        // ✅ Log update action
        DB::table('rl_logs_tbl')->insert([
            'log_message' => "✏️ Vendor <strong>{$request->business_name}</strong> updated by <strong>{$updatedByName}</strong>.",
            'created_at' => now(),
        ]);

        Log::info("Vendor updated: {$request->business_name} by {$updatedByName}");

        return redirect()->route('manage-vendor')->with('success', 'Vendor details updated successfully!');
    }

    /**
     * Soft Delete Vendor (Move to Trash)
     */
    public function delete($id)
    {
        $vendor = Vendor::find($id);

        if (!$vendor) {
            return redirect()->route('manage-vendors')->with('error', 'Vendor not found.');
        }

        $user = Session::get('user');
        $deletedById = $user['id'] ?? null;
        $deletedByName = $user['name'] ?? 'System';
        $deletedByRole = $user['role'] ?? 'Unknown';

        $vendor->update([
            'trash' => 1,
            'deleted_by' => $deletedById,
            'deleted_by_role' => $deletedByRole,
            'deleted_at' => now(),
        ]);

        DB::table('rl_logs_tbl')->insert([
            'log_message' => "🗑️ Vendor <strong>{$vendor->business_name}</strong> moved to trash by <strong>{$deletedByName}</strong>.",
            'created_at' => now(),
        ]);

        Log::warning("Vendor deleted: {$vendor->business_name} by {$deletedByName}");

        return redirect()->route('manage-vendor')->with('success', 'Vendor moved to trash successfully.');
    }
}

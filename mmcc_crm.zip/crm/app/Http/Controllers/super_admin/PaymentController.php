<?php

namespace App\Http\Controllers\super_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use App\Models\Payment;
use Carbon\Carbon;

class PaymentController extends Controller
{
    /**
     * Show form to create Inward Payment
     */
    public function addInward()
    {
        $companies = \App\Models\Company::where('status', 1)
            ->where('trash', 0)
            ->orderBy('company_name', 'asc')
            ->get();

        $vendors = \App\Models\Vendor::where('status', 1)
            ->where('trash', 0)
            ->where('vendor_type', 'Inward')
            ->orderBy('business_name', 'asc')
            ->get();

        return view('super_admin.add_inwordpayment', compact('companies', 'vendors'));
    }

    /**
     * Store Payment Record (Inward or Outward)
     */
    public function storeold(Request $request)
    {
        // ✅ Validation
        $validator = Validator::make($request->all(), [
            'payment_type' => ['required', 'in:inward,outward'],
            'company_id' => ['required', 'exists:companies,id'],
            'vendor_id' => ['required', 'exists:vendors,id'],
            'total_amount' => ['nullable', 'numeric', 'min:0'],
            'discount' => ['nullable', 'numeric', 'min:0'],
            'paid_amount' => ['required', 'numeric', 'min:0'],
            'balance_amount' => ['nullable', 'numeric', 'min:0'],
            'payment_date' => ['required', 'string'], // will be converted
            'payment_mode' => ['required', 'in:cash,cheque,bank_transfer,upi'],
            'reference_number' => ['nullable', 'string', 'max:191'],
            'remarks' => ['nullable', 'string', 'max:500'],
            'status' => ['required', 'in:pending,completed,failed'],
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->with('error', 'Please fix the highlighted errors.')
                ->withInput();
        }

        // ✅ Convert payment date (dd/mm/yyyy → yyyy-mm-dd)
        try {
            $formattedDate = \Carbon\Carbon::createFromFormat('d/m/Y', $request->payment_date)
                ->format('Y-m-d');
        } catch (\Exception $e) {
            return back()
                ->with('error', 'Invalid date format. Please select a valid date.')
                ->withInput();
        }

        // ✅ Get current admin/session user
        $user = Session::get('user');
        $createdBy = $user['id'] ?? null;
        $createdByName = $user['name'] ?? 'System';

        // ✅ Store payment
        $payment = \App\Models\Payment::create([
            'payment_type' => $request->payment_type,
            'company_id' => $request->company_id,
            'vendor_id' => $request->vendor_id,
            'total_amount' => $request->total_amount ?? 0,
            'discount' => $request->discount ?? 0,
            'paid_amount' => $request->paid_amount,
            'balance_amount' => $request->balance_amount ?? 0,
            'payment_date' => $formattedDate,
            'payment_mode' => $request->payment_mode,
            'reference_number' => $request->reference_number,
            'remarks' => $request->remarks,
            'payment_status' => $request->status,
            'created_by' => $createdBy,
        ]);

        // ✅ Fetch names for logging
        $companyName = \App\Models\Company::find($request->company_id)?->company_name ?? 'Unknown Company';
        $vendorName = \App\Models\Vendor::find($request->vendor_id)?->business_name ?? 'Unknown Vendor';

        // ✅ Log the activity
        DB::table('rl_logs_tbl')->insert([
            'log_message' => "💰 New {$request->payment_type} payment created by <strong>{$createdByName}</strong> for <strong>{$companyName}</strong> (Vendor: {$vendorName}, Amount: ₹{$request->paid_amount})",
            'created_at' => now(),
        ]);

        \Log::info("Payment ({$request->payment_type}) created by {$createdByName}");

        return redirect()
            ->back()
            ->with('success', ucfirst($request->payment_type) . ' payment added successfully!');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_type' => ['required', 'in:inward,outward'],
            'company_id' => ['required', 'exists:companies,id'],
            'vendor_id' => ['required', 'exists:vendors,id'],
            'total_amount' => ['nullable', 'numeric', 'min:0'],
            'discount' => ['nullable', 'numeric', 'min:0'],
            'paid_amount' => ['required', 'numeric', 'min:0'],
            'balance_amount' => ['nullable', 'numeric', 'min:0'],
            'payment_date' => ['required', 'string'], // will be converted
            'payment_mode' => ['required', 'in:cash,cheque,bank_transfer,upi'],
            'reference_number' => ['nullable', 'string', 'max:191'],
            'remarks' => ['nullable', 'string', 'max:500'],
            'status' => ['required', 'in:pending,completed,failed'],
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->with('error', 'Please fix the highlighted errors.')
                ->withInput();
        }

        DB::beginTransaction();
        try {
            $formattedDate = \Carbon\Carbon::createFromFormat('d/m/Y', $request->payment_date)
                ->format('Y-m-d');

            $user = Session::get('user');
            $createdBy = $user['id'] ?? null;
            $createdByName = $user['name'] ?? 'System';

            // ✅ Main Payment
            $payment = \App\Models\Payment::create([
                'payment_type' => $request->payment_type,
                'company_id' => $request->company_id,
                'vendor_id' => $request->vendor_id,
                'total_amount' => $request->total_amount ?? 0,
                'discount' => $request->discount ?? 0,
                'paid_amount' => $request->paid_amount,
                'balance_amount' => $request->balance_amount ?? 0,
                'payment_date' => $formattedDate,
                'payment_mode' => $request->payment_mode,
                'reference_number' => $request->reference_number,
                'remarks' => $request->remarks,
                'payment_status' => $request->status, // user-entered status
                'created_by' => $createdBy,
            ]);

            // ✅ Mirror record in history if it's an outward payment
            if ($request->payment_type === 'outward') {
                \App\Models\PaymentHistory::create([
                    'payment_id' => $payment->id,
                    'company_id' => $payment->company_id,
                    'vendor_id' => $payment->vendor_id,
                    'total_amount' => $payment->total_amount,
                    'amount_paid' => $payment->paid_amount,
                    'balance' => $payment->balance_amount,
                    'payment_date' => $formattedDate,
                    'payment_type' => $payment->payment_mode,
                    'ref_number' => $payment->reference_number,
                    'note' => $payment->remarks,
                    // 'payment_status' => $payment->payment_status, // ✅ same as user entered
                    'payment_status' => trim(strtolower($payment->payment_status)) ?: 'pending',
                    'created_by' => $createdBy,
                ]);
            }

            // ✅ Logging
            $companyName = \App\Models\Company::find($request->company_id)?->company_name ?? 'Unknown Company';
            $vendorName = \App\Models\Vendor::find($request->vendor_id)?->business_name ?? 'Unknown Vendor';

            DB::table('rl_logs_tbl')->insert([
                'log_message' => "💰 New {$request->payment_type} payment created by <strong>{$createdByName}</strong> for <strong>{$companyName}</strong> (Vendor: {$vendorName}, Amount: ₹{$request->paid_amount}, Status: {$request->status})",
                'created_at' => now(),
            ]);

            DB::commit();
            return redirect()->back()->with('success', ucfirst($request->payment_type) . ' payment added successfully!');

        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error("Payment storing failed: " . $e->getMessage());
            return back()->with('error', 'Something went wrong while saving payment.');
        }
    }


    public function inwardPayments(Request $request)
    {
        $payments = Payment::with(['company', 'vendor'])
            ->where('payment_type', 'inward')
            ->where('trash', 0)
            ->orderByDesc('id')
            ->get();

        return view('super_admin.inward_payment', compact('payments'));
    }

    /**
     * View single inward payment
     */
    public function view($id)
    {
        $payment = Payment::with(['company', 'vendor'])
            ->where('id', $id)
            ->where('payment_type', 'inward')
            ->first();

        if (!$payment) {
            return redirect()->route('inward-payments')->with('error', 'Payment not found.');
        }

        return view('super_admin.view_inwardpayment', compact('payment'));
    }

    /**
     * Edit inward payment form
     */
    public function edit($id)
    {
        $payment = Payment::find($id);
        if (!$payment) {
            return redirect()->route('inward-payments')->with('error', 'Payment not found.');
        }

        $companies = \App\Models\Company::where('status', 1)
            ->where('trash', 0)
            ->orderBy('company_name', 'asc')
            ->get();

        $vendors = \App\Models\Vendor::where('status', 1)
            ->where('trash', 0)
            ->orderBy('business_name', 'asc')
            ->get();

        return view('super_admin.edit_inwardpayment', compact('payment', 'companies', 'vendors'));
    }

    /**
     * Update inward payment
     */
    public function update(Request $request, $id)
    {
        $payment = Payment::find($id);
        if (!$payment) {
            return redirect()->route('inward-payments')->with('error', 'Payment not found.');
        }

        $validator = Validator::make($request->all(), [
            'company_id' => ['required', 'exists:companies,id'],
            'vendor_id' => ['required', 'exists:vendors,id'],
            'total_amount' => ['nullable', 'numeric', 'min:0'],
            'discount' => ['nullable', 'numeric', 'min:0'],
            'paid_amount' => ['required', 'numeric', 'min:0'],
            'balance_amount' => ['nullable', 'numeric', 'min:0'],
            'payment_date' => ['required', 'string'],
            'payment_mode' => ['required', 'in:cash,cheque,bank_transfer,upi'],
            'reference_number' => ['nullable', 'string', 'max:191'],
            'remarks' => ['nullable', 'string', 'max:500'],
            'status' => ['required', 'in:pending,completed,failed'],
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput()->with('error', 'Please fix the highlighted errors.');
        }

        try {
            $formattedDate = Carbon::createFromFormat('d/m/Y', $request->payment_date)->format('Y-m-d');
        } catch (\Exception $e) {
            return back()->with('error', 'Invalid date format.')->withInput();
        }

        $payment->update([
            'company_id' => $request->company_id,
            'vendor_id' => $request->vendor_id,
            'total_amount' => $request->total_amount ?? 0,
            'discount' => $request->discount ?? 0,
            'paid_amount' => $request->paid_amount,
            'balance_amount' => $request->balance_amount ?? 0,
            'payment_date' => $formattedDate,
            'payment_mode' => $request->payment_mode,
            'reference_number' => $request->reference_number,
            'remarks' => $request->remarks,
            'payment_status' => $request->status,
            'updated_by' => Session::get('user')['id'] ?? null,
        ]);

        $user = Session::get('user');
        $updatedBy = $user['name'] ?? 'System';
        $companyName = $payment->company->company_name ?? 'Unknown Company';
        $vendorName = $payment->vendor->business_name ?? 'Unknown Vendor';

        DB::table('rl_logs_tbl')->insert([
            'log_message' => "✏️ Payment (ID: {$payment->id}) updated by <strong>{$updatedBy}</strong> for company name <strong>{$companyName}</strong> and vendor (Vendor: {$vendorName}).",
            'created_at' => now(),
        ]);

        Log::info("Payment updated by {$updatedBy}");

        return redirect()->route('inward-payments')->with('success', 'Payment updated successfully.');
    }

    /**
     * Soft delete payment
     */
    public function delete($id)
    {
        $payment = Payment::with('company')->find($id);

        if (!$payment) {
            return redirect()->route('inward-payments')->with('error', 'Payment not found.');
        }

        $user = Session::get('user');
        $deletedById = $user['id'] ?? null;
        $deletedByName = $user['name'] ?? 'System';

        // ✅ Use variable before string interpolation
        $companyName = $payment->company->company_name ?? 'Unknown Company';

        $payment->update([
            'trash' => 1,
            'deleted_by' => $deletedById,
            'deleted_at' => now(),
        ]);

        DB::table('rl_logs_tbl')->insert([
            'log_message' => "🗑️ Payment (ID: {$payment->id}) for company name <strong>{$companyName}</strong> deleted by <strong>{$deletedByName}</strong>.",
            'created_at' => now(),
        ]);

        Log::warning("Payment deleted by {$deletedByName}");

        return redirect()->route('inward-payments')->with('success', 'Payment moved to trash successfully.');
    }




    /**
     * Show form to create Outward Payment
     */
    public function addOutward()
    {
        $companies = \App\Models\Company::where('status', 1)
            ->where('trash', 0)
            ->orderBy('company_name', 'asc')
            ->get();

        $vendors = \App\Models\Vendor::where('status', 1)
            ->where('trash', 0)
            ->where('vendor_type', 'Outward')
            ->orderBy('business_name', 'asc')
            ->get();

        return view('super_admin.add_outwordpayment', compact('companies', 'vendors'));
    }

    /**
     * Manage Outward Payments
     */
    // public function outwardPayments()
    // {
    //     $payments = Payment::with(['company', 'vendor'])
    //         ->where('payment_type', 'outward')
    //         ->where('trash', 0)
    //         ->orderByDesc('id')
    //         ->get();

    //     return view('super_admin.outward_payment', compact('payments'));
    // }

    public function outwardPayments(Request $request)
    {
        $query = Payment::with(['company', 'vendor'])
            ->where('payment_type', 'outward')
            ->where('trash', 0);

        // 🔍 Search Filters
        if ($request->company_name) {
            $query->whereHas('company', function ($q) use ($request) {
                $q->where('company_name', 'like', '%' . $request->company_name . '%');
            });
        }

        if ($request->vendor_name) {
            $query->whereHas('vendor', function ($q) use ($request) {
                $q->where('business_name', 'like', '%' . $request->vendor_name . '%');
            });
        }

        if ($request->payment_status) {
            $query->where('payment_status', $request->payment_status);
        }

        $payments = $query->orderByDesc('id')->get();

        return view('super_admin.outward_payment', compact('payments'));
    }


    /**
     * View single outward payment
     */
    public function viewOutward($id)
    {
        $payment = Payment::with(['company', 'vendor'])
            ->where('id', $id)
            ->where('payment_type', 'outward')
            ->first();

        if (!$payment) {
            return redirect()->route('outward-payments')->with('error', 'Payment not found.');
        }

        return view('super_admin.view_outwardpayment', compact('payment'));
    }

    /**
     * Edit outward payment form
     */
    public function editOutward($id)
    {
        $payment = Payment::find($id);
        if (!$payment) {
            return redirect()->route('outward-payments')->with('error', 'Payment not found.');
        }

        $companies = \App\Models\Company::where('status', 1)
            ->where('trash', 0)
            ->orderBy('company_name', 'asc')
            ->get();

        $vendors = \App\Models\Vendor::where('status', 1)
            ->where('trash', 0)
            ->orderBy('business_name', 'asc')
            ->get();

        return view('super_admin.edit_outwardpayment', compact('payment', 'companies', 'vendors'));
    }

    /**
     * Update outward payment
     */
    public function updateOutward(Request $request, $id)
    {
        $payment = Payment::find($id);
        if (!$payment) {
            return redirect()->route('outward-payments')->with('error', 'Payment not found.');
        }

        $validator = Validator::make($request->all(), [
            'company_id' => ['required', 'exists:companies,id'],
            'vendor_id' => ['required', 'exists:vendors,id'],
            'total_amount' => ['nullable', 'numeric', 'min:0'],
            'discount' => ['nullable', 'numeric', 'min:0'],
            'paid_amount' => ['required', 'numeric', 'min:0'],
            'balance_amount' => ['nullable', 'numeric', 'min:0'],
            'payment_date' => ['required', 'string'],
            'payment_mode' => ['required', 'in:cash,cheque,bank_transfer,upi'],
            'reference_number' => ['nullable', 'string', 'max:191'],
            'remarks' => ['nullable', 'string', 'max:500'],
            'status' => ['required', 'in:pending,completed,failed'],
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput()->with('error', 'Please fix the highlighted errors.');
        }

        try {
            $formattedDate = Carbon::createFromFormat('d/m/Y', $request->payment_date)->format('Y-m-d');
        } catch (\Exception $e) {
            return back()->with('error', 'Invalid date format.')->withInput();
        }

        $payment->update([
            'company_id' => $request->company_id,
            'vendor_id' => $request->vendor_id,
            'total_amount' => $request->total_amount ?? 0,
            'discount' => $request->discount ?? 0,
            'paid_amount' => $request->paid_amount,
            'balance_amount' => $request->balance_amount ?? 0,
            'payment_date' => $formattedDate,
            'payment_mode' => $request->payment_mode,
            'reference_number' => $request->reference_number,
            'remarks' => $request->remarks,
            'payment_status' => $request->status,
            'updated_by' => Session::get('user')['id'] ?? null,
        ]);

        $user = Session::get('user');
        $updatedBy = $user['name'] ?? 'System';
        $companyName = $payment->company->company_name ?? 'Unknown Company';
        $vendorName = $payment->vendor->business_name ?? 'Unknown Vendor';

        DB::table('rl_logs_tbl')->insert([
            'log_message' => "✏️ Outward Payment (ID: {$payment->id}) updated by <strong>{$updatedBy}</strong> for <strong>{$companyName}</strong> (Vendor: {$vendorName}).",
            'created_at' => now(),
        ]);

        Log::info("Outward Payment updated by {$updatedBy}");

        return redirect()->route('outward-payments')->with('success', 'Outward Payment updated successfully.');
    }

    /**
     * Soft delete outward payment
     */
    public function deleteOutward($id)
    {
        $payment = Payment::with('company')->find($id);

        if (!$payment) {
            return redirect()->route('outward-payments')->with('error', 'Payment not found.');
        }

        $user = Session::get('user');
        $deletedById = $user['id'] ?? null;
        $deletedByName = $user['name'] ?? 'System';

        $companyName = $payment->company->company_name ?? 'Unknown Company';

        $payment->update([
            'trash' => 1,
            'deleted_by' => $deletedById,
            'deleted_at' => now(),
        ]);

        DB::table('rl_logs_tbl')->insert([
            'log_message' => "🗑️ Outward Payment (ID: {$payment->id}) for <strong>{$companyName}</strong> deleted by <strong>{$deletedByName}</strong>.",
            'created_at' => now(),
        ]);

        Log::warning("Outward Payment deleted by {$deletedByName}");

        return redirect()->route('outward-payments')->with('success', 'Outward Payment moved to trash successfully.');
    }

    public function recordPayment(Request $request, $paymentId)
    {
        $request->validate([
            'amount_paid' => 'required|numeric|min:1',
            'payment_type' => 'required|in:cash,cheque,bank_transfer,upi',
            'payment_date' => 'required|date',
            'ref_number' => 'nullable|string|max:191',
            'note' => 'nullable|string|max:500',
        ]);

        $payment = \App\Models\Payment::find($paymentId);
        if (!$payment) {
            return back()->with('error', 'Payment record not found.');
        }

        DB::beginTransaction();
        try {
            $user = Session::get('user');
            $createdBy = $user['id'] ?? null;
            $createdByName = $user['name'] ?? 'System';

            // Calculate new totals
            $newPaid = $payment->paid_amount + $request->amount_paid;
            $newBalance = max(0, ($payment->total_amount - $payment->discount) - $newPaid);
            $status = $newBalance <= 0 ? 'completed' : 'pending';

            $paymentProofPath = null;

            if ($request->hasFile('payment_proof')) {
                $file = $request->file('payment_proof');
                $filename = 'payment_' . time() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('uploads/payment_proof'), $filename);
                $paymentProofPath = 'uploads/payment_proof/' . $filename;
            }

            \App\Models\PaymentHistory::create([
                'payment_id' => $payment->id,
                'company_id' => $payment->company_id,
                'vendor_id' => $payment->vendor_id,
                'total_amount' => $payment->total_amount,
                'amount_paid' => $request->amount_paid,
                'balance' => $newBalance,
                'payment_date' => $request->payment_date,
                'payment_type' => $request->payment_type,
                'ref_number' => $request->ref_number,
                'payment_proof' => $paymentProofPath,
                'note' => $request->note,
                'payment_status' => $status,
                'created_by' => $createdBy,
            ]);


            // ✅ 2. Update main payment table
            $payment->update([
                'paid_amount' => $newPaid,
                'balance_amount' => $newBalance,
                'payment_status' => $status,
                'updated_by' => $createdBy,
            ]);

            // ✅ 3. Log the activity
            DB::table('rl_logs_tbl')->insert([
                'log_message' => "💳 Payment of ₹{$request->amount_paid} recorded by <strong>{$createdByName}</strong> for <strong>{$payment->company->company_name}</strong> (Vendor: {$payment->vendor->business_name}).",
                'created_at' => now(),
            ]);

            DB::commit();
            return back()->with('success', 'Payment recorded successfully!');
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error("Payment recording failed: " . $e->getMessage());
            return back()->with('error', 'Failed to record payment. Please try again.');
        }
    }

    public function paymentHistory($paymentId)
    {
        $payment = Payment::with(['company', 'vendor'])->find($paymentId);

        if (!$payment) {
            return redirect()->route('outward-payments')->with('error', 'Payment record not found.');
        }

        $history = \App\Models\PaymentHistory::where('payment_id', $paymentId)
            ->orderByDesc('payment_date')
            ->get();

        return view('super_admin.history', compact('payment', 'history'));
    }



}

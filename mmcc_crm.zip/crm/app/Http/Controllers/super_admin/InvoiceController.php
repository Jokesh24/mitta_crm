<?php

namespace App\Http\Controllers\super_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;

class InvoiceController extends Controller
{
    /**
     * Display the Manage Company page
     */
    public function index()
    {
        return view('super_admin.manage_invoice');
    }

    /**
     * Display the Add Company page
     */
    public function add()
    {
        return view('super_admin.add_invoice');
    }
}

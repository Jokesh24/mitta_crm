<?php

namespace App\Http\Controllers\super_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;

class AttendenceController extends Controller
{
    /**
     * Display the Manage Company page
     */
    public function monthly()
    {
        return view('super_admin.attendance_monthly');
    }

    /**
     * Display the Add Company page
     */
    public function attendence()
    {
        return view('super_admin.attendance');
    }

    /**
     * Display the Add Company page
     */
    // public function details()
    // {
    //     return view('super_admin.leads_details');
    // }


}

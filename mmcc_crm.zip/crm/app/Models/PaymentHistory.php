<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaymentHistory extends Model
{
    use HasFactory;

    protected $table = 'payments_history';

    protected $fillable = [
        'payment_id',
        'company_id',
        'vendor_id',
        'total_amount',
        'amount_paid',
        'balance',
        'payment_date',
        'payment_type',
        'ref_number',
        'payment_proof',
        'note',
        'payment_status',
        'created_by',
        'updated_by',
    ];

    public function company()
    {
        return $this->belongsTo(\App\Models\Company::class, 'company_id');
    }

    public function vendor()
    {
        return $this->belongsTo(\App\Models\Vendor::class, 'vendor_id');
    }
}

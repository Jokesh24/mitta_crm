<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserLoginLog extends Model
{
    protected $table = 'user_login_logs';
    protected $primaryKey = 'id';

    /**
     * Fields that can be mass assigned.
     */
    protected $fillable = [
        'user_id',
        'ip_address',
        'user_agent',
        'logged_in_at',
    ];

    /**
     * Type casting for datetimes.
     */
    protected $casts = [
        'logged_in_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Define relationship with user.
     */
    public function user()
    {
        return $this->belongsTo(RlUser::class, 'user_id', 'id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class TwoFactorAuth extends Model
{
    protected $table = 'two_factor_auths';
    protected $primaryKey = 'id';

    /**
     * Fields that can be mass assigned.
     */
    protected $fillable = [
        'user_id',
        'otp',
        'expires_at',
        'is_used',
    ];

    /**
     * Type casting.
     */
    protected $casts = [
        'expires_at' => 'datetime',
        'is_used' => 'boolean',
    ];

    /**
     * Relationship with the user.
     */
    public function user()
    {
        return $this->belongsTo(RlUser::class, 'user_id', 'id');
    }

    /**
     * Check if OTP is expired.
     */
    public function isExpired(): bool
    {
        return Carbon::now()->greaterThan($this->expires_at);
    }

    /**
     * Mark OTP as used.
     */
    public function markAsUsed(): void
    {
        $this->update(['is_used' => true]);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $table = 'payments';

    protected $fillable = [
        'payment_type',
        'company_id',
        'vendor_id',
        'total_amount',
        'discount',
        'paid_amount',
        'balance_amount',
        'payment_date',
        'payment_mode',
        'reference_number',
        'remarks',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
        'trash',
        'deleted_at',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class, 'company_id');
    }

    public function vendor()
    {
        return $this->belongsTo(Vendor::class, 'vendor_id');
    }
}

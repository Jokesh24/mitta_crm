<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendor extends Model
{
    protected $table = 'vendors';

    protected $fillable = [
        'business_name',
        'email',
        'mobile_number',
        'gst_number',
        'pan_number',
        'vendor_type',
        'address',
        'status',
        'trash',
        'created_by',
        'updated_by',
        'deleted_by',
        'deleted_by_role',
        'deleted_at'
    ];
}

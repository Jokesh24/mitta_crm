<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;

class RlUser extends Authenticatable
{
    use Notifiable, SoftDeletes;

    protected $table = 'rl_users';
    protected $primaryKey = 'id';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'password',
        'role',
        'status',
        'trash',
        'deleted_by_id',
        'deleted_by_role',
        'is_two_factor_enabled',
        'first_login',
        'last_login_status',
        'last_login_at',
        'last_login_ip',
        'last_login_user_agent',
        'latitude',
        'longitude',
        'failed_attempts',
        'email_verified_at',
        'remember_token',
        'created_by',
        'updated_by',
    ];

    /**
     * Attributes hidden from arrays or JSON outputs.
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'last_login_at' => 'datetime',
        'is_two_factor_enabled' => 'boolean',
        'status' => 'boolean',
        'trash' => 'boolean',
        'latitude' => 'float',
        'longitude' => 'float',
    ];

    /**
     * Automatically hash the password before saving.
     */
    public function setPasswordAttribute($value)
    {
        if (!empty($value) && Hash::needsRehash($value)) {
            $this->attributes['password'] = Hash::make($value);
        } else {
            $this->attributes['password'] = $value;
        }
    }

    /**
     * Relationships
     */

    // Each user can have one active 2FA record
    public function twoFactorAuth()
    {
        return $this->hasOne(TwoFactorAuth::class, 'user_id', 'id');
    }

    // Each user can have multiple login logs
    public function loginLogs()
    {
        return $this->hasMany(UserLoginLog::class, 'user_id', 'id');
    }

    // The user who deleted (trashed) this user
    public function deletedBy()
    {
        return $this->belongsTo(self::class, 'deleted_by_id');
    }

    /**
     * Helpers
     */

    // Check if user is active
    public function isActive(): bool
    {
        return (bool) $this->status && !$this->trash;
    }

    // Check if 2FA is enabled
    public function hasTwoFactorEnabled(): bool
    {
        return (bool) $this->is_two_factor_enabled;
    }

    // Check if user is trashed
    public function isTrashed(): bool
    {
        return (bool) $this->trash;
    }

    // Full role display (optional UI helper)
    public function getFormattedRoleAttribute(): string
    {
        return ucwords(str_replace('_', ' ', $this->role));
    }
}

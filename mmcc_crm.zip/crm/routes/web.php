<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


use App\Http\Controllers\LoginController;

Route::get('/', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');

Route::get('/verify-otp', [LoginController::class, 'showOtpForm'])->name('verify.otp.form');
Route::post('/verify-otp', [LoginController::class, 'verifyOtp'])->name('verify.otp.submit');

Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

Route::post('/toggle-2fa', [LoginController::class, 'toggleTwoFactor'])->name('toggle.2fa');
Route::get('/setup-2fa', [LoginController::class, 'showTwoFactorSetup'])->name('setup.2fa');
Route::post('/setup-2fa', [LoginController::class, 'handleTwoFactorSetup'])->name('setup.2fa.submit');
Route::post('/update-location', [LoginController::class, 'updateLocation'])
    ->name('update.location')
    ->middleware('verify.session'); // ensures only logged-in users



Route::get('/change-password', [LoginController::class, 'showChangePasswordForm'])->name('change.password.form')->middleware('verify.session');
Route::post('/change-password', [LoginController::class, 'changePassword'])->name('change.password.update')->middleware('verify.session');



Route::post('/resend-otp', [LoginController::class, 'resendOtp'])->name('resend.otp');

Route::get('/security-settings', function () {
    return view('super_admin.settings');
})->middleware('verify.session')->name('security.settings');


// Route::get('/dashboard', function () {
//     return view('super_admin.index');
// })->middleware('auth')->name('dashboard');

Route::get('/dashboard', function () {
    return view('super_admin.index');
})->middleware('verify.session')->name('dashboard');


// COMPANY Controller Code 
use App\Http\Controllers\super_admin\CompanyController;

Route::get('add_company', [CompanyController::class, 'index'])->name('add-company')->middleware('verify.session');
Route::post('store_company', [CompanyController::class, 'store'])->name('store-company')->middleware('verify.session');
Route::get('manage-company', [CompanyController::class, 'manage'])->name('manage-company')->middleware('verify.session');
Route::get('/edit-company/{id}', [CompanyController::class, 'edit'])->name('edit-company')->middleware('verify.session');
Route::post('/update-company/{id}', [CompanyController::class, 'update'])->name('update-company')->middleware('verify.session');
Route::get('/delete-company/{id}', [CompanyController::class, 'delete'])->name('delete-company')->middleware('verify.session');
Route::get('view-company/{id}', [CompanyController::class, 'view'])->name('view-company')->middleware('verify.session');

// COMPANY Controller Code
use App\Http\Controllers\super_admin\VendorController;

Route::get('manage_vendors', [VendorController::class, 'index'])->name('manage-vendor')->middleware('verify.session');
Route::get('add_vendor', [VendorController::class, 'add'])->name('add-vendor')->middleware('verify.session');
Route::post('store-vendor', [VendorController::class, 'store'])->name('store-vendor')->middleware('verify.session');
Route::get('delete-vendor/{id}', [VendorController::class, 'delete'])->name('delete-vendor')->middleware('verify.session');

Route::get('/vendor/edit/{id}', [VendorController::class, 'edit'])->name('edit-vendor')->middleware('verify.session');
Route::put('/vendor/update/{id}', [VendorController::class, 'update'])->name('update-vendor')->middleware('verify.session');

// COMPANY Controller Code 
use App\Http\Controllers\super_admin\LeadController;

Route::get('manage_leads', [LeadController::class, 'index'])->name('manage-leads')->middleware('verify.session');
Route::get('add_lead', [LeadController::class, 'add'])->name('add-lead')->middleware('verify.session');
Route::get('leade_details', [LeadController::class, 'details'])->name('leade-details')->middleware('verify.session');

// COMPANY Controller Code 
use App\Http\Controllers\super_admin\PaymentController;

// Inward Payment
Route::get('payment/inward/add', [PaymentController::class, 'addInward'])->name('add-inward-payment')->middleware('verify.session');
Route::post('payment/store', [PaymentController::class, 'store'])->name('store-payment')->middleware('verify.session');
Route::get('inward_payments', [PaymentController::class, 'inwardPayments'])->name('inward-payments')->middleware('verify.session');
Route::get('/inward-payment/view/{id}', [PaymentController::class, 'view'])->name('view-inward-payment')->middleware('verify.session');
Route::get('/inward-payment/edit/{id}', [PaymentController::class, 'edit'])->name('edit-inward-payment')->middleware('verify.session');
Route::post('/inward-payment/update/{id}', [PaymentController::class, 'update'])->name('update-inward-payment')->middleware('verify.session');
Route::get('/inward-payment/delete/{id}', [PaymentController::class, 'delete'])->name('delete-inward-payment')->middleware('verify.session');


// Outward Payments
Route::get('/outward-payments', [PaymentController::class, 'outwardPayments'])->name('outward-payments')->middleware('verify.session');
Route::get('/add-outward-payment', [PaymentController::class, 'addOutward'])->name('add-outward-payment')->middleware('verify.session');
Route::get('/outward-payment/view/{id}', [PaymentController::class, 'viewOutward'])->name('view-outward-payment')->middleware('verify.session');
Route::get('/outward-payment/edit/{id}', [PaymentController::class, 'editOutward'])->name('edit-outward-payment')->middleware('verify.session');
Route::post('/outward-payment/update/{id}', [PaymentController::class, 'updateOutward'])->name('update-outward-payment')->middleware('verify.session');
Route::get('/outward-payment/delete/{id}', [PaymentController::class, 'deleteOutward'])->name('delete-outward-payment')->middleware('verify.session');
Route::post('/outward-payment/record/{id}', [PaymentController::class, 'recordPayment'])->name('record-payment');
Route::get('/outward-payment/history/{id}', [PaymentController::class, 'paymentHistory'])->name('outward-payment-history');


// COMPANY Controller Code 
use App\Http\Controllers\super_admin\InvoiceController;

Route::get('manage_invoice', [InvoiceController::class, 'index'])->name('manage-invoice')->middleware('verify.session');
Route::get('add_invoice', [InvoiceController::class, 'add'])->name('add-invoice')->middleware('verify.session');

// COMPANY Controller Code 
use App\Http\Controllers\super_admin\EmployeeController;

Route::get('manage_employee', [EmployeeController::class, 'index'])->name('manage-employee')->middleware('verify.session');
Route::get('add_employee', [EmployeeController::class, 'add'])->name('add-employee')->middleware('verify.session');
Route::get('employee_view', [EmployeeController::class, 'view'])->name('view-employee')->middleware('verify.session');

// COMPANY Controller Code 
use App\Http\Controllers\super_admin\AttendenceController;

Route::get('today_attendence', [AttendenceController::class, 'attendence'])->name('attendence-today')->middleware('verify.session');
Route::get('monthly_attendence', [AttendenceController::class, 'monthly'])->name('attendence-monthly')->middleware('verify.session');

// COMPANY Controller Code 
use App\Http\Controllers\super_admin\PayslipController;

Route::get('payslip', [PayslipController::class, 'payslip'])->name('pay-slip')->middleware('verify.session');
Route::get('payroll', [PayslipController::class, 'payroll'])->name('pay-roll')->middleware('verify.session');

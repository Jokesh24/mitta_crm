<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MMCC CRM Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body,
    html {
      height: 100%;
      /* overflow: hidden; */
    }

    .login-container {
      display: flex;
      height: 100vh;
      width: 100%;
    }

    /* Left Section */
    .left-section {
      background: url('img/login_bg.png') center center/cover no-repeat;
      flex: 1;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding-left: 80px;
      position: relative;
    }

    .left-content {
      max-width: 600px;
    }

    .left-content h1 {
      font-size: 3.2rem;
      font-weight: 400;
      line-height: 1.3;
      color: #ffffff;
      margin-bottom: 20px;
      text-shadow: 0px 1px 4px rgba(0, 0, 0, 0.2);
    }

    .left-content h1 strong {
      font-weight: 700;
      display: block;
      font-size: 3.4rem;
    }

    .left-content p {
      font-size: 1.1rem;
      line-height: 1.8;
      color: rgba(255, 255, 255, 0.85);
      max-width: 520px;
      margin-top: 10px;
    }

    /* Right Section */
    .right-section {
      background-color: #F2EDE3;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 60px 80px;
      /* Increased right side padding for more breathing space */
      position: relative;
    }

    .logo {
      text-align: center;

      position: relative;
      top: -10px;
    }

    .logo img {
      width: 190px;
    }

    .login-box {
      width: 100%;
      max-width: 520px;
      background: transparent;
      padding: 30px 0;
      /* Added vertical spacing inside login box */
    }

    .login-box h4 {
      font-size: 1.3rem;
      font-weight: 600;
      text-align: center;
      color: #4a3b2e;
      margin-bottom: 35px;
      /* Increased space below heading */
    }

    .form-label {
      color: #4a3b2e;
      font-weight: 500;
      margin-bottom: 6px;
    }

    .form-control {
      background-color: #fff !important;
      border: none;
      border-radius: 4px;
      height: 50px;
      padding-left: 15px;
      font-size: 0.95rem;
      box-shadow: 0 0 2px rgba(0, 0, 0, 0.1);
    }

    .form-control:focus {
      outline: none;
      box-shadow: 0 0 0 2px #AC8942;
    }

    .mb-3,
    .mb-2 {
      margin-bottom: 25px !important;
      /* Increase gap between form fields */
    }

    .login-btn {
      width: 100%;
      height: 50px;
      border: none;
      color: #fff;
      font-size: 1.05rem;
      font-weight: 600;
      border-radius: 4px;
      background: linear-gradient(180deg, #966C22 0%, #AC8942 100%);
      transition: all 0.3s ease-in-out;
      margin-top: 25px;
      /* Added more spacing above button */
    }

    .login-btn:hover {
      transform: scale(1.02);
      opacity: 0.95;
    }

    .forgot-password {
      text-align: right;
      font-size: 0.9rem;
      margin-top: 10px;
    }

    .forgot-password a {
      text-decoration: none;
      color: #4a3b2e;
    }

    .forgot-password a:hover {
      text-decoration: underline;
    }

    @media (max-width: 992px) {
      .login-container {
        flex-direction: column;
        height: auto;
      }

      .left-section {
        height: 300px;
        padding: 40px;
        justify-content: center;
        text-align: center;
      }

      .left-content h1 {
        font-size: 2.2rem;
      }

      .left-content h1 strong {
        font-size: 2.4rem;
      }

      .left-content p {
        font-size: 0.95rem;
      }

      .right-section {
        height: auto;
        padding: 40px 20px;
      }
    }
  </style>
</head>

<body>
  <div class="login-container">
    <!-- Left Section -->
    <div class="left-section">
      <div class="left-content">
        <h1>Welcome to<br><strong>MMCC CRM Portal</strong></h1>
        <p>Manage your business smarter with MMCC CRM — a powerful platform designed to streamline customer
          relationships, automate workflows, and drive better decision-making. Stay connected, stay productive, and make
          every interaction count.</p>
      </div>
    </div>

    <!-- Right Section -->
    <div class="right-section">
      <div class="logo">
        <img src="{{ asset('img/logo.png') }}" alt="Logo">
      </div>
      <div class="login-box">
        <h4>Please login to your Account</h4>

        @if(session('error'))
          <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        @if(session('success'))
          <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        @if(session('info'))
          <div class="alert alert-info">{{ session('info') }}</div>
        @endif


        <form method="POST" action="{{ route('login.submit') }}">
          @csrf
          <div class="mb-3">
            <label class="form-label">Email/Mobile Number</label>
            <input type="text" name="email" class="form-control" placeholder="Email or Mobile Number" required>
          </div>

          <div class="mb-2">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Password" required>
          </div>

          <div class="forgot-password">
            <a href="#">Forgot Password?</a>
          </div>

          <button type="submit" class="login-btn mt-3">Login</button>
        </form>

      </div>
    </div>
  </div>
</body>

</html>
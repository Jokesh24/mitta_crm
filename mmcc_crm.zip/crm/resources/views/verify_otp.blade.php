<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>MMCC CRM Portal</title>
    @include('super_admin.includes.header_links')

    <style>
        body {
            background-color: #F2EDE3;
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .auth-container {
            max-width: 520px;
            width: 100%;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
            padding: 45px 40px;
            transition: all 0.3s ease;
        }

        .auth-container:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 28px rgba(0, 0, 0, 0.1);
        }

        .auth-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .auth-icon {
            width: 60px;
            height: 60px;
            background-color: #F2EDE3;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px auto;
            box-shadow: 0 0 0 4px rgba(150, 108, 34, 0.1);
        }

        .auth-icon i {
            font-size: 26px;
            color: #966C22;
        }

        .auth-header h3 {
            color: #966C22;
            font-weight: 700;
            font-size: 1.4rem;
        }

        .auth-header p {
            color: #7a6331;
            font-size: 0.95rem;
            margin-top: 5px;
        }

        .form-label-custom {
            color: #7a6331;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 6px;
        }

        .input-custom {
            border: 1px solid #e3d9c4;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .input-custom:focus {
            border-color: #AC8942;
            box-shadow: 0 0 0 0.2rem rgba(172, 137, 66, 0.25);
        }

        .btn-verify {
            background-color: #AC8942;
            border: none;
            border-radius: 10px;
            padding: 12px 0;
            font-weight: 600;
            color: #fff;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .btn-verify:hover {
            background-color: #966C22;
            box-shadow: 0 4px 12px rgba(150, 108, 34, 0.3);
        }

        .btn-resend {
            background: transparent;
            color: #966C22;
            font-weight: 600;
            border: none;
            margin-top: 10px;
            text-decoration: underline;
            font-size: 0.9rem;
            transition: all 0.2s ease;
        }

        .btn-resend:hover {
            color: #AC8942;
            text-decoration: none;
        }

        .alert-box {
            border-radius: 10px;
            font-size: 0.9rem;
            padding: 10px 12px;
            margin-bottom: 20px;
        }

        .alert-warning-custom {
            background-color: #fff8ec;
            color: #966C22;
            border: 1px solid #f2dca9;
            text-align: center;
        }

        .alert-warning-custom small {
            color: #7a6331;
        }

        .auth-footer {
            text-align: center;
            font-size: 0.9rem;
            color: #8c7745;
            margin-top: 25px;
        }

        .btn-resend:disabled {
            background: transparent;
            color: #bbb;
            cursor: not-allowed;
            text-decoration: none;
        }

        #countdownText {
            transition: opacity 0.3s ease;
        }
    </style>
</head>

<body>
    <div class="auth-container">
        <div class="auth-header">
            <div class="auth-icon">
                <i class="bi bi-shield-lock-fill"></i>
            </div>
            <h3>Verify OTP</h3>
            @php
                $maskedPhone = $phone ? substr($phone, 0, 2) . 'xxxxxx' . substr($phone, -2) : 'Unknown Number';
            @endphp
            <p>OTP has been sent to <strong>{{ $maskedPhone }}</strong></p>
        </div>

        @if(session('error'))
            <div class="alert alert-danger alert-box">{{ session('error') }}</div>
        @endif

        @if(session('info'))
            <div class="alert alert-info alert-box">{{ session('info') }}</div>
        @endif

        <div class="alert alert-warning-custom alert-box">
            <strong>Test OTP:</strong> {{ $otp ?? 'N/A' }} <br>
            <small style="color:red">
                Expires at:
                {{ $expires ? \Carbon\Carbon::parse($expires)->setTimezone('Asia/Kolkata')->format('h:i A') : '' }}
            </small>
        </div>

        <form method="POST" action="{{ route('verify.otp.submit') }}" id="verifyOtpForm">
            @csrf
            <div class="mb-4">
                <label class="form-label-custom">Enter OTP</label>
                <input type="text" name="otp" class="form-control input-custom" maxlength="6" required autofocus>
            </div>

            <button type="submit" class="btn btn-verify w-100">Verify & Continue</button>
        </form>

        <!-- Resend OTP -->
        <form method="POST" action="{{ route('resend.otp') }}" id="resendOtpForm">
            @csrf
            <button type="submit" id="resendOtpBtn" class="btn-resend w-100 mt-2">Resend OTP</button>
            <div id="countdownText" class="text-center mt-2 text-muted" style="font-size: 0.9rem;"></div>
        </form>


        <div class="auth-footer">
            Need help? <a href="#" style="color:#966C22; font-weight:600; text-decoration:none;">Contact Support</a>
        </div>
    </div>
    @include('super_admin.includes.footer_links')
</body>

</html>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const resendBtn = document.getElementById('resendOtpBtn');
        const countdownText = document.getElementById('countdownText');
        let cooldown = 30; // seconds

        // If cooldown already running in localStorage
        const storedTime = localStorage.getItem('otpCooldownEnd');
        const now = Date.now();

        if (storedTime && now < parseInt(storedTime)) {
            const remaining = Math.floor((parseInt(storedTime) - now) / 1000);
            startCooldown(remaining);
        }

        // Intercept resend form submission
        document.getElementById('resendOtpForm').addEventListener('submit', function (e) {
            e.preventDefault();
            if (resendBtn.disabled) return;

            // Submit the form manually
            this.submit();

            // Start cooldown after clicking
            startCooldown(cooldown);
        });

        function startCooldown(seconds) {
            resendBtn.disabled = true;
            resendBtn.style.opacity = '0.6';
            resendBtn.textContent = 'Resend OTP (Wait...)';

            const endTime = Date.now() + seconds * 1000;
            localStorage.setItem('otpCooldownEnd', endTime);

            const interval = setInterval(() => {
                const remaining = Math.floor((endTime - Date.now()) / 1000);
                if (remaining <= 0) {
                    clearInterval(interval);
                    resendBtn.disabled = false;
                    resendBtn.style.opacity = '1';
                    resendBtn.textContent = 'Resend OTP';
                    countdownText.textContent = '';
                    localStorage.removeItem('otpCooldownEnd');
                } else {
                    countdownText.textContent = `You can resend a new OTP in ${remaining}s`;
                }
            }, 1000);
        }
    });
</script>
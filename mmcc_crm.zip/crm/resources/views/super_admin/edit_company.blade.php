<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Company</title>
    @include('super_admin.includes.header_links')
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Edit Company</h5>
                        <div>
                            <a href="{{ route('manage-company') }}" class="btn btn-primary">
                                <i class="bi bi-chevron-double-left me-1"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Form -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-building me-1"></i> Edit Company Details
                            </h4>
                        </div>

                        @if(session('success'))
                            <div class="alert alert-success mt-3">{{ session('success') }}</div>
                        @endif
                        @if(session('error'))
                            <div class="alert alert-danger mt-3">{{ session('error') }}</div>
                        @endif

                        <form action="{{ route('update-company', $company->id) }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="row g-4 mb-4">
                                <!-- Company Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="company_name" class="form-control"
                                        value="{{ old('company_name', $company->company_name) }}">
                                    @error('company_name') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- Email -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Email<span
                                            class="text-danger">*</span></label>
                                    <input type="email" name="company_email" class="form-control"
                                        value="{{ old('company_email', $company->company_email) }}">
                                    @error('company_email') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- Mobile -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Mobile Number</label>
                                    <input type="text" name="mobile_number" class="form-control"
                                        value="{{ old('mobile_number', $company->mobile_number) }}">
                                    @error('mobile_number') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- GST -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">GST Number</label>
                                    <input type="text" name="gst_number" class="form-control"
                                        value="{{ old('gst_number', $company->gst_number) }}">
                                </div>

                                <!-- Company Logo -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Logo</label>
                                    <input type="file" name="company_logo" class="form-control" accept="image/*">
                                    @if($company->company_logo)
                                        <img src="{{ asset($company->company_logo) }}" alt="Logo" class="mt-2 rounded"
                                            width="60">
                                    @endif
                                    <small class="text-muted">Supported formats: JPG, PNG, SVG</small>
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status</label>
                                    <select name="status" class="form-select">
                                        <option value="active" {{ $company->status == 'active' ? 'selected' : '' }}>Active
                                        </option>
                                        <option value="inactive" {{ $company->status == 'inactive' ? 'selected' : '' }}>
                                            Inactive</option>
                                    </select>
                                </div>

                                <!-- Address -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Address</label>
                                    <textarea name="address" class="form-control"
                                        rows="2">{{ old('address', $company->address) }}</textarea>
                                </div>
                            </div>

                            <!-- BANK DETAILS -->
                            <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                                <h4 class="me-2 mb-0 fw-semibold text-primary">
                                    <i class="bi bi-bank me-1"></i> Bank Details
                                </h4>
                            </div>

                            <div class="row g-4 mb-4">
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Account Holder Name</label>
                                    <input type="text" name="account_holder_name" class="form-control"
                                        value="{{ old('account_holder_name', $company->account_holder_name) }}">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Bank Name</label>
                                    <input type="text" name="bank_name" class="form-control"
                                        value="{{ old('bank_name', $company->bank_name) }}">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Branch Name</label>
                                    <input type="text" name="branch_name" class="form-control"
                                        value="{{ old('branch_name', $company->branch_name) }}">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Account Number</label>
                                    <input type="text" name="account_number" class="form-control"
                                        value="{{ old('account_number', $company->account_number) }}">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">IFSC Code</label>
                                    <input type="text" name="ifsc_code" class="form-control"
                                        value="{{ old('ifsc_code', $company->ifsc_code) }}">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Account Type</label>
                                    <select name="account_type" class="form-select">
                                        <option value="">Select Type</option>
                                        <option value="saving" {{ $company->account_type == 'saving' ? 'selected' : '' }}>
                                            Saving</option>
                                        <option value="current" {{ $company->account_type == 'current' ? 'selected' : '' }}>Current</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <a href="{{ route('manage-company') }}"
                                    class="btn btn-outline-secondary px-4">Cancel</a>
                                <button type="submit" class="btn btn-primary px-4">Update Company</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')
</body>

</html>
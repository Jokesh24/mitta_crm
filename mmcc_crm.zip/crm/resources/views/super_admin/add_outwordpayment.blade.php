<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Outward Payment</title>
    @include('super_admin.includes.header_links')

    <!-- Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <!-- Flatpickr JS -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Create Outward Payment</h5>
                        <div>
                            <a href="{{ route('outward-payments') }}" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Outward Payments
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        @if(session('success'))
            <div class="alert alert-success mt-3">{{ session('success') }}</div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger mt-3">{{ session('error') }}</div>
        @endif

        <!-- Form Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="{{ route('store-payment') }}" method="POST" novalidate>
                            @csrf
                            <input type="hidden" name="payment_type" value="outward">

                            <div class="row g-4 mb-4">
                                <!-- Company Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Name <span
                                            class="text-danger">*</span></label>
                                    <select name="company_id" class="form-select" required>
                                        <option value="">Select Company</option>
                                        @foreach($companies as $company)
                                            <option value="{{ $company->id }}" {{ old('company_id') == $company->id ? 'selected' : '' }}>
                                                {{ $company->company_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('company_id') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- Vendor Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Vendor Name <span
                                            class="text-danger">*</span></label>
                                    <select name="vendor_id" class="form-select" required>
                                        <option value="">Select Vendor</option>
                                        @foreach($vendors as $vendor)
                                            <option value="{{ $vendor->id }}" {{ old('vendor_id') == $vendor->id ? 'selected' : '' }}>
                                                {{ $vendor->business_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('vendor_id') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- Total -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Total Amount</label>
                                    <input type="number" step="0.01" id="totalAmount" name="total_amount"
                                        value="{{ old('total_amount') }}" class="form-control"
                                        placeholder="Enter total amount">
                                </div>

                                <!-- Discount -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Discount</label>
                                    <input type="number" step="0.01" id="discountAmount" name="discount"
                                        value="{{ old('discount') }}" class="form-control"
                                        placeholder="Enter discount amount">
                                </div>

                                <!-- Paid -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Paid Amount <span
                                            class="text-danger">*</span></label>
                                    <input type="number" step="0.01" id="paidAmount" name="paid_amount"
                                        value="{{ old('paid_amount') }}" class="form-control"
                                        placeholder="Enter paid amount" required>
                                    @error('paid_amount') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- Balance -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Balance Amount</label>
                                    <input type="number" step="0.01" id="balanceAmount" name="balance_amount"
                                        value="{{ old('balance_amount') }}" class="form-control"
                                        placeholder="Balance will auto-calculate" readonly>
                                </div>

                                <!-- Payment Date
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" name="payment_date" value="{{ old('payment_date') }}"
                                        class="form-control" required>
                                    @error('payment_date') <small class="text-danger">{{ $message }}</small> @enderror
                                </div> -->

                                <!-- Payment Date -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Date <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="paymentDate" name="payment_date"
                                        value="{{ old('payment_date') }}" class="form-control" required>
                                    @error('payment_date') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- Payment Mode -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Mode <span
                                            class="text-danger">*</span></label>
                                    <select name="payment_mode" class="form-select" required>
                                        <option value="">Select Mode</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="bank_transfer">Bank Transfer</option>
                                        <option value="upi">UPI</option>
                                    </select>
                                    @error('payment_mode') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>

                                <!-- Reference Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Reference Number</label>
                                    <input type="text" name="reference_number" value="{{ old('reference_number') }}"
                                        class="form-control" placeholder="Enter reference ID">
                                </div>

                                <!-- Remarks -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Remarks</label>
                                    <textarea name="remarks" rows="2" class="form-control"
                                        placeholder="Enter remarks">{{ old('remarks') }}</textarea>
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status <span
                                            class="text-danger">*</span></label>
                                    <select name="status" class="form-select" required>
                                        <option value="">Select Status</option>
                                        <option value="pending">Pending</option>
                                        <option value="completed">Completed</option>
                                        <option value="failed">Failed</option>
                                    </select>
                                    @error('status') <small class="text-danger">{{ $message }}</small> @enderror
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
                                <button type="submit" class="btn btn-primary px-4">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')

    <!-- 🧮 Auto Balance Calculation -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const totalInput = document.getElementById('totalAmount');
            const discountInput = document.getElementById('discountAmount');
            const paidInput = document.getElementById('paidAmount');
            const balanceInput = document.getElementById('balanceAmount');

            function calculateBalance() {
                const total = parseFloat(totalInput.value) || 0;
                const discount = parseFloat(discountInput.value) || 0;
                const paid = parseFloat(paidInput.value) || 0;
                const balance = total - discount - paid;
                balanceInput.value = balance >= 0 ? balance.toFixed(2) : 0;
            }

            totalInput.addEventListener('input', calculateBalance);
            discountInput.addEventListener('input', calculateBalance);
            paidInput.addEventListener('input', calculateBalance);
        });
        // ✅ Flatpickr JS Date Picker
        document.addEventListener("DOMContentLoaded", function () {
            flatpickr("#paymentDate", {
                dateFormat: "d/m/Y",
                allowInput: true,
                maxDate: "today"
            });
        });
    </script>
</body>

</html>
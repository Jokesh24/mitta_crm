<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Vendor</title>
    @include('super_admin.includes.header_links')
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Edit Vendor</h5>
                        <div>
                            <a href="{{ route('manage-vendor') }}" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Vendors
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Vendor Form -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="{{ route('update-vendor', $vendor->id) }}" method="POST" novalidate>
                            @csrf
                            @method('PUT')

                            <div class="row g-4 mb-4">
                                <!-- Business Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Business Name <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="business_name"
                                        value="{{ old('business_name', $vendor->business_name) }}" class="form-control"
                                        required>
                                    @error('business_name')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- Email -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Email <span
                                            class="text-danger">*</span></label>
                                    <input type="email" name="email" value="{{ old('email', $vendor->email) }}"
                                        class="form-control" required>
                                    @error('email')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- Mobile Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Mobile Number <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="mobile_number"
                                        value="{{ old('mobile_number', $vendor->mobile_number) }}" class="form-control"
                                        required>
                                    @error('mobile_number')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- GST -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">GST Number</label>
                                    <input type="text" name="gst_number"
                                        value="{{ old('gst_number', $vendor->gst_number) }}" class="form-control">
                                    @error('gst_number')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- PAN -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">PAN Number</label>
                                    <input type="text" name="pan_number"
                                        value="{{ old('pan_number', $vendor->pan_number) }}" class="form-control">
                                    @error('pan_number')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- Vendor Type -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Vendor Type <span
                                            class="text-danger">*</span></label>
                                    <select name="vendor_type" class="form-select" required>
                                        <option value="">Select Type</option>
                                        <option value="Inward" {{ old('vendor_type', $vendor->vendor_type) == 'Inward' ? 'selected' : '' }}>Inward</option>
                                        <option value="Outward" {{ old('vendor_type', $vendor->vendor_type) == 'Outward' ? 'selected' : '' }}>Outward</option>
                                    </select>
                                    @error('vendor_type')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- Address -->
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Address <span
                                            class="text-danger">*</span></label>
                                    <textarea name="address" class="form-control" rows="3"
                                        required>{{ old('address', $vendor->address) }}</textarea>
                                    @error('address')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status <span
                                            class="text-danger">*</span></label>
                                    <select name="status" class="form-select" required>
                                        <option value="">Select Status</option>
                                        <option value="active" {{ old('status', $vendor->status) == 'active' ? 'selected' : '' }}>Active</option>
                                        <option value="inactive" {{ old('status', $vendor->status) == 'inactive' ? 'selected' : '' }}>Inactive</option>
                                    </select>
                                    @error('status')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <a href="{{ route('manage-vendor') }}" class="btn btn-outline-secondary px-4">Cancel</a>
                                <button type="submit" class="btn btn-primary px-4">Update Vendor</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')
</body>

</html>
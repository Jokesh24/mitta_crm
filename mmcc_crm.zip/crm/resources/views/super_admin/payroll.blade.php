<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>
    <!-- Your existing header links (Bootstrap, etc.) -->
    @include('super_admin.includes.header_links')

    <style>
        .salary-slip {
            background: #fff;
            border: 1px solid #000;
            max-width: 850px;
            margin: 40px auto;
            padding: 25px 35px;
        }

        .salary-slip table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }

        .salary-slip th,
        .salary-slip td {
            border: 1px dotted #000;
            padding: 8px 10px;
            vertical-align: middle;
            font-size: 15px;
        }

        .salary-slip th {
            background-color: #f1f1f1;
            font-weight: 600;
            text-align: left;
        }

        .text-center {
            text-align: center !important;
        }

        .text-end {
            text-align: right !important;
        }

        .fw-bold {
            font-weight: 700 !important;
        }

        .no-border td {
            border: none !important;
        }

        .header-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #00000057;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .header-section img {
            height: 70px;
            width: auto;
        }

        .company-details h4 {
            margin: 0;
            font-weight: 700;
            font-size: 20px;
        }

        .company-details p {
            margin: 0;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>

<body>
    @include('super_admin.includes.sidebar')

    @include('super_admin.includes.header')


    <div class="content">
        <!-- Page Header -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Payslip</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>

                            <!-- Custom CSS for tooltip -->
                            <!-- Export Dropdown -->
                            <div class="dropdown me-1 ">
                                <a href="javascript:void(0);"
                                    class="dropdown-toggle btn btn-white border-1 d-inline-flex align-items-center"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-pdf me-1"></i> Export as PDF
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-excel me-1"></i> Export as Excel
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Add New Company Button -->

                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="salary-slip">
            <!-- Header with logo and company info -->
            <div class="header-section border-bottom pb-3 mb-4">
                <div class="d-flex justify-content-between align-items-center flex-wrap">
                    <!-- Left: Company Logo and Details -->
                    <div class="d-flex align-items-center mb-2 mb-md-0">
                        <img src="img/logo.png" alt="Company Logo" width="70" class="me-3 rounded">
                        <div class="company-details">
                            <h4 class="fw-bold mb-1 text-primary">Richlabz IT Solutions</h4>
                            <p class="mb-0 small text-muted">8117 Roosevelt St, New Rochelle, NY 10801</p>
                            <p class="mb-0 small">
                                <strong>Phone:</strong> +1 555 123 4567 |
                                <strong>Email:</strong> info@lucidinfoweb.com
                            </p>
                        </div>
                    </div>

                    <!-- Right: Invoice Details -->

                </div>
            </div>


            <!-- Title -->

            <h5 class="fw-semibold text-primary mb-3">
                <i class="bi bi-calendar-week me-2"></i> Employee Details
            </h5>
            <!-- Employee details -->
            <table class="no-border mb-2">
                <tr>
                    <td><strong>Name:</strong> Madhavi Reddy</td>
                    <td><strong>Department:</strong> Design</td>
                </tr>
                <tr>
                    <td><strong>Emp. No:</strong> EMP123</td>
                    <td><strong>Bank Name:</strong> HDFC Bank</td>
                </tr>
                <tr>
                    <td><strong>Designation:</strong> Web Designer</td>
                    <td><strong>A/c No.:</strong> XXXX1234</td>
                </tr>
            </table>

            <!-- ================= WORK & ATTENDANCE SUMMARY ================= -->
            <div class="mb-4 mt-3">
                <h5 class="fw-semibold text-primary mb-3">
                    <i class="bi bi-calendar-week me-2"></i> Attendance & Work Summary
                </h5>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle mb-0">
                        <thead class="table-light text-center">
                            <tr>
                                <th>Total Working Days</th>
                                <th>Present Days</th>
                                <th>Leaves Taken</th>
                                <th>Paid Leaves</th>
                                <th>Extra Working Days</th>
                                <th>Overtime Hours</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr>
                                <td>26</td>
                                <td>22</td>
                                <td>2</td>
                                <td>1</td>
                                <td>1</td>
                                <td>6 hrs</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- ================= EARNINGS & DEDUCTIONS ================= -->
            <div>
                <h5 class="fw-semibold text-primary mb-3">
                    <i class="bi bi-cash-coin me-2"></i> Earnings & Deductions
                </h5>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle">
                        <thead class="table-light text-center">
                            <tr>
                                <th colspan="2">Earnings</th>
                                <th colspan="2">Deductions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Basic Salary</td>
                                <td class="text-end">₹25,200</td>
                                <td>EPF</td>
                                <td class="text-end">₹1,800</td>
                            </tr>
                            <tr>
                                <td>House Rent Allowance</td>
                                <td class="text-end">₹9,408</td>
                                <td>Health Insurance</td>
                                <td class="text-end">₹500</td>
                            </tr>
                            <tr>
                                <td>Conveyance Allowance</td>
                                <td class="text-end">₹1,493</td>
                                <td>Professional Tax</td>
                                <td class="text-end">₹200</td>
                            </tr>
                            <tr>
                                <td>Medical Allowance</td>
                                <td class="text-end">₹1,167</td>
                                <td>TDS</td>
                                <td class="text-end">–</td>
                            </tr>
                            <tr>
                                <td>Special Allowance</td>
                                <td class="text-end">₹18,732</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr class="fw-bold table-light">
                                <td>Gross Salary</td>
                                <td class="text-end">₹56,000</td>
                                <td>Total Deductions</td>
                                <td class="text-end">₹2,500</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Net Pay -->
            <table>
                <tr class="fw-bold">
                    <td>Net Pay</td>
                    <td class="text-end" colspan="3">₹53,500</td>
                </tr>
            </table>

            <!-- Amount in Words -->
            <table class="no-border">
                <tr>
                    <td><strong>Amount in Words:</strong> Fifty Three Thousand Five Hundred Only</td>
                </tr>
            </table>
        </div>
    </div>

    @include('super_admin.includes.footer_links')

</body>

</html>
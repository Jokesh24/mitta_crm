<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Edit Outward Payment</title>
    @include('super_admin.includes.header_links')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Edit Outward Payment</h5>
                        <div>
                            <a href="{{ route('outward-payments') }}" class="btn btn-primary">
                                <i class="bi bi-chevron-left me-1"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="{{ route('update-outward-payment', $payment->id) }}" method="POST">
                            @csrf
                            <input type="hidden" name="payment_type" value="outward">

                            <div class="row g-4 mb-4">
                                <!-- Company -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Name <span
                                            class="text-danger">*</span></label>
                                    <select name="company_id" class="form-select" required>
                                        <option value="">Select Company</option>
                                        @foreach($companies as $company)
                                            <option value="{{ $company->id }}" {{ $payment->company_id == $company->id ? 'selected' : '' }}>
                                                {{ $company->company_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- Vendor -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Vendor Name <span
                                            class="text-danger">*</span></label>
                                    <select name="vendor_id" class="form-select" required>
                                        <option value="">Select Vendor</option>
                                        @foreach($vendors as $vendor)
                                            <option value="{{ $vendor->id }}" {{ $payment->vendor_id == $vendor->id ? 'selected' : '' }}>
                                                {{ $vendor->business_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Total Amount</label>
                                    <input type="number" step="0.01" id="totalAmount" name="total_amount"
                                        value="{{ $payment->total_amount }}" class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Discount</label>
                                    <input type="number" step="0.01" id="discountAmount" name="discount"
                                        value="{{ $payment->discount }}" class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Paid Amount <span
                                            class="text-danger">*</span></label>
                                    <input type="number" step="0.01" id="paidAmount" name="paid_amount"
                                        value="{{ $payment->paid_amount }}" class="form-control" required>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Balance Amount</label>
                                    <input type="number" step="0.01" id="balanceAmount" name="balance_amount"
                                        value="{{ $payment->balance_amount }}" class="form-control" readonly>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Date <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="paymentDate" name="payment_date"
                                        value="{{ \Carbon\Carbon::parse($payment->payment_date)->format('d/m/Y') }}"
                                        class="form-control" required>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Mode</label>
                                    <select name="payment_mode" class="form-select" required>
                                        <option value="cash" {{ $payment->payment_mode == 'cash' ? 'selected' : '' }}>Cash
                                        </option>
                                        <option value="cheque" {{ $payment->payment_mode == 'cheque' ? 'selected' : '' }}>
                                            Cheque</option>
                                        <option value="bank_transfer" {{ $payment->payment_mode == 'bank_transfer' ? 'selected' : '' }}>Bank Transfer</option>
                                        <option value="upi" {{ $payment->payment_mode == 'upi' ? 'selected' : '' }}>UPI
                                        </option>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Reference Number</label>
                                    <input type="text" name="reference_number" value="{{ $payment->reference_number }}"
                                        class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Remarks</label>
                                    <textarea name="remarks" rows="2"
                                        class="form-control">{{ $payment->remarks }}</textarea>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status</label>
                                    <select name="status" class="form-select" required>
                                        <option value="pending" {{ $payment->payment_status == 'pending' ? 'selected' : '' }}>Pending</option>
                                        <option value="completed" {{ $payment->payment_status == 'completed' ? 'selected' : '' }}>Completed</option>
                                        <option value="failed" {{ $payment->payment_status == 'failed' ? 'selected' : '' }}>Failed</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <a href="{{ route('outward-payments') }}"
                                    class="btn btn-outline-secondary px-4">Cancel</a>
                                <button type="submit" class="btn btn-primary px-4">Update Payment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const totalInput = document.getElementById('totalAmount');
            const discountInput = document.getElementById('discountAmount');
            const paidInput = document.getElementById('paidAmount');
            const balanceInput = document.getElementById('balanceAmount');

            function calculateBalance() {
                const total = parseFloat(totalInput.value) || 0;
                const discount = parseFloat(discountInput.value) || 0;
                const paid = parseFloat(paidInput.value) || 0;
                balanceInput.value = (total - discount - paid).toFixed(2);
            }

            [totalInput, discountInput, paidInput].forEach(i => i.addEventListener('input', calculateBalance));
            flatpickr("#paymentDate", { dateFormat: "d/m/Y", allowInput: true });
        });
    </script>
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Change Password - CRM Dashboard</title>

    @include('super_admin.includes.header_links')

    <style>
        .is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.1rem rgba(220, 53, 69, 0.15);
        }

        small.text-danger {
            font-size: 0.85rem;
            font-weight: 500;
        }
    </style>
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Change Password</h5>
                        <div>
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Change Password Card -->
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-lock-fill me-1"></i> Update Password
                            </h4>
                        </div>

                        @if(session('success'))
                            <div class="alert alert-success mt-3">{{ session('success') }}</div>
                        @endif

                        @if(session('error'))
                            <div class="alert alert-danger mt-3">{{ session('error') }}</div>
                        @endif

                        <form action="{{ route('change.password.update') }}" method="POST" novalidate>
                            @csrf

                            <div class="row g-4 mb-4">
                                <!-- Old Password -->
                                <div class="col-md-12">
                                    <label class="form-label fw-semibold">Old Password <span
                                            class="text-danger">*</span></label>
                                    <input type="password" name="old_password"
                                        class="form-control @error('old_password') is-invalid @enderror"
                                        placeholder="Enter your current password" required>
                                    @error('old_password')
                                        <small class="text-danger d-block mt-1">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- New Password -->
                                <div class="col-md-12">
                                    <label class="form-label fw-semibold">New Password <span
                                            class="text-danger">*</span></label>
                                    <input type="password" name="new_password"
                                        class="form-control @error('new_password') is-invalid @enderror"
                                        placeholder="Enter new strong password" required>
                                    <small class="text-muted">
                                        Must be at least 6 characters, Try to include uppercase, lowercase, number, and
                                        special
                                        character.
                                    </small>
                                    @error('new_password')
                                        <small class="text-danger d-block mt-1">{{ $message }}</small>
                                    @enderror
                                </div>

                                <!-- Confirm New Password -->
                                <div class="col-md-12">
                                    <label class="form-label fw-semibold">Confirm New Password <span
                                            class="text-danger">*</span></label>
                                    <input type="password" name="confirm_password"
                                        class="form-control @error('confirm_password') is-invalid @enderror"
                                        placeholder="Re-enter new password" required>
                                    @error('confirm_password')
                                        <small class="text-danger d-block mt-1">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>

                            <!-- Buttons -->
                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
                                <button type="submit" class="btn btn-primary px-4">Update Password</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')

</body>

</html>
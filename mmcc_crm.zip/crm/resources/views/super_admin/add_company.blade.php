<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>



    <!-- Your existing header links (Bootstrap, etc.) -->
    @include('super_admin.includes.header_links')

<style>
    <style>
    .is-invalid {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 0.1rem rgba(220, 53, 69, 0.15);
    }

    small.text-danger {
        font-size: 0.85rem;
        font-weight: 500;
    }
</style>

</style>

</head>

<body>
    @include('super_admin.includes.sidebar')

    @include('super_admin.includes.header')


    <div class="content">
        <!-- Page Header -->
        <div class="row  mb-3">
            <div class="col-lg-12">
                <div class="card border-0 ">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Add New Company
                        </h5>
                        <div> <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>
                            <a href="{{ route('manage-company') }}" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Companies
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Employee Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 ">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <!-- ================= COMPANY DETAILS ================= -->
                            <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                                <h4 class="me-2 mb-0 fw-semibold text-primary">
                                    <i class="bi bi-building me-1"></i> Company Details
                                </h4>
                            </div>

                            @if(session('success'))
                                <div class="alert alert-success mt-3">{{ session('success') }}</div>
                            @endif

                            @if(session('error'))
                                <div class="alert alert-danger mt-3">{{ session('error') }}</div>
                            @endif

                            <!-- @if($errors->any())
                                <div class="alert alert-warning mt-3">
                                    <ul class="mb-0">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif -->


                           <form action="{{ route('store-company') }}" method="POST" enctype="multipart/form-data" novalidate>
    @csrf

    <div class="row g-4 mb-4">
        <!-- Company Name -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Company Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control @error('company_name') is-invalid @enderror"
                   name="company_name" value="{{ old('company_name') }}" placeholder="Enter company name" required>
            @error('company_name')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Email -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Company Email<span class="text-danger">*</span></label>
            <input type="email" class="form-control @error('company_email') is-invalid @enderror"
                   name="company_email" value="{{ old('company_email') }}" placeholder="Enter company email" required>
            @error('company_email')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Contact Number -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Mobile Number</label>
            <input type="text" class="form-control @error('mobile_number') is-invalid @enderror"
                   name="mobile_number" value="{{ old('mobile_number') }}" placeholder="Enter mobile number">
            @error('mobile_number')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- GST Number -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">GST Number</label>
            <input type="text" class="form-control @error('gst_number') is-invalid @enderror"
                   name="gst_number" value="{{ old('gst_number') }}" placeholder="Enter GST number">
            @error('gst_number')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Company Logo Upload -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Company Logo</label>
            <input type="file" class="form-control @error('company_logo') is-invalid @enderror"
                   name="company_logo" accept="image/*">
            <small class="text-muted">Supported formats: JPG, PNG, SVG (max 2MB)</small>
            @error('company_logo')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Status -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Status</label>
            <select name="status" class="form-select @error('status') is-invalid @enderror">
                <option value="">Select Status</option>
                <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>Active</option>
                <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>
            </select>
            @error('status')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Company Address -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Address</label>
            <textarea name="address" class="form-control @error('address') is-invalid @enderror"
                      rows="2" placeholder="Enter company address">{{ old('address') }}</textarea>
            @error('address')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>
    </div>

    <!-- ================= BANK DETAILS ================= -->
    <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
        <h4 class="me-2 mb-0 fw-semibold text-primary">
            <i class="bi bi-bank me-1"></i> Bank Details
        </h4>
    </div>

    <div class="row g-4 mb-4">
        <!-- Account Holder Name -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Account Holder Name</label>
            <input type="text" name="account_holder_name"
                   class="form-control @error('account_holder_name') is-invalid @enderror"
                   value="{{ old('account_holder_name') }}" placeholder="Enter account holder name">
            @error('account_holder_name')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Bank Name -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Bank Name</label>
            <input type="text" name="bank_name"
                   class="form-control @error('bank_name') is-invalid @enderror"
                   value="{{ old('bank_name') }}" placeholder="Enter bank name">
            @error('bank_name')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Branch Name -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Branch Name</label>
            <input type="text" name="branch_name"
                   class="form-control @error('branch_name') is-invalid @enderror"
                   value="{{ old('branch_name') }}" placeholder="Enter branch name">
            @error('branch_name')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Account Number -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Account Number</label>
            <input type="text" name="account_number"
                   class="form-control @error('account_number') is-invalid @enderror"
                   value="{{ old('account_number') }}" placeholder="Enter account number">
            @error('account_number')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- IFSC Code -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">IFSC Code</label>
            <input type="text" name="ifsc_code"
                   class="form-control @error('ifsc_code') is-invalid @enderror"
                   value="{{ old('ifsc_code') }}" placeholder="Enter IFSC code">
            @error('ifsc_code')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>

        <!-- Account Type -->
        <div class="col-md-4">
            <label class="form-label fw-semibold">Account Type</label>
            <select name="account_type" class="form-select @error('account_type') is-invalid @enderror">
                <option value="">Select Type</option>
                <option value="saving" {{ old('account_type') == 'saving' ? 'selected' : '' }}>Saving</option>
                <option value="current" {{ old('account_type') == 'current' ? 'selected' : '' }}>Current</option>
            </select>
            @error('account_type')
                <small class="text-danger d-block mt-1">{{ $message }}</small>
            @enderror
        </div>
    </div>

    <!-- ================= BUTTONS ================= -->
    <div class="mt-4 d-flex justify-content-end gap-2">
        <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
        <button type="submit" class="btn btn-primary px-4">Submit</button>
    </div>
</form>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <script>
        flatpickr("#joiningDate", {
            dateFormat: "d/m/Y",
            allowInput: true
        });
    </script>
    @include('super_admin.includes.footer_links')

</body>



</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>MMCC CRM Portal</title>
    @include('super_admin.includes.header_links')

    <style>
        body {
            background-color: #F2EDE3;
            /* font-family: 'Poppins', sans-serif; */
            color: #4a3b2e;
        }

        .container-security {
            max-width: 850px;
            margin: 50px auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
            padding: 40px 50px;
        }

        .security-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .security-header h3 {
            font-weight: 700;
            color: #966C22;
            font-size: 1.8rem;
        }

        .security-header p {
            color: #7a6331;
            font-size: 0.95rem;
        }

        .form-check-input {
            width: 50px;
            height: 26px;
            cursor: pointer;
            border-color: #ac8942;
        }

        .form-check-input:checked {
            background-color: #AC8942;
            border-color: #AC8942;
        }

        .alert {
            border-radius: 12px;
            padding: 15px 18px;
            font-size: 0.95rem;
            margin-top: 20px;
        }

        .alert-success {
            background-color: #e7f4ec;
            border: 1px solid #b7e0c2;
            color: #216d35;
        }

        .alert-warning {
            background-color: #fff8ec;
            border: 1px solid #f2dca9;
            color: #966C22;
        }

        .settings-box {
            background-color: #f8f5ef;
            border-radius: 12px;
            padding: 25px 30px;
            margin-top: 20px;
            border: 1px solid #e3d9c4;
        }

        .btn-back {
            background-color: #AC8942;
            color: #fff;
            border: none;
            padding: 10px 25px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-back:hover {
            background-color: #966C22;
            color: #fff;
            transform: scale(1.03);
        }

        .footer-note {
            text-align: center;
            font-size: 0.85rem;
            color: #8c7745;
            margin-top: 25px;
        }
    </style>
</head>

<body>
    @include('super_admin.includes.header')
    @include('super_admin.includes.sidebar')



    <div class="container-security">
        <div class="security-header">
            <h3>Security Settings</h3>
            <p>Manage your account’s login security and Two-Factor Authentication.</p>
        </div>

        @if(session('success'))
            <div class="alert alert-success text-center">{{ session('success') }}</div>
        @endif

        @if(session('error'))
            <div class="alert alert-warning text-center">{{ session('error') }}</div>
        @endif

        @if(Session::has('user'))
            @php
                $user = \App\Models\RlUser::find(Session::get('user.id'));
            @endphp

            <div class="settings-box">
                <h5 class="fw-semibold mb-3">Two-Factor Authentication (2FA)</h5>
                <p class="text-muted mb-4">
                    Add an extra layer of security to your account. When 2FA is enabled, you will be required to verify
                    your login using a one-time password (OTP) sent to your registered mobile number.
                </p>

                <form method="POST" action="{{ route('toggle.2fa') }}">
                    @csrf
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="twoFactorSwitch" name="is_two_factor_enabled"
                            onchange="this.form.submit()" {{ $user->is_two_factor_enabled ? 'checked' : '' }}>
                        <label class="form-check-label fw-medium" for="twoFactorSwitch">
                            Enable Two-Factor Authentication (OTP Verification)
                        </label>
                    </div>
                </form>

                @if($user->is_two_factor_enabled)
                    <div class="alert alert-success mt-3">
                        ✅ Two-Factor Authentication is currently <strong>Enabled</strong>.
                        <br>
                        You will be asked for an OTP each time you log in.
                    </div>
                @else
                    <div class="alert alert-warning mt-3">
                        ⚠️ Two-Factor Authentication is currently <strong>Disabled</strong>.
                        <br>
                        Enable it for enhanced account security.
                    </div>
                @endif
            </div>
        @endif

        <div class="text-center mt-4">
            <a href="{{ route('dashboard') }}" class="btn-back">
                <i class="bi bi-arrow-left-circle me-1"></i> Back to Dashboard
            </a>
        </div>

        <div class="footer-note">
            For any assistance, contact <strong>support@mmcccrm.com</strong>
        </div>
    </div>

    @include('super_admin.includes.footer_links')
</body>

</html>
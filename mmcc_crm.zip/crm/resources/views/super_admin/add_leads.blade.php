<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>

    <!-- Your existing header links (Bootstrap, etc.) -->
    @include('super_admin.includes.header_links')

</head>

<body>
    @include('super_admin.includes.sidebar')

    @include('super_admin.includes.header')

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Create New Lead</h5>
                        <div>
                            <a href="{{ route('manage-leads') }}" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Leads
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lead Form Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="#" novalidate>
                            <div class="row g-4 mb-4">
                                <!-- Customer Mobile Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Customer Mobile Number <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Customer Mobile Number"
                                        required>
                                </div>

                                <!-- Customer Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Customer Name <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter customer name" required>
                                </div>

                                <!-- Business Type -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Business Type <span
                                            class="text-danger">*</span></label>
                                    <select class="form-select" required>
                                        <option value="">Select Business Type</option>
                                        <option>Type 1</option>
                                        <option>Type 2</option>
                                    </select>
                                </div>

                                <!-- Email ID -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Email ID <span
                                            class="text-danger">*</span></label>
                                    <input type="email" class="form-control" placeholder="Enter email address" required>
                                </div>

                                <!-- Lead Source -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Lead Source <span
                                            class="text-danger">*</span></label>
                                    <select class="form-select" required>
                                        <option value="">Select Lead Source</option>
                                        <option>Source 1</option>
                                        <option>Source 2</option>
                                    </select>
                                </div>

                                <!-- Follow Up Date & Time -->
                                <div class="col-md-2">
                                    <label class="form-label fw-semibold">Follow Up Date</label>
                                    <input type="date" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label fw-semibold">Follow Up Time</label>
                                    <input type="time" class="form-control">
                                </div>

                                <!-- Team Member -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Team Member</label>
                                    <select class="form-select">
                                        <option value="">Select Team Member</option>
                                        <option>Member 1</option>
                                        <option>Member 2</option>
                                    </select>
                                </div>

                                <!-- Lead Status -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Lead Status <span
                                            class="text-danger">*</span></label>
                                    <select class="form-select" required>
                                        <option value="">Select Status</option>
                                        <option>New</option>
                                        <option>In Progress</option>
                                        <option>Closed</option>
                                    </select>
                                </div>

                                <!-- Lead Details -->
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Lead Details <span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" placeholder="Lead Details"
                                        required></textarea>
                                </div>
                            </div>

                            <!-- Buttons -->
                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
                                <button type="submit" class="btn btn-primary px-4">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        flatpickr("#joiningDate", {
            dateFormat: "d/m/Y",
            allowInput: true
        });
    </script>
    @include('super_admin.includes.footer_links')

</body>



</html>
@include('super_admin.includes.header_links')

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Payment Failed</title>

    <style>
        /* Page layout */
        body,
        html {
            height: 100%;
            margin: 0;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Message box style */
        .message-box {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            text-align: center;
            padding: 40px 68px;
            width: 100%;
            max-width: 420px;
            animation: slideDown 1s ease forwards;
            opacity: 0;
            transform: translateY(-40px);
        }

        /* Slide down animation */
        @keyframes slideDown {
            0% {
                opacity: 0;
                transform: translateY(-50px);
            }

            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Icon animation */
        .message-box._failed i {
            font-size: 60px;
            color: #dc3545;
            /* Red for failure */
            margin-bottom: 20px;
            animation: popIn 0.8s ease;
        }

        @keyframes popIn {
            0% {
                transform: scale(0);
                opacity: 0;
            }

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        /* Text styling */
        .message-box h2 {
            font-weight: 600;
            margin-bottom: 10px;
            color: #212529;
        }

        .message-box p {
            color: #6c757d;
            font-size: 16px;
            line-height: 1.5;
        }

        /* Optional retry button */
        .retry-btn {
            display: inline-block;
            margin-top: 20px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .retry-btn:hover {
            background-color: #b52a36;
        }
    </style>
</head>

<body>
    <div class="message-box _failed">
        <i class="bi bi-x-circle" aria-hidden="true"></i>
        <h2>Your payment failed</h2>
        <p>Please try again later.</p>
        <button class="retry-btn" onclick="window.location.href='payment.php'">Try Again</button>
    </div>

    @include('super_admin.includes.footer_links')

</body>

</html>
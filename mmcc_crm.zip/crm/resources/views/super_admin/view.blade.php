<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>
    @include('super_admin.includes.header_links')
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Company Details</h5>
                        <div>
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i>
                            </a>
                            <a href="{{ route('manage-company') }}" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Companies
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Company Details Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">

                        <!-- ================= COMPANY DETAILS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-building me-1"></i> Company Details
                            </h4>
                        </div>

                        <!-- Company Details Rows -->
                        <div class="mb-4 font">
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Company Name:</strong> {{ $company->company_name }}</div>
                                <div class="col-md-4"><strong>Mobile:</strong> {{ $company->mobile_number ?? 'N/A' }}
                                </div>
                                <div class="col-md-4"><strong>GST No:</strong> {{ $company->gst_number ?? 'N/A' }}</div>
                            </div>

                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Email:</strong> {{ $company->company_email }}</div>
                                <!-- <div class="col-md-4"><strong>PAN No:</strong> {{ $company->pan_card ?? 'N/A' }}</div> -->
                                <div class="col-md-4"><strong>Status:</strong>
                                    @if($company->status == 'active')
                                        <span class="badge bg-success">Active</span>
                                    @else
                                        <span class="badge bg-danger">Inactive</span>
                                    @endif
                                </div>
                            </div>

                            <div class="row mb-2">
                                <!-- <div class="col-md-4"><strong>Established:</strong>
                                    {{ $company->established_year ?? 'N/A' }}</div> -->
                                <div class="col-md-4"><strong>Address:</strong> {{ $company->address ?? 'N/A' }}</div>
                                <div class="col-md-4">
                                    <strong>Logo:</strong>
                                    @if($company->company_logo)
                                        <img src="{{ asset($company->company_logo) }}" width="50" class="rounded border">
                                    @else
                                        <img src="{{ asset('img/default-logo.png') }}" width="50" class="rounded border">
                                    @endif
                                </div>
                            </div>
                        </div>

                        <!-- ================= BANK DETAILS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-bank me-1"></i> Bank Details
                            </h4>
                        </div>

                        <div class="mb-4">
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Account Holder:</strong>
                                    {{ $company->account_holder_name ?? 'N/A' }}</div>
                                <div class="col-md-4"><strong>Bank Name:</strong> {{ $company->bank_name ?? 'N/A' }}
                                </div>
                                <div class="col-md-4"><strong>Branch:</strong> {{ $company->branch_name ?? 'N/A' }}
                                </div>
                            </div>

                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Account No:</strong>
                                    {{ $company->account_number ?? 'N/A' }}</div>
                                <div class="col-md-4"><strong>IFSC:</strong> {{ $company->ifsc_code ?? 'N/A' }}</div>
                                <div class="col-md-4"><strong>Type:</strong>
                                    {{ ucfirst($company->account_type ?? 'N/A') }}</div>
                            </div>
                        </div>

                        <!-- Buttons -->
                        <div class="mt-4 d-flex justify-content-end gap-2">
                            <a href="{{ route('edit-company', $company->id) }}" class="btn btn-primary px-4">
                                <i class="bi bi-pencil-square me-1"></i> Edit
                            </a>
                            <a href="{{ route('manage-company') }}" class="btn btn-outline-secondary px-4">Back</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')
</body>

</html>
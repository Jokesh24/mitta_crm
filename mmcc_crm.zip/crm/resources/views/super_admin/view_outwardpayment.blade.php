<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - View Outward Payment</title>
    @include('super_admin.includes.header_links')
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">View Outward Payment</h5>
                        <div>
                            <a href="{{ route('outward-payments') }}" class="btn btn-primary">
                                <i class="bi bi-chevron-left me-1"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="row g-4 mb-4">
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Company Name</label>
                                <input type="text" class="form-control"
                                    value="{{ $payment->company->company_name ?? '-' }}" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Vendor Name</label>
                                <input type="text" class="form-control"
                                    value="{{ $payment->vendor->business_name ?? '-' }}" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Total Amount</label>
                                <input type="text" class="form-control"
                                    value="₹{{ number_format($payment->total_amount, 2) }}" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Discount</label>
                                <input type="text" class="form-control"
                                    value="₹{{ number_format($payment->discount, 2) }}" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Paid Amount</label>
                                <input type="text" class="form-control"
                                    value="₹{{ number_format($payment->paid_amount, 2) }}" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Balance Amount</label>
                                <input type="text" class="form-control"
                                    value="₹{{ number_format($payment->balance_amount, 2) }}" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Payment Date</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->payment_date)->format('d/m/Y') }}"
                                    readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Payment Mode</label>
                                <input type="text" class="form-control" value="{{ ucfirst($payment->payment_mode) }}"
                                    readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Reference Number</label>
                                <input type="text" class="form-control" value="{{ $payment->reference_number ?? '-' }}"
                                    readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Remarks</label>
                                <textarea class="form-control" rows="2"
                                    readonly>{{ $payment->remarks ?? '-' }}</textarea>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Payment Status</label><br>
                                @if($payment->payment_status == 'completed')
                                    <span class="badge bg-success px-3 py-2">Completed</span>
                                @elseif($payment->payment_status == 'pending')
                                    <span class="badge bg-warning text-dark px-3 py-2">Pending</span>
                                @else
                                    <span class="badge bg-danger px-3 py-2">Failed</span>
                                @endif
                            </div>
                        </div>

                        <div class="mt-4 d-flex justify-content-end gap-2">
                            <a href="{{ route('edit-outward-payment', $payment->id) }}"
                                class="btn btn-primary px-4">Edit Payment</a>
                            <a href="{{ route('outward-payments') }}" class="btn btn-outline-secondary px-4">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')
</body>

</html>
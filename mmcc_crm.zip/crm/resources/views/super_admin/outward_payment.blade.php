<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Outward Payment</title>
    @include('super_admin.includes.header_links')
</head>

<body>
    @include('super_admin.includes.sidebar')
    @include('super_admin.includes.header')

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Payments</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i>
                            </a>

                            <!-- Export Dropdown -->
                            <div class="dropdown me-1">
                                <a href="javascript:void(0);"
                                    class="dropdown-toggle btn btn-white border-1 d-inline-flex align-items-center"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-pdf me-1"></i> Export as PDF
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-excel me-1"></i> Export as Excel
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Add Button -->
                            <a href="{{ route('add-outward-payment') }}" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add Outward Payment
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Manage Table -->
        <div class="card shadow-sm border-bottom mt-3 company">
            <div class="border-bottom">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <h5 class="fw-semibold mb-0">Outward Payment</h5>

                        <!-- Filters -->
                        <div class="d-flex align-items-center flex-wrap justify-content-end gap-2">
                            <input type="text" id="searchCompany" class="form-control"
                                placeholder="Search by Company Name" style="width:210px;">
                            <input type="text" id="searchVendor" class="form-control"
                                placeholder="Search by Vendor Name" style="width:210px;">
                            <select id="searchStatus" class="form-select" style="width:160px;">
                                <option value="">All Payment Status</option>
                                <option value="pending">Pending</option>
                                <option value="completed">Completed</option>
                                <option value="failed">Failed</option>
                            </select>
                            <button class="btn btn-light border-1" id="resetFilter">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            @if(session('success'))
                <div class="alert alert-success mt-3">{{ session('success') }}</div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger mt-3">{{ session('error') }}</div>
            @endif

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th><input type="checkbox" class="form-check-input"></th>
                                <th>Company</th>
                                <th>Vendor Name</th>
                                <th>Total</th>
                                <th>Paid</th>
                                <th>Discount</th>
                                <th>Balance</th>
                                <th>Due Date</th>
                                <th>Payment Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="paymentTableBody">
                            @forelse($payments as $index => $payment)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td><input type="checkbox" class="form-check-input"></td>
                                    <td>{{ $payment->company->company_name ?? '-' }}</td>
                                    <td>{{ $payment->vendor->business_name ?? '-' }}</td>
                                    <td>₹{{ number_format($payment->total_amount, 2) }}</td>
                                    <td>₹{{ number_format($payment->paid_amount, 2) }}</td>
                                    <td>₹{{ number_format($payment->discount, 2) }}</td>
                                    <td>₹{{ number_format($payment->balance_amount, 2) }}</td>
                                    <td>{{ \Carbon\Carbon::parse($payment->payment_date)->format('d/m/Y') }}</td>
                                    <td>
                                        @if($payment->payment_status == 'completed')
                                            <span class="badge bg-success">Completed</span>
                                        @elseif($payment->payment_status == 'pending')
                                            <span class="badge bg-warning text-dark">Pending</span>
                                        @else
                                            <span class="badge bg-danger">Failed</span>
                                        @endif
                                    </td>

                                    <td class="text-center">
                                        <!-- Pay -->
                                        <button class="btn btn-sm btn-outline-success me-1 pay-btn" data-bs-toggle="modal"
                                            data-bs-target="#recordPaymentModal" data-id="{{ $payment->id }}"
                                            data-company="{{ $payment->company->company_name ?? '-' }}"
                                            data-total="{{ $payment->total_amount }}"
                                            data-balance="{{ $payment->balance_amount }}">
                                            <i class="bi bi-cash-stack me-1"></i> Pay
                                        </button>


                                        <!-- Payment History -->
                                        <a href="{{ route('outward-payment-history', $payment->id) }}"
                                            class="btn btn-sm btn-outline-warning me-1" title="View Payment History">
                                            <i class="bi bi-clock-history me-1"></i> History
                                        </a>


                                        <!-- Edit -->
                                        <a href="{{ route('edit-outward-payment', $payment->id) }}"
                                            class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <!-- Delete -->
                                        <button type="button" class="btn btn-sm btn-outline-danger me-1 delete-btn"
                                            data-id="{{ $payment->id }}" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>

                                        <!-- View -->
                                        <a href="{{ route('view-outward-payment', $payment->id) }}"
                                            class="btn btn-sm btn-outline-info" title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="11" class="text-center text-muted">No outward payments found</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <!-- Pagination Placeholder -->
                <nav aria-label="Outward Payments Pagination">
                    <ul class="pagination justify-content-end mt-3">
                        <li class="page-item disabled"><a class="page-link" href="#"><i
                                    class="bi bi-chevron-left"></i></a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#"><i class="bi bi-chevron-right"></i></a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Record Payment Modal -->
    <div class="modal fade" id="recordPaymentModal" tabindex="-1" aria-labelledby="recordPaymentModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header text-white" style="background:#946d1e;">
                    <h5 class="modal-title" id="recordPaymentModalLabel"><i class="bi bi-cash-coin me-2"></i>Record
                        Payment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <form action="" method="POST" id="recordPaymentForm" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" id="paymentIdField" name="payment_id">

                        <div class="row g-3">
                            <!-- ✅ Company Name (formerly Paying Account) -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Company Name <span
                                        class="text-danger">*</span></label>
                                <input type="text" id="companyNameField" name="company_name" class="form-control"
                                    readonly>
                            </div>

                            <!-- ✅ Total Amount -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Total Amount</label>
                                <input type="text" id="totalAmountField" class="form-control" name="total_amount"
                                    readonly>
                            </div>

                            <!-- ✅ Balance Amount -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Balance Amount</label>
                                <input type="text" id="balanceAmountField" class="form-control" name="balance_amount"
                                    readonly>
                            </div>

                            <!-- ✅ Paying Amount -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Enter Paying Amount <span
                                        class="text-danger">*</span></label>
                                <input type="number" step="0.01" class="form-control" name="amount_paid"
                                    placeholder="Enter Paying Amount" required>
                            </div>

                            <!-- ✅ Payment Type -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Payment Type <span
                                        class="text-danger">*</span></label>
                                <select name="payment_type" class="form-select" required>
                                    <option value="">Select Payment Type</option>
                                    <option value="cash">Cash</option>
                                    <option value="cheque">Cheque</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                    <option value="upi">UPI</option>
                                </select>
                            </div>

                            <!-- ✅ Payment Date -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Payment Date <span
                                        class="text-danger">*</span></label>
                                <input type="date" name="payment_date" class="form-control" required>
                            </div>

                            <!-- ✅ Reference Number -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Reference Number</label>
                                <input type="text" name="ref_number" class="form-control"
                                    placeholder="Enter Reference Number">
                            </div>

                            <!-- ✅ Upload Payment Proof -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Upload Payment Proof</label>
                                <input type="file" name="payment_proof" class="form-control">
                            </div>

                            <!-- ✅ Note -->
                            <div class="col-12">
                                <label class="form-label fw-semibold">Note</label>
                                <textarea name="note" rows="3" class="form-control"
                                    placeholder="Enter remarks or notes"></textarea>
                            </div>
                        </div>
                    </form>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" form="recordPaymentForm" class="btn btn-primary">Save Payment</button>
                </div>
            </div>
        </div>
    </div>

    @include('super_admin.includes.footer_links')
</body>

</html>

<!-- JS Section -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {

        // 🧹 DELETE CONFIRMATION
        document.querySelectorAll(".delete-btn").forEach(btn => {
            btn.addEventListener("click", function () {
                const paymentId = this.getAttribute("data-id");
                Swal.fire({
                    title: "Are you sure?",
                    text: "This payment will be moved to trash.",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#BE3117",
                    cancelButtonColor: "#6c757d",
                    confirmButtonText: "Yes, delete it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = `/outward-payment/delete/${paymentId}`;
                    }
                });
            });
        });

        // 🧮 LIVE SEARCH FILTER
        const searchCompany = document.getElementById("searchCompany");
        const searchVendor = document.getElementById("searchVendor");
        const searchStatus = document.getElementById("searchStatus");
        const resetFilter = document.getElementById("resetFilter");

        function filterTable() {
            const companyVal = searchCompany.value.toLowerCase();
            const vendorVal = searchVendor.value.toLowerCase();
            const statusVal = searchStatus.value.toLowerCase();

            document.querySelectorAll("#paymentTableBody tr").forEach(row => {
                const company = row.cells[2]?.innerText.toLowerCase() || "";
                const vendor = row.cells[3]?.innerText.toLowerCase() || "";
                const status = row.cells[9]?.innerText.toLowerCase() || "";
                const match =
                    (!companyVal || company.includes(companyVal)) &&
                    (!vendorVal || vendor.includes(vendorVal)) &&
                    (!statusVal || status.includes(statusVal));
                row.style.display = match ? "" : "none";
            });
        }

        [searchCompany, searchVendor, searchStatus].forEach(input =>
            input.addEventListener("input", filterTable)
        );

        resetFilter.addEventListener("click", () => {
            searchCompany.value = "";
            searchVendor.value = "";
            searchStatus.value = "";
            filterTable();
        });

        // ✅ MODAL FIELD POPULATION FIX
        const recordPaymentModal = document.getElementById("recordPaymentModal");
        recordPaymentModal.addEventListener("show.bs.modal", function (event) {
            const button = event.relatedTarget; // Button that triggered the modal

            if (!button) return;

            const paymentId = button.getAttribute("data-id");
            const companyName = button.getAttribute("data-company");
            const totalAmount = button.getAttribute("data-total");
            const balance = button.getAttribute("data-balance");

            // Fill the modal inputs
            document.getElementById("paymentIdField").value = paymentId;
            document.getElementById("companyNameField").value = companyName;
            document.getElementById("totalAmountField").value = totalAmount;
            document.getElementById("balanceAmountField").value = balance;

            // Set form action dynamically
            const form = document.getElementById("recordPaymentForm");
            form.action = `/outward-payment/record/${paymentId}`;
        });

    });
</script>
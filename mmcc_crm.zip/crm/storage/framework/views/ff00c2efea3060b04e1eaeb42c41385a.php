<!-- <link rel="icon" href="img/favicon.png" type="image/x-icon"> -->
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Bootstrap Icons CDN with local fallback -->
<link href="<?php echo e(asset('css/bootstrap-icons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" />

<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>"><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/includes/header_links.blade.php ENDPATH**/ ?>
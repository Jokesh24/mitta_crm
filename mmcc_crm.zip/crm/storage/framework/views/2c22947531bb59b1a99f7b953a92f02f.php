<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>CRM Dashboard - Corporate View</title>



  <!-- Your existing header links (Bootstrap, etc.) -->
  <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



</head>

<body>
  <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


  <div class="content">
    <!-- ====================== TOP SECTION ====================== -->
    <div class="dashboard-row">
      <div class="row g-3">
        <!-- LEFT SIDE -->
        <div class="col-md-8">
          <div class="row g-3">
            <!-- 6 Info Cards -->
            <div class="col-md-4">
              <div class="info-card">
                <div>
                  <h6>Total Companies</h6>
                  <p>3000+</p>
                </div>
                <div class="info-icon"><i class="bi bi-buildings"></i></div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="info-card">
                <div>
                  <h6>Total Employees</h6>
                  <p>1560+</p>
                </div>
                <div class="info-icon"><i class="bi bi-person-workspace"></i></div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="info-card">
                <div>
                  <h6>Total Payments</h6>
                  <p>₹3,50,000</p>
                </div>
                <div class="info-icon"><i class="bi bi-cash-stack"></i></div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="info-card">
                <div>
                  <h6>Total Vendors</h6>
                  <p>1265+</p>
                </div>
                <div class="info-icon"><i class="bi bi-person-badge"></i></div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="info-card">
                <div>
                  <h6>Total Branches</h6>
                  <p>250+</p>
                </div>
                <div class="info-icon"><i class="bi bi-geo-alt"></i></div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="info-card">
                <div>
                  <h6>Total Revenue</h6>
                  <p>₹5,80,000</p>
                </div>
                <div class="info-icon"><i class="bi bi-currency-rupee"></i></div>
              </div>
            </div>
          </div>

          <!-- Stats Section -->
          <div class="stats-container">
            <div class="stats-box">
              <h6>In-Word Stats</h6>
              <div class="row g-3">
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-orange">Total Amount</h6>
                    <p>₹3,60,000</p>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-blue">Paid Amount</h6>
                    <p>₹50,000</p>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-green">Discount</h6>
                    <p>₹1,000</p>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-pink">Balance</h6>
                    <p>₹3,00,000</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="stats-box">
              <h6>Out-Word Stats</h6>
              <div class="row g-3">
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-orange">Total Amount</h6>
                    <p>₹3,60,000</p>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-blue">Paid Amount</h6>
                    <p>₹50,000</p>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-green">Discount</h6>
                    <p>₹1,000</p>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="amount-item">
                    <h6 class="label-pink">Balance</h6>
                    <p>₹3,00,000</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- RIGHT SIDE -->
        <div class="col-md-4">
          <!-- In-Word Reminder -->
          <div class="reminder-box mb-4">
            <div class="reminder-header d-flex justify-content-between align-items-center mb-2">
              <h6 class="m-0">In-Word Reminder</h6>
              <button class="btn btn-sm btn-light dropdown-toggle" data-bs-toggle="dropdown">
                <i class="bi bi-calendar-event me-1"></i> This week
              </button>
            </div>

            <div class="table-responsive">
              <table class="table table-sm align-middle">
                <thead class="table-light">
                  <tr>
                    <th>Vendor</th>
                    <th>Balance</th>
                    <th>Due date</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Richlabz</td>
                    <td>1,00,000</td>
                    <td><button class="btn-due">10-11-2025</button></td>
                    <td><button class="btn-send">Send Reminder</button></td>
                  </tr>
                  <tr>
                    <td>Slifax</td>
                    <td>50,000</td>
                    <td><button class="btn-due">10-11-2025</button></td>
                    <td><button class="btn-send">Send Reminder</button></td>
                  </tr>
                  <tr>
                    <td>Dr Cita</td>
                    <td>28,000</td>
                    <td>15-11-2025</td>
                    <td><button class="btn-send">Send Reminder</button></td>
                  </tr>
                  <tr>
                    <td>Yoskool</td>
                    <td>50,000</td>
                    <td>28-11-2025</td>
                    <td><button class="btn-send">Send Reminder</button></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <a href="#" class="view-all d-block text-end mt-2 text-decoration-none">View all</a>
          </div>

          <!-- Out-Word Reminder -->
          <div class="reminder-box">
            <div class="reminder-header d-flex justify-content-between align-items-center mb-2">
              <h6 class="m-0">Out-Word Reminder</h6>
              <button class="btn btn-sm btn-light dropdown-toggle" data-bs-toggle="dropdown">
                <i class="bi bi-calendar-event me-1"></i> This week
              </button>
            </div>

            <div class="table-responsive">
              <table class="table table-sm align-middle">
                <thead class="table-light">
                  <tr>
                    <th>Vendor</th>
                    <th>Total</th>
                    <th>Paid</th>
                    <th>Bal</th>
                    <th>Due date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Richlabz</td>
                    <td>10,000</td>
                    <td class="text-success">5600</td>
                    <td class="text-danger">3400</td>
                    <td>10-11-2025</td>
                  </tr>
                  <tr>
                    <td>Slifax</td>
                    <td>5,000</td>
                    <td class="text-success">1500</td>
                    <td class="text-danger">3500</td>
                    <td>22-11-2025</td>
                  </tr>
                  <tr>
                    <td>Richlabz</td>
                    <td>10,000</td>
                    <td class="text-success">5600</td>
                    <td class="text-danger">3400</td>
                    <td>10-11-2025</td>
                  </tr>
                  <tr>
                    <td>Yoskool</td>
                    <td>5,000</td>
                    <td class="text-success">1500</td>
                    <td class="text-danger">3500</td>
                    <td>22-11-2025</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <a href="#" class="view-all d-block text-end mt-2 text-decoration-none">View all</a>
          </div>
        </div>

      </div>
    </div>






    <!-- ====================== EMPLOYEE SECTION ====================== -->
    <!-- ====================== EMPLOYEE SECTION ====================== -->

    <div class="dashboard-section">

      <!-- Employee Attendance -->
      <div class="card">
        <div class="card-header">
          <span>Employee Attendance</span>
          <button class="btn-today"><i class="bi bi-calendar"></i> Today</button>
        </div>
        <div class="card-body">
          <!-- Employee Items -->
          <div class="employee-item">
            <div class="employee-info">
              <img src="https://i.pravatar.cc/45?img=11" alt="">
              <div>
                <div class="employee-name">KNS Reddy</div>
                <div class="employee-role">UI/UX Designer</div>
              </div>
            </div>
            <span class="time-badge">09:15 AM</span>
          </div>

          <div class="employee-item">
            <div class="employee-info">
              <img src="https://i.pravatar.cc/45?img=12" alt="">
              <div>
                <div class="employee-name">Akeeb Shaik</div>
                <div class="employee-role">Project Manager</div>
              </div>
            </div>
            <span class="time-badge">09:36 AM</span>
          </div>

          <div class="employee-item flex-column align-items-start">
            <div class="d-flex justify-content-between w-100 align-items-center">
              <div class="employee-info">
                <img src="https://i.pravatar.cc/45?img=13" alt="">
                <div>
                  <div class="employee-name">Praveen Saaho</div>
                  <div class="employee-role">PHP Developer</div>
                </div>
              </div>
              <span class="time-badge">09:36 AM</span>
            </div>

            <!-- Modified Production Box -->
            <div class="production-box w-100">
              <div class="production-item">
                <div class="d-flex align-items-center"> <span class="dot green"></span>
                  <div class="label">Clock In</div>
                </div>
                <div class="time">09:30 AM</div>
              </div>
              <div class="production-item">
                <div class="d-flex align-items-center">
                  <span class="dot red"></span>
                  <div class="label">Clock Out</div>
                </div>
                <div class="time">07:30 PM</div>
              </div>
              <div class="production-item">
                <div class="d-flex align-items-center">
                  <span class="dot blue"></span>
                  <div class="label">Production</div>
                </div>
                <div class="time">10.00 Hrs</div>
              </div>
            </div>
          </div>

          <div class="late-box">
            <div class="employee-info">
              <img src="https://i.pravatar.cc/45?img=15" alt="">
              <div>
                <div class="employee-name">Bhagyesh Bagh</div>
                <div class="employee-role">Project Manager</div>
              </div>
            </div>
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span class="late-time">30 Min</span>
              <span class="time-badge late">10:30 AM</span>
            </div>
          </div>

          <div class="view-btn">View all attendance</div>
        </div>
      </div>

      <!-- Employee Status -->
      <div class="card">
        <div class="card-header">
          <span>Employee Status</span>
          <button class="btn-week"><i class="bi bi-calendar-week"></i> This Week</button>
        </div>
        <div class="card-body">
          <div class="status-heading d-flex align-items-center  justify-content-between">
            <p>Total Employees</p>
            <h4>2546</h4>
          </div>
          <div class="status-bar">
            <div class="bar-segment fulltime"></div>
            <div class="bar-segment contract"></div>
            <div class="bar-segment probation"></div>
            <div class="bar-segment wfh"></div>
          </div>

          <div class="status-box mt-3">
            <div>Fulltime (48%) <br><b>1252</b></div>
            <div>Contract (20%) <br><b>563</b></div>
            <div>Probation (22%) <br><b>256</b></div>
            <div>WFH (20%) <br><b>110</b></div>
          </div>

          <div class="top-performer mt-4">
            <div class="d-flex align-items-center gap-2">
              <img src="https://i.pravatar.cc/45?img=15" alt="">
              <div>
                <div class="employee-name mb-0">Bhagyesh Bagh</div>
                <div class="employee-role">Project Manager</div>
              </div>
            </div>
            <span class="performance">Performance 98%</span>
          </div>

          <div class="view-btn">View all Employees</div>
        </div>
      </div>

      <!-- Attendance Overview -->
      <div class="card">
        <div class="card-header">
          <span>Attendance Overview</span>
          <button class="btn-today"><i class="bi bi-calendar"></i> Today</button>
        </div>
        <div class="card-body text-center">
          <div class="chart-container">
            <canvas id="attendanceChart"></canvas>
          </div>
          <div class="attendance-details">
            <p class="mb-1">Total Attendance</p>
            <span>2260</span>
          </div>
          <ul class="legend-list mt-3">
            <li><span><span class="legend-dot present"></span> Present</span> 59%</li>
            <li><span><span class="legend-dot late"></span> Late</span> 21%</li>
            <li><span><span class="legend-dot permission"></span> Permission</span> 15%</li>
            <li><span><span class="legend-dot absent"></span> Absent</span> 2%</li>
          </ul>
          <div class="view-btn">View details</div>
        </div>
      </div>

    </div>











    <!-- ====================== WORD OVERVIEW SECTION ====================== -->
    <div class="word-overview-section">

      <!-- In-Word Bar Chart -->
      <div class="card">
        <div class="card-header"><span>In-Word Overview</span>
          <div class="d-flex align-items-center gap-2">

            <button class="btn-year"><i class="bi bi-calendar"></i> 2025</button>
          </div>
        </div>
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center small text-muted mb-4">
            <div class="text-success small fw-semibold"><i class="bi bi-arrow-up-right"></i> 40% increased from last
              year</div>
            <div>
              <span class="dot inword"></span> In-word
            </div>
          </div>
          <canvas id="inWordChart" height="250"></canvas>
        </div>
      </div>

      <!-- Out-Word Bar Chart -->
      <div class="card">
        <div class="card-header"><span>Out-Word Overview</span>
          <div class="d-flex align-items-center gap-2">

            <button class="btn-year"><i class="bi bi-calendar"></i> 2025</button>
          </div>
        </div>
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center small text-muted mb-4">
            <div class="text-success small fw-semibold"><i class="bi bi-arrow-up-right"></i> 40% increased from last
              year</div>
            <div> <span class="dot outword"></span> Out-word</div>
          </div>
          <canvas id="outWordChart" height="250"></canvas>
        </div>
      </div>

    </div>
  </div>

  <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

<!-- ====================== CHART INITIALISATION ====================== -->
<script>
  // 1. Doughnut – Attendance Overview
  const attCtx = document.getElementById('attendanceChart').getContext('2d');
  new Chart(attCtx, {
    type: 'doughnut',
    data: {
      labels: ['Present', 'Late', 'Permission', 'Absent'],
      datasets: [{
        data: [59, 21, 15, 2],
        backgroundColor: ['#007bff', '#198754', '#ffb703', '#f03e3e'],
        borderWidth: 0
      }]
    },
    options: {
      cutout: '70%',
      plugins: {
        legend: {
          display: false
        }
      },
      maintainAspectRatio: false
    }
  });


  // 2. Bar – In-Word Overview
  // In-Word Chart
  const inWordCtx = document.getElementById('inWordChart').getContext('2d');
  new Chart(inWordCtx, {
    type: 'bar',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [{
        label: 'In-Word',
        data: [20, 25, 45, 70, 80, 95, 75, 65, 45, 40, 25, 30],
        backgroundColor: '#006d77',
        borderRadius: 6,
        maxBarThickness: 25
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false, // keeps height fixed
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: '#f1f1f1'
          },
          ticks: {
            stepSize: 20,
            color: '#999',
            callback: val => val + 'K'
          }
        },
        x: {
          grid: {
            display: false
          },
          ticks: {
            color: '#888'
          }
        }
      }
    }
  });


  // Out-Word Chart
  const outWordCtx = document.getElementById('outWordChart').getContext('2d');
  new Chart(outWordCtx, {
    type: 'bar',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [{
        label: 'Out-Word',
        data: [50, 85, 25, 100, 85, 70, 85, 60, 85, 30, 100, 85],
        backgroundColor: '#ff4500',
        borderRadius: 6,
        maxBarThickness: 25
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: '#f1f1f1'
          },
          ticks: {
            stepSize: 20,
            color: '#999',
            callback: val => val + 'K'
          }
        },
        x: {
          grid: {
            display: false
          },
          ticks: {
            color: '#888'
          }
        }
      }
    }
  });
</script>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/index.blade.php ENDPATH**/ ?>
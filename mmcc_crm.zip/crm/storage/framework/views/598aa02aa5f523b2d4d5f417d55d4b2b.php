<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Manage Companies</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Manage Companies</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i>
                            </a>

                            <!-- Export Dropdown -->
                            <div class="dropdown me-1">
                                <a href="javascript:void(0);" class="dropdown-toggle btn btn-white border-1"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li><a href="#" class="dropdown-item"><i class="bi bi-file-earmark-pdf me-1"></i>
                                            Export as PDF</a></li>
                                    <li><a href="#" class="dropdown-item"><i class="bi bi-file-earmark-excel me-1"></i>
                                            Export as Excel</a></li>
                                </ul>
                            </div>

                            <!-- Add Company -->
                            <a href="<?php echo e(route('add-company')); ?>" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add New Company
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- STAT CARDS -->
        <div class="row g-3">
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-dark rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-people text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Total Companies</p>
                                <h4 class="fw-bold mb-0"><?php echo e($totalCompanies); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-success rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-person-check text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Active</p>
                                <h4 class="fw-bold mb-0"><?php echo e($activeCount); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-danger rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-person-dash text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Inactive</p>
                                <h4 class="fw-bold mb-0"><?php echo e($inactiveCount); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-primary rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-trash text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Trash</p>
                                <h4 class="fw-bold mb-0"><?php echo e($trashedCount); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- COMPANIES TABLE -->
        <div class="card shadow-sm border-bottom mt-3 company">
            <div class="border-bottom">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">

                        <h5 class="fw-semibold mb-0">Companies List</h5>

                        <!-- Filters -->
                        <form class="d-flex align-items-center flex-wrap justify-content-end gap-2"
                            onsubmit="return false;">
                            <!-- Search -->
                            <input type="text" id="companySearch" class="form-control"
                                placeholder="Search by name, email, mobile or GST" style="width:210px;">

                            <!-- Status -->
                            <select id="statusFilter" class="form-select" style="width:160px;">
                                <option value="">Select Status</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>

                            <button type="button" class="btn btn-light border-1" id="resetFilters">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                        </form>


                    </div>
                </div>
            </div>

            <!-- TABLE -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th><input type="checkbox" class="form-check-input"></th>
                                <th>Company Logo</th>
                                <th>Company Name</th>
                                <th>Company Email</th>
                                <th>Mobile Number</th>
                                <th>GST Number</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><input type="checkbox" class="form-check-input"></td>
                                    <td>
                                        <?php if($company->company_logo): ?>
                                            <img src="<?php echo e(asset($company->company_logo)); ?>" alt="Logo" class="rounded-circle"
                                                width="40" height="40">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('img/default-logo.png')); ?>" alt="Logo" class="rounded-circle"
                                                width="40" height="40">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($company->company_name); ?></td>
                                    <td><?php echo e($company->company_email); ?></td>
                                    <td><?php echo e($company->mobile_number ?? '-'); ?></td>
                                    <td><?php echo e($company->gst_number ?? '-'); ?></td>
                                    <td>
                                        <?php if($company->status == 'active'): ?>
                                            <span
                                                class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">Active</span>
                                        <?php else: ?>
                                            <span
                                                class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('edit-company', $company->id)); ?>" class="text-primary me-2"
                                            title="Edit">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="<?php echo e(route('delete-company', $company->id)); ?>" class="text-danger me-2"
                                            title="Delete"
                                            onclick="return confirm('Are you sure you want to move this company to trash?');">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                        <a href="<?php echo e(route('view-company', $company->id)); ?>" class="text-success me-2"
                                            title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted py-4">No companies found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const searchInput = document.getElementById("companySearch");
        const statusFilter = document.getElementById("statusFilter");
        const resetButton = document.getElementById("resetFilters");
        const tableRows = document.querySelectorAll(".table tbody tr");

        function filterTable() {
            const searchValue = searchInput.value.toLowerCase().trim();
            const statusValue = statusFilter.value.toLowerCase();

            tableRows.forEach(row => {
                const name = row.children[3]?.textContent.toLowerCase() || '';
                const email = row.children[4]?.textContent.toLowerCase() || '';
                const mobile = row.children[5]?.textContent.toLowerCase() || '';
                const gst = row.children[6]?.textContent.toLowerCase() || '';
                const statusText = row.children[7]?.textContent.toLowerCase() || '';

                // Match conditions
                const matchesSearch =
                    name.includes(searchValue) ||
                    email.includes(searchValue) ||
                    mobile.includes(searchValue) ||
                    gst.includes(searchValue);

                const matchesStatus = !statusValue || statusText.includes(statusValue);

                if (matchesSearch && matchesStatus) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }

        // Event listeners
        searchInput.addEventListener("keyup", filterTable);
        statusFilter.addEventListener("change", filterTable);

        resetButton.addEventListener("click", () => {
            searchInput.value = "";
            statusFilter.value = "";
            filterTable();
        });
    });
</script><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/manage_company.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>



    <!-- Your existing header links (Bootstrap, etc.) -->
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row  mb-3">
            <div class="col-lg-12">
                <div class="card border-0 ">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Employee Details
                        </h5>
                        <div> <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>
                            <a href="employee_list.php" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Employee
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Employee Card -->
        <!-- Employee Details Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">

                        <!-- ================= EMPLOYEE DETAILS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-person-badge me-1"></i> Employee Details
                            </h4>
                        </div>

                        <div class="mb-4">
                            <!-- Row 1 -->
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Employee ID:</strong> EMP001</div>
                                <div class="col-md-4"><strong>Employee Name:</strong> John Doe</div>
                                <div class="col-md-4"><strong>Department:</strong> Development</div>
                            </div>

                            <!-- Row 2 -->
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Designation:</strong> Software Engineer</div>
                                <div class="col-md-4"><strong>Email ID:</strong> john.doe@example.com</div>
                                <div class="col-md-4"><strong>Mobile Number:</strong> 9876543210</div>
                            </div>

                            <!-- Row 3 -->
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Date of Joining:</strong> 15/02/2022</div>
                                <div class="col-md-4"><strong>Aadhaar Number:</strong> 1234 5678 9012</div>
                                <div class="col-md-4"><strong>PAN Number:</strong> ABCDE1234F</div>
                            </div>

                            <!-- Row 4 -->
                            <div class="row mb-2 align-items-center">
                                <div class="col-md-4">
                                    <strong>Aadhaar Proof:</strong>
                                    <a href="uploads/aadhaar.pdf" target="_blank"
                                        class="text-decoration-none text-primary">
                                        <i class="bi bi-file-earmark-text me-1"></i> View Proof
                                    </a>
                                </div>
                                <div class="col-md-4">
                                    <strong>PAN Proof:</strong>
                                    <a href="uploads/pan.pdf" target="_blank" class="text-decoration-none text-primary">
                                        <i class="bi bi-file-earmark-text me-1"></i> View Proof
                                    </a>
                                </div>
                                <div class="col-md-4">
                                    <strong>Reporting Manager:</strong> Jane Smith
                                </div>
                            </div>
                        </div>

                        <!-- ================= ADDRESS DETAILS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-geo-alt me-1"></i> Address Details
                            </h4>
                        </div>

                        <div class="mb-4">
                            <div class="row mb-2">
                                <div class="col-md-6">
                                    <strong>Present Address:</strong>
                                    <div class="">
                                        123, ABC Residency, Madhapur, Hyderabad - 500081
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <strong>Permanent Address:</strong>
                                    <div class="">
                                        45, XYZ Colony, Kukatpally, Hyderabad - 500072
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- ================= DOCUMENTS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-card-image me-1"></i> Employee Photo & ID
                            </h4>
                        </div>

                        <div class="mb-4">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <strong>Employee Photo:</strong><br>
                                    <img src="img/employee-photo.jpg" width="80" class="rounded border mt-2">
                                </div>
                                <div class="col-md-4">
                                    <strong>Company ID Card:</strong><br>
                                    <img src="img/id-card.png" width="100" class="rounded border mt-2">
                                </div>
                            </div>
                        </div>

                        <!-- ================= BUTTONS ================= -->
                        <div class="mt-4 d-flex justify-content-end gap-2">
                            <a href="edit-employee.php" class="btn btn-primary px-4">
                                <i class="bi bi-pencil-square me-1"></i> Edit
                            </a>
                            <a href="manage-employee.php" class="btn btn-outline-secondary px-4">
                                Back
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>



    </div>
    <script>
        flatpickr("#joiningDate", {
            dateFormat: "d/m/Y",
            allowInput: true
        });
    </script>
    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>



</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/view_employee.blade.php ENDPATH**/ ?>
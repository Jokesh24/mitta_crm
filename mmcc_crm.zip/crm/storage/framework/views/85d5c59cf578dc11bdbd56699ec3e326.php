<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>



    <!-- Your existing header links (Bootstrap, etc.) -->
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Create New Employee</h5>
                        <div>
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" aria-label="Back" data-bs-original-title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>
                            <a href="employee_list.php" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Employees
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lead Form Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="#" novalidate>
                            <div class="row g-4 mb-4">
                                <!-- Employee ID -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Employee ID <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Employee ID" required>
                                </div>

                                <!-- Employee Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Employee Name <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Employee Name" required>
                                </div>

                                <!-- Department -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Department <span
                                            class="text-danger">*</span></label>
                                    <select class="form-select" required>
                                        <option value="">Select Department</option>
                                        <option>HR</option>
                                        <option>Sales</option>
                                        <option>Development</option>
                                        <option>Finance</option>
                                    </select>
                                </div>

                                <!-- Designation -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Designation <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Designation" required>
                                </div>

                                <!-- Email -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Email ID <span
                                            class="text-danger">*</span></label>
                                    <input type="email" class="form-control" placeholder="Enter Email Address" required>
                                </div>

                                <!-- Mobile Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Mobile Number <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Mobile Number" required>
                                </div>

                                <!-- Joining Date -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Date of Joining <span
                                            class="text-danger">*</span></label>
                                    <input type="" id="joiningDate" class="form-control" placeholder="Enter Date">
                                </div>

                                <!-- Employment Type -->


                                <!-- Aadhaar Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Aadhaar Number <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" maxlength="12"
                                        placeholder="Enter 12-digit Aadhaar Number" required>
                                </div>

                                <!-- PAN Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">PAN Number <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" maxlength="10"
                                        placeholder="Enter PAN Number" required>
                                </div>

                                <!-- Aadhaar Proof Upload -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Upload Aadhaar Proof <span
                                            class="text-danger">*</span></label>
                                    <input type="file" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                                    <small class="text-muted">Accepted formats: JPG, PNG, PDF (max 2MB)</small>
                                </div>

                                <!-- PAN Proof Upload -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Upload PAN Proof <span
                                            class="text-danger">*</span></label>
                                    <input type="file" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                                    <small class="text-muted">Accepted formats: JPG, PNG, PDF (max 2MB)</small>
                                </div>
                                <!-- Address -->
                                <div class="col-6 mt-3">
                                    <label class="form-label fw-semibold">Present Address <span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" placeholder="Enter Present Address"
                                        required></textarea>
                                </div>

                                <!-- Permanent Address -->
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Permanent Address <span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" placeholder="Enter Permanent Address"
                                        required></textarea>


                                </div>
                            </div>

                            <!-- Buttons -->
                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
                                <button type="submit" class="btn btn-primary px-4">Submit</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        flatpickr("#joiningDate", {
            dateFormat: "d/m/Y",
            allowInput: true
        });
    </script>
    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>



</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/add_employee.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>
    <!-- Your existing header links (Bootstrap, etc.) -->
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row  mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Manage Leads</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>

                            <!-- Custom CSS for tooltip -->
                            <!-- Export Dropdown -->
                            <div class="dropdown me-1 ">
                                <a href="javascript:void(0);"
                                    class="dropdown-toggle btn btn-white border-1 d-inline-flex align-items-center"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-pdf me-1"></i> Export as PDF
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-excel me-1"></i> Export as Excel
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Add New Company Button -->
                            <a href="<?php echo e(route('add-lead')); ?>" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add New Lead
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="card shadow-sm border-bottom mt-3 company">
            <!-- HEADER -->
            <div class="border-bottom ">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">

                        <!-- Title -->
                        <h5 class="fw-semibold mb-0">Leads List</h5>

                        <!-- Filters Section -->
                        <div class="d-flex align-items-center flex-wrap justify-content-end gap-2">

                            <!-- Date Range -->
                            <input type="text" class="form-control" placeholder="Search by " style="width:210px;">

                            <!-- Designation -->
                            <select class="form-select" style="width:160px;">
                                <option>Designation</option>
                                <option>Finance</option>
                                <option>Developer</option>
                                <option>Executive</option>
                            </select>

                            <!-- Status -->
                            <select class="form-select" style="width:160px;">
                                <option>Select Status</option>
                                <option>Active</option>
                                <option>Inactive</option>
                            </select>

                            <button class="btn btn-primary text-white me-1">
                                <i class="bi bi-search"></i>
                            </button>

                            <button class="btn btn-light border-1">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>

                        </div>
                    </div>
                </div>
            </div>
            <!-- TABLE -->
            <div class="card-body">
                <div class="table-responsive">
                    <div class="table-responsive">
                        <table class="table align-middle table-hover table-striped mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th><input type="checkbox" class="form-check-input"></th>
                                    <th>Team Member</th>
                                    <th>Mobile Number</th>
                                    <th>Customer Name</th>
                                    <th>Last Update</th>
                                    <th>Follow-Up Date & Time</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Row 1 -->
                                <tr>
                                    <td>1</td>
                                    <td><input type="checkbox" class="form-check-input"></td>
                                    <td>Alpha Tech</td>
                                    <td>9876543210</td>
                                    <td>John Doe</td>
                                    <td>06-11-2025</td>
                                    <td>08-11-2025 • 03:30 PM</td>
                                    <td>
                                        <span
                                            class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">Active</span>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger me-1" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        <a href="<?php echo e(route('leade-details')); ?>" class="btn btn-sm btn-outline-info"
                                            title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <div class="dropdown d-inline">
                                            <a href="#" class="text-secondary" id="moreDropdown3"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="bi bi-three-dots"></i>
                                            </a>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="moreDropdown3">
                                                <li><a class="dropdown-item" href="#">Action 1</a></li>
                                                <li><a class="dropdown-item" href="#">Action 2</a></li>
                                                <li><a class="dropdown-item" href="#">Action 3</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Row 2 -->
                                <tr>
                                    <td>2</td>
                                    <td><input type="checkbox" class="form-check-input"></td>
                                    <td>Beta Innovations</td>
                                    <td>9988776655</td>
                                    <td>Jane Smith</td>
                                    <td>25-10-2025</td>
                                    <td>10-11-2025 • 10:00 AM</td>
                                    <td>
                                        <span
                                            class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2">Inactive</span>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger me-1" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        <a href="<?php echo e(route('leade-details')); ?>" class="btn btn-sm btn-outline-info"
                                            title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <div class="dropdown d-inline">
                                            <a href="#" class="text-secondary" id="moreDropdown3"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="bi bi-three-dots"></i>
                                            </a>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="moreDropdown3">
                                                <li><a class="dropdown-item" href="#">Action 1</a></li>
                                                <li><a class="dropdown-item" href="#">Action 2</a></li>
                                                <li><a class="dropdown-item" href="#">Action 3</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Row 3 -->
                                <tr>
                                    <td>3</td>
                                    <td><input type="checkbox" class="form-check-input"></td>
                                    <td>Gamma Solutions</td>
                                    <td>9090909090</td>
                                    <td>Robert Lee</td>
                                    <td>01-11-2025</td>
                                    <td>09-11-2025 • 01:15 PM</td>
                                    <td>
                                        <span
                                            class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">Active</span>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger me-1" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        <a href="<?php echo e(route('leade-details')); ?>" class="btn btn-sm btn-outline-info"
                                            title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <div class="dropdown d-inline">
                                            <a href="#" class="text-secondary" id="moreDropdown3"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="bi bi-three-dots"></i>
                                            </a>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="moreDropdown3">
                                                <li><a class="dropdown-item" href="#">Action 1</a></li>
                                                <li><a class="dropdown-item" href="#">Action 2</a></li>
                                                <li><a class="dropdown-item" href="#">Action 3</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>

                <!-- Pagination -->
                <nav aria-label="Company table pagination">
                    <ul class="pagination justify-content-end mt-3">
                        <li class="page-item disabled">
                            <a class="page-link" href="#"><i class="bi bi-chevron-left"></i></a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#"><i class="bi bi-chevron-right"></i></a>
                        </li>
                    </ul>
                </nav>
            </div>

        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/manage_lead.blade.php ENDPATH**/ ?>
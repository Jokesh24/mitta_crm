<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Manage Vendors</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Manage Vendors</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i>
                            </a>

                            <!-- Export Dropdown -->
                            <div class="dropdown me-1">
                                <a href="javascript:void(0);" class="dropdown-toggle btn btn-white border-1"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li><a href="#" class="dropdown-item"><i class="bi bi-file-earmark-pdf me-1"></i>
                                            Export as PDF</a></li>
                                    <li><a href="#" class="dropdown-item"><i class="bi bi-file-earmark-excel me-1"></i>
                                            Export as Excel</a></li>
                                </ul>
                            </div>

                            <!-- Add Vendor -->
                            <a href="<?php echo e(route('add-vendor')); ?>" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add New Vendor
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- STAT CARDS -->
        <div class="row g-3">
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-dark rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-people text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Total Vendors</p>
                                <h4 class="fw-bold mb-0"><?php echo e($totalVendors); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-success rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-person-check text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Active</p>
                                <h4 class="fw-bold mb-0"><?php echo e($activeCount); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-danger rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-person-dash text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Inactive</p>
                                <h4 class="fw-bold mb-0"><?php echo e($inactiveCount); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <span
                                class="avatar bg-primary rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-trash text-white fs-4"></i>
                            </span>
                            <div class="ms-3">
                                <p class="fs-6 mb-1">Trashed</p>
                                <h4 class="fw-bold mb-0"><?php echo e($trashedCount); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <?php if(session('success')): ?>
            <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger mt-3"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <!-- VENDORS TABLE -->
        <div class="card shadow-sm border-bottom mt-3">
            <div class="border-bottom">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <h5 class="fw-semibold mb-0">Vendors List</h5>

                        <!-- Filters -->
                        <form class="d-flex align-items-center flex-wrap justify-content-end gap-2"
                            onsubmit="return false;">
                            <!-- Search -->
                            <input type="text" id="vendorSearch" class="form-control"
                                placeholder="Search by name, mobile, GST or PAN" style="width:210px;">

                            <!-- Vendor Type -->
                            <select id="vendorTypeFilter" class="form-select" style="width:160px;">
                                <option value="">Select Type</option>
                                <option value="inward">Inward</option>
                                <option value="outward">Outward</option>
                            </select>

                            <!-- Status -->
                            <select id="statusFilter" class="form-select" style="width:160px;">
                                <option value="">Select Status</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>

                            <!-- Reset -->
                            <button type="button" class="btn btn-light border-1" id="resetFilters">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- TABLE -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Business Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>GST</th>
                                <th>PAN</th>
                                <th>Vendor Type</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="vendorTableBody">
                            <?php $__empty_1 = true; $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($vendor->business_name); ?></td>
                                    <td><?php echo e($vendor->email); ?></td>
                                    <td><?php echo e($vendor->mobile_number); ?></td>
                                    <td><?php echo e($vendor->gst_number ?? '-'); ?></td>
                                    <td><?php echo e($vendor->pan_number ?? '-'); ?></td>
                                    <td><?php echo e(ucfirst($vendor->vendor_type)); ?></td>
                                    <td><?php echo e($vendor->address); ?></td>
                                    <td>
                                        <span class="badge <?php echo e($vendor->status == 'active' ? 'bg-success' : 'bg-danger'); ?>">
                                            <?php echo e(ucfirst($vendor->status)); ?>

                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('edit-vendor', $vendor->id)); ?>" class="text-primary me-2"
                                            title="Edit">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>

                                        <a href="<?php echo e(route('delete-vendor', $vendor->id)); ?>" class="text-danger me-2"
                                            title="Delete"
                                            onclick="return confirm('Are you sure you want to move this vendor to trash?');">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10" class="text-center text-muted py-4">No vendors found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const searchInput = document.getElementById("vendorSearch");
        const vendorTypeFilter = document.getElementById("vendorTypeFilter");
        const statusFilter = document.getElementById("statusFilter");
        const resetButton = document.getElementById("resetFilters");
        const tableRows = document.querySelectorAll("#vendorTableBody tr");

        function filterTable() {
            const searchValue = searchInput.value.toLowerCase().trim();
            const typeValue = vendorTypeFilter.value.toLowerCase();
            const statusValue = statusFilter.value.toLowerCase();

            tableRows.forEach(row => {
                const name = row.children[1]?.textContent.toLowerCase().trim() || '';
                const mobile = row.children[3]?.textContent.toLowerCase().trim() || '';
                const gst = row.children[4]?.textContent.toLowerCase().trim() || '';
                const pan = row.children[5]?.textContent.toLowerCase().trim() || '';
                const type = row.children[6]?.textContent.toLowerCase().trim() || '';
                const statusText = row.children[8]?.innerText.toLowerCase().trim() || '';

                // ✅ Search filter (matches name, mobile, GST, PAN)
                const matchesSearch =
                    name.includes(searchValue) ||
                    mobile.includes(searchValue) ||
                    gst.includes(searchValue) ||
                    pan.includes(searchValue);

                // ✅ Vendor type filter
                const matchesType = !typeValue || type === typeValue;

                // ✅ Status filter (match partial text like “active” or “inactive”)
                const matchesStatus = !statusValue || statusText.includes(statusValue);

                // ✅ Show or hide row
                row.style.display = (matchesSearch && matchesType && matchesStatus) ? "" : "none";
            });
        }

        // ✅ Event listeners
        searchInput.addEventListener("keyup", filterTable);
        vendorTypeFilter.addEventListener("change", filterTable);
        statusFilter.addEventListener("change", filterTable);

        // ✅ Reset filters
        resetButton.addEventListener("click", () => {
            searchInput.value = "";
            vendorTypeFilter.value = "";
            statusFilter.value = "";
            filterTable();
        });
    });
</script><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/manage_vendors.blade.php ENDPATH**/ ?>
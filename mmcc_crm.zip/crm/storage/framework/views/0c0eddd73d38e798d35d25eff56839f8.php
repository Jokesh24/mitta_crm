<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>
    <!-- Your existing header links (Bootstrap, etc.) -->
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row  mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Manage Attendance</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>

                            <!-- Custom CSS for tooltip -->
                            <!-- Export Dropdown -->
                            <div class="dropdown me-1 ">
                                <a href="javascript:void(0);"
                                    class="dropdown-toggle btn btn-white border-1 d-inline-flex align-items-center"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-pdf me-1"></i> Export as PDF
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-excel me-1"></i> Export as Excel
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Add New Company Button -->
                            <!-- <a href="add_attendance.php" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add New Attendance
                            </a> -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row g-3">
            <!-- Total Employees -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-dark rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-people text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate">Present</p>
                                <h4 class="fw-bold mb-0">245</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Active Employees -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-success rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-person-check text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate">Late Login</p>
                                <h4 class="fw-bold mb-0">180</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- On Leave -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-warning rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-person-fill-exclamation text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate">Active</p>
                                <h4 class="fw-bold mb-0">35</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Inactive -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-danger rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-person-x text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate">Inactive</p>
                                <h4 class="fw-bold mb-0">30</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-bottom mt-3 company">
            <!-- HEADER -->
            <div class="border-bottom">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">

                        <!-- Title -->
                        <h5 class="fw-semibold mb-0"> Attendance Details Today</h5>

                        <!-- Filters Section -->
                        <div class="d-flex align-items-center flex-wrap justify-content-end gap-2">

                            <!-- Date Range -->
                            <input type="date" id="joiningDate" class="form-control" placeholder="Select Date"
                                style="width:200px;">

                            <!-- Department Filter -->
                            <select class="form-select" style="width:160px;">
                                <option>All Departments</option>
                                <option>HR</option>
                                <option>Development</option>
                                <option>Finance</option>
                                <option>Marketing</option>
                            </select>

                            <!-- Attendance Status -->
                            <select class="form-select" style="width:160px;">
                                <option>Select Status</option>
                                <option>Present</option>
                                <option>Absent</option>
                                <option>On Leave</option>
                            </select>

                            <button class="btn btn-primary text-white me-1">
                                <i class="bi bi-search"></i>
                            </button>

                            <button class="btn btn-light border-1">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>

                        </div>
                    </div>
                </div>
            </div>

            <!-- TABLE -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th><input type="checkbox" class="form-check-input"></th>
                                <th>Employee ID</th>
                                <th>Employee Name</th>
                                <th>Department</th>
                                <th>Date</th>
                                <th>Check-In</th>
                                <th>Check-Out</th>
                                <th>Total Hours</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>EMP001</td>
                                <td>Ravi Kumar</td>
                                <td>Development</td>
                                <td>2025-11-08</td>
                                <td>09:00 AM</td>
                                <td>06:15 PM</td>
                                <td>9h 15m</td>
                                <td>
                                    <span
                                        class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">Present</span>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger me-1" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info" title="View">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </td>
                            </tr>

                            <tr>
                                <td>2</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>EMP002</td>
                                <td>Neha Sharma</td>
                                <td>Finance</td>
                                <td>2025-11-08</td>
                                <td>—</td>
                                <td>—</td>
                                <td>0h</td>
                                <td>
                                    <span
                                        class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2">Absent</span>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger me-1" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info" title="View">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>EMP003</td>
                                <td>Ajay Mehta</td>
                                <td>HR</td>
                                <td>2025-11-08</td>
                                <td>09:30 AM</td>
                                <td>05:30 PM</td>
                                <td>8h 00m</td>
                                <td>
                                    <span
                                        class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-2">On
                                        Leave</span>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger me-1" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info" title="View">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav aria-label="Attendance pagination">
                    <ul class="pagination justify-content-end mt-3">
                        <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1">
                                <i class="bi bi-chevron-left"></i>
                            </a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#">
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

    </div>
    <script>
        flatpickr("#joiningDate", {
            dateFormat: "d/m/Y",
            allowInput: true
        });
    </script>
    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/attendance.blade.php ENDPATH**/ ?>
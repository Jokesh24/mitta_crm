<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>



    <!-- Your existing header links (Bootstrap, etc.) -->
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Lead Status Board</h5>
                        <!-- <div>
                            <a href="manage_lead.php" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Leads
                            </a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">

                        <!-- ================= LEAD DETAILS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-person-lines-fill me-1"></i> Lead Details
                            </h4>
                        </div>

                        <!-- Lead Information -->
                        <div class="mb-4 font">
                            <!-- Row 1 -->
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Lead Name:</strong> Ravi Kumar</div>
                                <div class="col-md-4"><strong>Company:</strong> Tech Vision Pvt Ltd</div>
                                <div class="col-md-4"><strong>Status:</strong> <span
                                        class="badge bg-warning text-dark">In Progress</span></div>
                            </div>

                            <!-- Row 2 -->
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Email:</strong> ravi.kumar@example.com</div>
                                <div class="col-md-4"><strong>Phone:</strong> +91 9876543210</div>
                                <div class="col-md-4"><strong>Lead Source:</strong> Website Form</div>
                            </div>

                            <!-- Row 3 -->
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Assigned To:</strong> Neha Sharma</div>
                                <div class="col-md-4"><strong>Follow-Up Date:</strong> 15/11/2025</div>
                                <div class="col-md-4"><strong>Lead Value:</strong> ₹45,000</div>
                            </div>

                            <!-- Row 4 -->
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Location:</strong> Hyderabad, India</div>
                                <div class="col-md-4"><strong>Category:</strong> Software Services</div>
                                <div class="col-md-4"><strong>Lead Type:</strong> B2B</div>
                            </div>

                            <!-- Row 5 -->
                            <div class="row mb-2">
                                <div class="col-md-12">
                                    <strong>Remarks:</strong>
                                    <span>Client interested in CRM system — proposal sent on 10/11/2025. Waiting for
                                        confirmation.</span>
                                </div>
                            </div>
                        </div>

                        <!-- ================= FOLLOW-UP HISTORY ================= -->
                        <!-- Follow-Up History Section -->
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-light border-bottom d-flex align-items-center">
                                <h5 class="fw-semibold text-primary mb-0">
                                    <i class="bi bi-chat-left-dots me-2"></i>Follow-Up History
                                </h5>
                            </div>

                            <div class="card-body">
                                <ul class="timeline list-unstyled mb-0">
                                    <li class="timeline-item mb-4 position-relative ps-4">
                                        <span class="timeline-dot"></span>
                                        <div>
                                            <h6 class="mb-1 fw-semibold text-dark"><span class="bg-light">15 Oct 2025
                                            </h6>
                                            <div class="my-3">
                                                <p class="mb-1"><i
                                                        class="bi bi-arrow-right-short text-primary  me-1"></i> Sent
                                                    proposal via email. Awaiting client response.</p>
                                                <p class="mb-0"><i
                                                        class="bi bi-arrow-right-short me-1 text-primary"></i> Shared
                                                    supporting documents and pricing details.</p>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="timeline-item mb-4 position-relative ps-4">
                                        <span class="timeline-dot"></span>
                                        <div>
                                            <h6 class="mb-1 fw-semibold text-dark"><span class="bg-light">15 Oct 2025
                                            </h6>
                                            <div class="my-3">
                                                <p class="mb-1"><i
                                                        class="bi bi-arrow-right-short text-primary  me-1"></i> Sent
                                                    proposal via email. Awaiting client response.</p>
                                                <p class="mb-0"><i
                                                        class="bi bi-arrow-right-short me-1 text-primary"></i> Shared
                                                    supporting documents and pricing details.</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="timeline-item mb-4 position-relative ps-4">
                                        <span class="timeline-dot"></span>
                                        <div>
                                            <h6 class="mb-1 fw-semibold text-dark"><span class="bg-light">15 Oct 2025
                                            </h6>
                                            <div class="my-3">
                                                <p class="mb-1"><i
                                                        class="bi bi-arrow-right-short text-primary  me-1"></i> Sent
                                                    proposal via email. Awaiting client response.</p>
                                                <p class="mb-0"><i
                                                        class="bi bi-arrow-right-short me-1 text-primary"></i> Shared
                                                    supporting documents and pricing details.</p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- ================= ATTACHMENTS ================= -->


                        <!-- ================= ACTION BUTTONS ================= -->
                        <div class="mt-4 d-flex justify-content-end gap-2">
                            <a href="edit-lead.php" class="btn btn-primary px-4">
                                <i class="bi bi-pencil-square me-1"></i> Edit
                            </a>
                            <a href="followup-lead.php" class="btn btn-success px-4">
                                <i class="bi bi-plus-circle me-1"></i> Add Follow-Up
                            </a>
                            <a href="manage-leads.php" class="btn btn-outline-secondary px-4">
                                <i class="bi bi-arrow-left me-1"></i> Back
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>


    </div>

    <script>
        flatpickr("#joiningDate", {
            dateFormat: "d/m/Y",
            allowInput: true
        });
    </script>
    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>



</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/leads_details.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Company Details</h5>
                        <div>
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i>
                            </a>
                            <a href="<?php echo e(route('manage-company')); ?>" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Companies
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Company Details Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">

                        <!-- ================= COMPANY DETAILS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-building me-1"></i> Company Details
                            </h4>
                        </div>

                        <!-- Company Details Rows -->
                        <div class="mb-4 font">
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Company Name:</strong> <?php echo e($company->company_name); ?></div>
                                <div class="col-md-4"><strong>Mobile:</strong> <?php echo e($company->mobile_number ?? 'N/A'); ?>

                                </div>
                                <div class="col-md-4"><strong>GST No:</strong> <?php echo e($company->gst_number ?? 'N/A'); ?></div>
                            </div>

                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Email:</strong> <?php echo e($company->company_email); ?></div>
                                <!-- <div class="col-md-4"><strong>PAN No:</strong> <?php echo e($company->pan_card ?? 'N/A'); ?></div> -->
                                <div class="col-md-4"><strong>Status:</strong>
                                    <?php if($company->status == 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row mb-2">
                                <!-- <div class="col-md-4"><strong>Established:</strong>
                                    <?php echo e($company->established_year ?? 'N/A'); ?></div> -->
                                <div class="col-md-4"><strong>Address:</strong> <?php echo e($company->address ?? 'N/A'); ?></div>
                                <div class="col-md-4">
                                    <strong>Logo:</strong>
                                    <?php if($company->company_logo): ?>
                                        <img src="<?php echo e(asset($company->company_logo)); ?>" width="50" class="rounded border">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('img/default-logo.png')); ?>" width="50" class="rounded border">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- ================= BANK DETAILS ================= -->
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-bank me-1"></i> Bank Details
                            </h4>
                        </div>

                        <div class="mb-4">
                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Account Holder:</strong>
                                    <?php echo e($company->account_holder_name ?? 'N/A'); ?></div>
                                <div class="col-md-4"><strong>Bank Name:</strong> <?php echo e($company->bank_name ?? 'N/A'); ?>

                                </div>
                                <div class="col-md-4"><strong>Branch:</strong> <?php echo e($company->branch_name ?? 'N/A'); ?>

                                </div>
                            </div>

                            <div class="row mb-2">
                                <div class="col-md-4"><strong>Account No:</strong>
                                    <?php echo e($company->account_number ?? 'N/A'); ?></div>
                                <div class="col-md-4"><strong>IFSC:</strong> <?php echo e($company->ifsc_code ?? 'N/A'); ?></div>
                                <div class="col-md-4"><strong>Type:</strong>
                                    <?php echo e(ucfirst($company->account_type ?? 'N/A')); ?></div>
                            </div>
                        </div>

                        <!-- Buttons -->
                        <div class="mt-4 d-flex justify-content-end gap-2">
                            <a href="<?php echo e(route('edit-company', $company->id)); ?>" class="btn btn-primary px-4">
                                <i class="bi bi-pencil-square me-1"></i> Edit
                            </a>
                            <a href="<?php echo e(route('manage-company')); ?>" class="btn btn-outline-secondary px-4">Back</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/view.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Manage Invoice</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Manage Invoice</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i>
                            </a>

                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>

                            <!-- Export Dropdown -->
                            <div class="dropdown me-1">
                                <a href="javascript:void(0);"
                                    class="dropdown-toggle btn btn-white border-1 d-inline-flex align-items-center"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li><a href="#" class="dropdown-item rounded-1"><i
                                                class="bi bi-file-earmark-pdf me-1"></i> Export as PDF</a></li>
                                    <li><a href="#" class="dropdown-item rounded-1"><i
                                                class="bi bi-file-earmark-excel me-1"></i> Export as Excel</a></li>
                                </ul>
                            </div>

                            <!-- Add New Invoice Button -->
                            <a href="<?php echo e(route('add-invoice')); ?>" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add New Invoice
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row g-3">

            <!-- Total Employees -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-dark rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-people text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate">Total Invoice</p>
                                <h4 class="fw-bold mb-0">1007</h4>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Active -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-success rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-person-check text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate ">Outstanding

                                </p>
                                <h4 class="fw-bold mb-0">1007</h4>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Inactive -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-danger rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-person-dash text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate">Draft</p>
                                <h4 class="fw-bold mb-0">1007</h4>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Trsh -->
            <div class="col-lg-3 col-md-6 d-flex">
                <div class="card flex-fill shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center overflow-hidden">
                            <div>
                                <span
                                    class="avatar avatar-lg bg-primary rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-trash text-white fs-4"></i>
                                </span>
                            </div>
                            <div class="ms-3 overflow-hidden">
                                <p class="fs-6 mb-1 text-truncate">Total Overdue

                                </p>
                                <h4 class="fw-bold mb-0">1007</h4>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- Invoice List -->
        <div class="card shadow-sm border-bottom mt-3 company">
            <div class="border-bottom">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <h5 class="fw-semibold mb-0">Invoice List</h5>

                        <div class="d-flex align-items-center flex-wrap justify-content-end gap-2">
                            <input type="text" class="form-control" placeholder="Search by Invoice / Customer"
                                style="width:210px;">
                            <select class="form-select" style="width:160px;">
                                <option>Payment Status</option>
                                <option>Paid</option>
                                <option>Pending</option>
                                <option>Overdue</option>
                            </select>

                            <button class="btn btn-primary text-white me-1">
                                <i class="bi bi-search"></i>
                            </button>

                            <button class="btn btn-light border-1">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th><input type="checkbox" class="form-check-input"></th>
                                <th>Invoice No</th>
                                <th>Customer Name</th>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>INV-001</td>
                                <td>Alpha Tech</td>
                                <td>01 Nov 2025</td>
                                <td>₹25,000</td>
                                <td><span
                                        class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">Paid</span>
                                </td>
                                <td class="text-center">
                                    <a href="#" class="text-primary me-2" title="Edit"><i
                                            class="bi bi-pencil-square"></i></a>
                                    <a href="#" class="text-danger me-2" title="Delete"><i class="bi bi-trash"></i></a>
                                    <a href="#" class="text-success me-2" title="View"><i class="bi bi-eye"></i></a>
                                    <div class="dropdown d-inline">
                                        <a href="#" class="text-secondary" id="moreDropdown1" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="bi bi-three-dots"></i>
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="moreDropdown1">
                                            <li><a class="dropdown-item" href="#">Download PDF</a></li>
                                            <li><a class="dropdown-item" href="#">Send Email</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>2</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>INV-002</td>
                                <td>Beta Innovations</td>
                                <td>03 Nov 2025</td>
                                <td>₹18,500</td>
                                <td><span
                                        class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-2">Pending</span>
                                </td>
                                <td class="text-center">
                                    <a href="#" class="text-primary me-2" title="Edit"><i
                                            class="bi bi-pencil-square"></i></a>
                                    <a href="#" class="text-danger me-2" title="Delete"><i class="bi bi-trash"></i></a>
                                    <a href="#" class="text-success me-2" title="View"><i class="bi bi-eye"></i></a>
                                    <div class="dropdown d-inline">
                                        <a href="#" class="text-secondary" id="moreDropdown2" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="bi bi-three-dots"></i>
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="moreDropdown2">
                                            <li><a class="dropdown-item" href="#">Download PDF</a></li>
                                            <li><a class="dropdown-item" href="#">Send Reminder</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>INV-003</td>
                                <td>Gamma Solutions</td>
                                <td>05 Nov 2025</td>
                                <td>₹42,000</td>
                                <td><span
                                        class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2">Overdue</span>
                                </td>
                                <td class="text-center">
                                    <a href="#" class="text-primary me-2" title="Edit"><i
                                            class="bi bi-pencil-square"></i></a>
                                    <a href="#" class="text-danger me-2" title="Delete"><i class="bi bi-trash"></i></a>
                                    <a href="#" class="text-success me-2" title="View"><i class="bi bi-eye"></i></a>
                                    <div class="dropdown d-inline">
                                        <a href="#" class="text-secondary" id="moreDropdown3" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="bi bi-three-dots"></i>
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="moreDropdown3">
                                            <li><a class="dropdown-item" href="#">Download PDF</a></li>
                                            <li><a class="dropdown-item" href="#">Send Reminder</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav aria-label="Invoice pagination">
                    <ul class="pagination justify-content-end mt-3">
                        <li class="page-item disabled"><a class="page-link" href="#"><i
                                    class="bi bi-chevron-left"></i></a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#"><i class="bi bi-chevron-right"></i></a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/manage_invoice.blade.php ENDPATH**/ ?>
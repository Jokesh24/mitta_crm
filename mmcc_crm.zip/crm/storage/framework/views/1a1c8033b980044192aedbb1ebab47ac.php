<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Company</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Edit Company</h5>
                        <div>
                            <a href="<?php echo e(route('manage-company')); ?>" class="btn btn-primary">
                                <i class="bi bi-chevron-double-left me-1"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Form -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                            <h4 class="me-2 mb-0 fw-semibold text-primary">
                                <i class="bi bi-building me-1"></i> Edit Company Details
                            </h4>
                        </div>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger mt-3"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('update-company', $company->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row g-4 mb-4">
                                <!-- Company Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="company_name" class="form-control"
                                        value="<?php echo e(old('company_name', $company->company_name)); ?>">
                                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Email -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Email<span
                                            class="text-danger">*</span></label>
                                    <input type="email" name="company_email" class="form-control"
                                        value="<?php echo e(old('company_email', $company->company_email)); ?>">
                                    <?php $__errorArgs = ['company_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Mobile -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Mobile Number</label>
                                    <input type="text" name="mobile_number" class="form-control"
                                        value="<?php echo e(old('mobile_number', $company->mobile_number)); ?>">
                                    <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- GST -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">GST Number</label>
                                    <input type="text" name="gst_number" class="form-control"
                                        value="<?php echo e(old('gst_number', $company->gst_number)); ?>">
                                </div>

                                <!-- Company Logo -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Logo</label>
                                    <input type="file" name="company_logo" class="form-control" accept="image/*">
                                    <?php if($company->company_logo): ?>
                                        <img src="<?php echo e(asset($company->company_logo)); ?>" alt="Logo" class="mt-2 rounded"
                                            width="60">
                                    <?php endif; ?>
                                    <small class="text-muted">Supported formats: JPG, PNG, SVG</small>
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status</label>
                                    <select name="status" class="form-select">
                                        <option value="active" <?php echo e($company->status == 'active' ? 'selected' : ''); ?>>Active
                                        </option>
                                        <option value="inactive" <?php echo e($company->status == 'inactive' ? 'selected' : ''); ?>>
                                            Inactive</option>
                                    </select>
                                </div>

                                <!-- Address -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Address</label>
                                    <textarea name="address" class="form-control"
                                        rows="2"><?php echo e(old('address', $company->address)); ?></textarea>
                                </div>
                            </div>

                            <!-- BANK DETAILS -->
                            <div class="d-flex align-items-center mb-3 flex-wrap border-bottom p-2 bg-light">
                                <h4 class="me-2 mb-0 fw-semibold text-primary">
                                    <i class="bi bi-bank me-1"></i> Bank Details
                                </h4>
                            </div>

                            <div class="row g-4 mb-4">
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Account Holder Name</label>
                                    <input type="text" name="account_holder_name" class="form-control"
                                        value="<?php echo e(old('account_holder_name', $company->account_holder_name)); ?>">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Bank Name</label>
                                    <input type="text" name="bank_name" class="form-control"
                                        value="<?php echo e(old('bank_name', $company->bank_name)); ?>">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Branch Name</label>
                                    <input type="text" name="branch_name" class="form-control"
                                        value="<?php echo e(old('branch_name', $company->branch_name)); ?>">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Account Number</label>
                                    <input type="text" name="account_number" class="form-control"
                                        value="<?php echo e(old('account_number', $company->account_number)); ?>">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">IFSC Code</label>
                                    <input type="text" name="ifsc_code" class="form-control"
                                        value="<?php echo e(old('ifsc_code', $company->ifsc_code)); ?>">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Account Type</label>
                                    <select name="account_type" class="form-select">
                                        <option value="">Select Type</option>
                                        <option value="saving" <?php echo e($company->account_type == 'saving' ? 'selected' : ''); ?>>
                                            Saving</option>
                                        <option value="current" <?php echo e($company->account_type == 'current' ? 'selected' : ''); ?>>Current</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('manage-company')); ?>"
                                    class="btn btn-outline-secondary px-4">Cancel</a>
                                <button type="submit" class="btn btn-primary px-4">Update Company</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/edit_company.blade.php ENDPATH**/ ?>
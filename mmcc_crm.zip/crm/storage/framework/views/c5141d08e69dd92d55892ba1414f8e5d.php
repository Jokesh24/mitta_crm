<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>
    <!-- Your existing header links (Bootstrap, etc.) -->
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row  mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Payslip</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>

                            <!-- Custom CSS for tooltip -->
                            <!-- Export Dropdown -->
                            <div class="dropdown me-1 ">
                                <a href="javascript:void(0);"
                                    class="dropdown-toggle btn btn-white border-1 d-inline-flex align-items-center"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-pdf me-1"></i> Export as PDF
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-excel me-1"></i> Export as Excel
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Add New Company Button -->
                            <!-- <a href="add_inwordpayment.php" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add Inword Payment
                            </a> -->
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="card shadow-sm border-bottom mt-3 company">
            <!-- HEADER -->
            <div class="border-bottom ">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">

                        <!-- Title -->
                        <h5 class="fw-semibold mb-0">Employee Payslip </h5>

                        <!-- Filters Section -->
                        <div class="d-flex align-items-center flex-wrap justify-content-end gap-2">

                            <!-- Date Range -->
                            <input type="text" class="form-control" placeholder="Search by " style="width:210px;">

                            <!-- Designation -->
                            <select class="form-select" style="width:160px;">
                                <option>Designation</option>
                                <option>Finance</option>
                                <option>Developer</option>
                                <option>Executive</option>
                            </select>

                            <!-- Status -->
                            <select class="form-select form-select-sm" style="width: 160px;">
                                <option selected disabled>Select Month</option>
                                <option>January</option>
                                <option>February</option>
                                <option>March</option>
                                <option>April</option>
                                <option>May</option>
                                <option>June</option>
                                <option>July</option>
                                <option>August</option>
                                <option>September</option>
                                <option>October</option>
                                <option>November</option>
                                <option>December</option>
                            </select>
                            <button class="btn btn-primary text-white me-1">
                                <i class="bi bi-search"></i>
                            </button>

                            <button class="btn btn-light border-1">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>

                        </div>
                    </div>
                </div>
            </div>
            <!-- TABLE -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th><input type="checkbox" class="form-check-input"></th>
                                <th>Employee ID</th>
                                <th>Employee Name</th>
                                <th>Department</th>
                                <th>Designation</th>
                                <th>Joining Date</th>
                                <th>Salary</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <!-- Row 1 -->
                            <tr>
                                <td>1</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>EMP001</td>
                                <td>Ravi Kumar</td>
                                <td>Development</td>
                                <td>Software Engineer</td>
                                <td>05 Jan 2023</td>
                                <td>₹39,000</td>
                                <td>
                                    <span
                                        class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">
                                        Paid
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('pay-roll')); ?>" class="btn btn-sm btn-outline-primary"
                                        title="Generate Payslip">
                                        <i class="bi bi-file-earmark-text"></i> Generate Slip
                                    </a>
                                </td>
                            </tr>

                            <!-- Row 2 -->
                            <tr>
                                <td>2</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>EMP002</td>
                                <td>Neha Sharma</td>
                                <td>Finance</td>
                                <td>Accountant</td>
                                <td>12 Mar 2022</td>
                                <td>₹30,700</td>
                                <td>
                                    <span
                                        class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-2">
                                        Pending
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('pay-roll')); ?>" class="btn btn-sm btn-outline-primary"
                                        title="Generate Payslip">
                                        <i class="bi bi-file-earmark-text"></i> Generate Slip
                                    </a>
                                </td>
                            </tr>

                            <!-- Row 3 -->
                            <tr>
                                <td>3</td>
                                <td><input type="checkbox" class="form-check-input"></td>
                                <td>EMP003</td>
                                <td>Ajay Mehta</td>
                                <td>HR</td>
                                <td>HR Manager</td>
                                <td>20 Jul 2021</td>
                                <td>₹34,800</td>
                                <td>
                                    <span
                                        class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2">
                                        Unpaid
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('pay-roll')); ?>" class="btn btn-sm btn-outline-primary"
                                        title="Generate Payslip">
                                        <i class="bi bi-file-earmark-text"></i> Generate Slip
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav aria-label="Payslip pagination">
                    <ul class="pagination justify-content-end mt-3">
                        <li class="page-item disabled">
                            <a class="page-link" href="#"><i class="bi bi-chevron-left"></i></a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#"><i class="bi bi-chevron-right"></i></a>
                        </li>
                    </ul>
                </nav>
            </div>

        </div>
    </div>
    <!-- ================= RECORD PAYMENT MODAL ================= -->
    <div class="modal fade" id="recordPaymentModal" tabindex="-1" aria-labelledby="recordPaymentModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header text-white" style="background:#946d1e;">
                    <h5 class="modal-title" id="recordPaymentModalLabel"><i class="bi bi-cash-coin me-2"></i>Record
                        Payment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <form action="#" method="POST" id="recordPaymentForm">
                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Total Amount</label>
                                <input type="text" class="form-control" value="Rs 1001" readonly>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Balance Amount</label>
                                <input type="text" class="form-control" value="Alpha Tech Pvt Ltd" readonly>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Enter Paying Amount <span
                                        class="text-danger">*</span></label>
                                <input type="number" class="form-control" placeholder="Enter Paying Amount" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Payment Type <span
                                        class="text-danger">*</span></label>
                                <select class="form-select" required>
                                    <option value="">Select Payment Type</option>
                                    <option>Cash</option>
                                    <option>Cheque</option>
                                    <option>Bank Transfer</option>
                                    <option>UPI</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">In Advance</label>
                                <input type="number" class="form-control" placeholder="Enter Advance Amount">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Payment Date <span
                                        class="text-danger">*</span></label>
                                <input type="date" class="form-control" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Received By</label>
                                <input type="text" class="form-control" placeholder="Enter Receiver Name">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Upload Payment Proof</label>
                                <input type="file" class="form-control">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-semibold">Note</label>
                                <textarea class="form-control" rows="3" placeholder="Enter remarks or notes"></textarea>
                            </div>

                        </div>
                    </form>
                </div>


                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" form="recordPaymentForm" class="btn btn-primary">Save Payment</button>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/payslip.blade.php ENDPATH**/ ?>
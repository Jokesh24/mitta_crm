<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Setup Two-Factor Authentication | MMCC CRM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #F2EDE3;
            /* font-family: 'Poppins', sans-serif; */
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .setup-container {
            max-width: 850px;
            width: 100%;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.08);
            display: flex;
            overflow: hidden;
        }

        .left-section {
            background: linear-gradient(180deg, #AC8942, #966C22);
            color: white;
            flex: 1;
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .left-section h2 {
            font-weight: 700;
            margin-bottom: 20px;
        }

        .left-section p {
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.95rem;
            line-height: 1.6;
        }

        .right-section {
            flex: 1;
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .right-section h4 {
            color: #4a3b2e;
            font-weight: 700;
            margin-bottom: 15px;
        }

        .btn-option {
            border-radius: 10px;
            padding: 12px 0;
            font-weight: 600;
            transition: all 0.3s ease;
            width: 100%;
            margin-bottom: 12px;
        }

        .btn-enable {
            background: linear-gradient(180deg, #966C22, #AC8942);
            color: white;
            border: none;
        }

        .btn-enable:hover {
            transform: scale(1.02);
            opacity: 0.9;
        }

        .btn-skip {
            background: transparent;
            border: 1px solid #AC8942;
            color: #AC8942;
        }

        .btn-skip:hover {
            background-color: #AC8942;
            color: white;
        }

        .btn-never {
            background: transparent;
            color: #4d76ff;
            /* text-decoration: underline; */
            border: none;
        }

        .btn-never:hover {
            color: #966C22;
        }
    </style>
</head>

<body>

    <div class="setup-container">
        <div class="left-section">
            <h2>Secure Your CRM Account 🔐</h2>
            <p>Two-Factor Authentication (2FA) provides an additional layer of security, protecting your data even if
                someone gains access to your password.</p>
            <p>You’ll receive a one-time verification code on your registered mobile number each time you log in.</p>
        </div>

        <div class="right-section">
            <h4>Would you like to enable Two-Factor Authentication?</h4>
            <p class="text-muted mb-4">Choose how you'd like to proceed:</p>

            <?php if(session('info')): ?>
                <div class="alert alert-info"><?php echo e(session('info')); ?></div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('setup.2fa.submit')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" name="choice" value="enable" class="btn-option btn-enable">
                    ✅ Enable 2FA (Recommended)
                </button>

                <button type="submit" name="choice" value="skip" class="btn-option btn-skip">
                    ⏭ Skip for Now
                </button>

                <button type="submit" name="choice" value="never" class="btn-option btn-never">
                    🚫 Don’t ask me again
                </button>
            </form>
        </div>
    </div>

</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/setup_2fa.blade.php ENDPATH**/ ?>
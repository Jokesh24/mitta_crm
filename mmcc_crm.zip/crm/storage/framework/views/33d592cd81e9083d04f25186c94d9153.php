<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('https://code.jquery.com/ui/1.12.1/jquery-ui.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/chart.js')); ?>"></script>

<script src="<?php echo e(asset('js/main.js')); ?>"></script><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/includes/footer_links.blade.php ENDPATH**/ ?>
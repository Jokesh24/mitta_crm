<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Vendor</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Edit Vendor</h5>
                        <div>
                            <a href="<?php echo e(route('manage-vendor')); ?>" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Vendors
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Vendor Form -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="<?php echo e(route('update-vendor', $vendor->id)); ?>" method="POST" novalidate>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="row g-4 mb-4">
                                <!-- Business Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Business Name <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="business_name"
                                        value="<?php echo e(old('business_name', $vendor->business_name)); ?>" class="form-control"
                                        required>
                                    <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Email -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Email <span
                                            class="text-danger">*</span></label>
                                    <input type="email" name="email" value="<?php echo e(old('email', $vendor->email)); ?>"
                                        class="form-control" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Mobile Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Mobile Number <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="mobile_number"
                                        value="<?php echo e(old('mobile_number', $vendor->mobile_number)); ?>" class="form-control"
                                        required>
                                    <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- GST -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">GST Number</label>
                                    <input type="text" name="gst_number"
                                        value="<?php echo e(old('gst_number', $vendor->gst_number)); ?>" class="form-control">
                                    <?php $__errorArgs = ['gst_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- PAN -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">PAN Number</label>
                                    <input type="text" name="pan_number"
                                        value="<?php echo e(old('pan_number', $vendor->pan_number)); ?>" class="form-control">
                                    <?php $__errorArgs = ['pan_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Vendor Type -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Vendor Type <span
                                            class="text-danger">*</span></label>
                                    <select name="vendor_type" class="form-select" required>
                                        <option value="">Select Type</option>
                                        <option value="Inward" <?php echo e(old('vendor_type', $vendor->vendor_type) == 'Inward' ? 'selected' : ''); ?>>Inward</option>
                                        <option value="Outward" <?php echo e(old('vendor_type', $vendor->vendor_type) == 'Outward' ? 'selected' : ''); ?>>Outward</option>
                                    </select>
                                    <?php $__errorArgs = ['vendor_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Address -->
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Address <span
                                            class="text-danger">*</span></label>
                                    <textarea name="address" class="form-control" rows="3"
                                        required><?php echo e(old('address', $vendor->address)); ?></textarea>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status <span
                                            class="text-danger">*</span></label>
                                    <select name="status" class="form-select" required>
                                        <option value="">Select Status</option>
                                        <option value="active" <?php echo e(old('status', $vendor->status) == 'active' ? 'selected' : ''); ?>>Active</option>
                                        <option value="inactive" <?php echo e(old('status', $vendor->status) == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('manage-vendor')); ?>" class="btn btn-outline-secondary px-4">Cancel</a>
                                <button type="submit" class="btn btn-primary px-4">Update Vendor</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/edit_vendor.blade.php ENDPATH**/ ?>
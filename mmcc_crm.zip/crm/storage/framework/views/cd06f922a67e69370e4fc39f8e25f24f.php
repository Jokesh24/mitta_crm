<div class="overlay" id="overlay"></div>

<!-- Start Sidebar Section -->
<div class="sidebar">
  <div class="sidebar-logo text-center">
    <a href="<?php echo e(route('dashboard')); ?>">
      <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
    </a>
  </div>

  <div class="sidebar-content">

    <!-- Dashboard -->
    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link" id="dashboard-link">
      <i class="bi bi-grid-3x3-gap" data-tooltip="Dashboard"></i>
      <span>Dashboard</span>
    </a>

    <!-- Master Data -->
    <a href="#submenu1" class="nav-link dropdown-toggle" data-submenu="submenu1" id="master-data-link">
      <i class="bi bi-database" data-tooltip="Master Data"></i>
      <span>Master Data</span>
    </a>
    <div class="submenu" id="submenu1">
      <a href="add_currency.php" class="nav-link" id="currency-link"><span>Currency</span></a>
      <a href="add_state.php" class="nav-link" id="state-link"><span>State</span></a>
      <a href="add_city.php" class="nav-link" id="cities-link"><span>Cities</span></a>
    </div>

    <!-- Companies -->
    <a href="#submenu2" class="nav-link dropdown-toggle" data-submenu="submenu2" id="companies-link">
      <i class="bi bi-buildings" data-tooltip="Companies"></i>
      <span>Companies</span>
    </a>
    <div class="submenu" id="submenu2">
      <a href="<?php echo e(route('add-company')); ?>" class="nav-link" id="add-company-link"><span>Add</span></a>
      <a href="<?php echo e(route('manage-company')); ?>" class="nav-link" id="manage-company-link"><span>Manage</span></a>
    </div>

    <!-- Vendors -->
    <!-- <a href="<?php echo e(route('manage-vendor')); ?>" class="nav-link" id="vendors-link">
      <i class="bi bi-person-workspace" data-tooltip="Vendors"></i>
      <span>Vendors</span>
    </a> -->


    <!-- Vendors -->
    <a href="#submenu8" class="nav-link dropdown-toggle" data-submenu="submenu8" id="vendors-section-link">
      <i class="bi bi-person-vcard" data-bs-toggle="tooltip" title="Vendors"></i>
      <span>Vendors</span>
    </a>
    <div class="submenu" id="submenu8">
      <a href="<?php echo e(route('add-vendor')); ?>" class="nav-link" id="add-vendor-link"><span>Add Vendor</span></a>
      <a href="<?php echo e(route('manage-vendor')); ?>" class="nav-link" id="manage-vendor-link"><span>Manage Vendors</span></a>
    </div>


    <!-- Leads -->
    <a href="#submenu5" class="nav-link dropdown-toggle" data-submenu="submenu5" id="leads-link">
      <i class="bi bi-people" data-bs-toggle="tooltip" title="Leads"></i>
      <span>Leads</span>
    </a>
    <div class="submenu" id="submenu5">
      <a href="<?php echo e(route('add-lead')); ?>" class="nav-link" id="add-leads-link"><span>Add Lead</span></a>
      <a href="<?php echo e(route('manage-leads')); ?>" class="nav-link" id="manage-lead-link"><span>Manage Leads</span></a>
    </div>

    <!-- Payments -->
    <a href="#submenu7" class="nav-link dropdown-toggle" data-submenu="submenu7" id="payments-link">
      <i class="bi bi-cash-stack" data-tooltip="Payments" title="Payments"></i>
      <span>Payments</span>
    </a>
    <div class="submenu" id="submenu7">
      <a href="<?php echo e(route('inward-payments')); ?>" class="nav-link" id="add-inword-link"><span>Inword
          Payments</span></a>
      <a href="<?php echo e(route('outward-payments')); ?>" class="nav-link" id="add-outword-link"><span>Outword
          Payments</span></a>
    </div>

    <!-- Invoices -->
    <a href="#submenu6" class="nav-link dropdown-toggle" data-submenu="submenu6" id="invoice-link">
      <i class="bi bi-receipt-cutoff" data-bs-toggle="tooltip" title="Invoices"></i>
      <span>Invoices</span>
    </a>
    <div class="submenu" id="submenu6">
      <a href="<?php echo e(route('add-invoice')); ?>" class="nav-link" id="add-invoice-link"><span>Add Invoice</span></a>
      <a href="<?php echo e(route('manage-invoice')); ?>" class="nav-link" id="manage-invoice-link"><span>Manage Invoices</span></a>
    </div>

    <!-- HRMS (Dropdown) -->
    <a href="#submenuHRMS" class="nav-link dropdown-toggle" data-submenu="submenuHRMS" id="hrms-link">
      <i class="bi bi-person-lines-fill" data-bs-toggle="tooltip" title="HRMS"></i>
      <span>HRMS</span>
    </a>
    <div class="submenu" id="submenuHRMS">
      <a href="<?php echo e(route('manage-employee')); ?>" class="nav-link" id="employee-list-link">
        <span>Employee List</span>
      </a>

      <!-- Day Attendance -->
      <a href="<?php echo e(route('attendence-today')); ?>" class="nav-link" id="attendance-day-link">
        <span>Day Attendance</span>
      </a>

      <!-- Monthly Attendance -->
      <a href="<?php echo e(route('attendence-monthly')); ?>" class="nav-link" id="attendance-monthly-link">
        <span>Monthly Attendance</span>
      </a>

      <!-- Payroll -->
      <a href="<?php echo e(route('pay-slip')); ?>" class="nav-link" id="payroll-link">
        <span>Payslip</span>
      </a>
    </div>

    <!-- Change Password -->
    <a href="<?php echo e(route('change.password.form')); ?>" class="nav-link" id="change-password-link">
      <i class="bi bi-key" data-tooltip="Change Password"></i>
      <span>Change Password</span>
    </a>

    <!-- Security Settings  -->
    <a href="<?php echo e(route('security.settings')); ?>" class="nav-link" id="security-settings-link">
      <i class="bi bi-shield-lock" data-tooltip="Security Settings"></i>
      <span>Security Settings</span>
    </a>

    <!-- Logout -->
    <a href="<?php echo e(route('logout')); ?>" class="nav-link" id="logout-link">
      <i class="bi bi-box-arrow-right" data-tooltip="Logout"></i>
      <span>Logout</span>
    </a>

  </div>
</div>
<!-- End Sidebar Section -->

<!-- Sidebar Script -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    /* ---------- Submenu Toggle ---------- */
    const dropdowns = document.querySelectorAll(".dropdown-toggle");
    dropdowns.forEach(dropdown => {
      dropdown.addEventListener("click", function (e) {
        e.preventDefault();
        const submenu = this.nextElementSibling;
        if (!submenu) return;

        const isActive = this.classList.contains("active");
        if (!isActive) {
          submenu.style.maxHeight = submenu.scrollHeight + "px";
          submenu.classList.add("show");
          this.classList.add("active");
        } else {
          submenu.style.maxHeight = "0";
          submenu.classList.remove("show");
          this.classList.remove("active");
        }
      });
    });

    /* ---------- Highlight Active Sidebar Link ---------- */
    const currentUrl = window.location.href;

    // Highlight active link and expand submenu if needed
    document.querySelectorAll(".sidebar a.nav-link").forEach(link => {
      if (link.href === currentUrl || currentUrl.startsWith(link.href)) {
        link.classList.add("active");

        // Expand its submenu if inside one
        const submenu = link.closest(".submenu");
        if (submenu) {
          submenu.classList.add("show");
          submenu.style.maxHeight = submenu.scrollHeight + "px";

          // Mark parent dropdown as active
          const parentToggle = submenu.previousElementSibling;
          if (parentToggle && parentToggle.classList.contains("dropdown-toggle")) {
            parentToggle.classList.add("active");
          }
        }
      }
    });
  });
</script><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/includes/sidebar.blade.php ENDPATH**/ ?>
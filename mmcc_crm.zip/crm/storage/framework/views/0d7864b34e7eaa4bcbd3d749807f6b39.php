<!-- Start Header Section -->
<div class="header d-flex justify-content-between align-items-center px-4 py-2 shadow-sm">
  <!-- Left Section -->
  <div class="d-flex align-items-center gap-3">
    <i class="bi bi-list fs-4" id="toggleBtn"></i>
  </div>

  <!-- Welcome Section -->
  <div class="welcome-text">
    <span> &nbsp; Welcome to, <span class="welcome-text-highlight">Super Admin</span></span>
  </div>

  <!-- Right Section -->
  <div class="d-flex align-items-center gap-4 position-relative">
    <?php if(Session::has('user')): ?>
      <?php
        $user = Session::get('user');
        $lastLogin = \App\Models\RlUser::find($user['id']);
      ?>

      <!-- User Info Box -->
      <div class="last-login-box px-3 py-2 rounded-3 shadow-sm text-end">
        <div class="fw-semibold text-dark">
          <?php echo e($user['name']); ?>

          <span class="text-muted">(<?php echo e(ucfirst($user['role'])); ?>)</span>
        </div>
        <?php if($lastLogin): ?>
          <div class="d-flex align-items-center gap-2 mt-1">
            <i class="bi bi-clock text-primary pulse-icon"></i>
            <small class="text-muted">
              <?php echo e(\Carbon\Carbon::parse($lastLogin->last_login_at)->format('d M Y, h:i A')); ?>

            </small>
          </div>
          
          
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <!-- Settings Icon -->
    <i class="bi bi-gear fs-5 text-muted hover-icon"></i>

    <!-- User Icon -->
    <!-- User Dropdown -->
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-decoration-none " id="userDropdown" data-bs-toggle="dropdown"
        aria-expanded="false">
        <img src="<?php echo e(asset('img/user-icon.png')); ?>" alt="User Icon" class="user-icon rounded-circle" width="35"
          height="35">
      </a>
      <ul class="dropdown-menu dropdown-menu-end shadow-sm" aria-labelledby="userDropdown">
        <li>
          <h6 class="dropdown-header">Welcome, User</h6>
        </li>
        <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i>My Profile</a></li>
        <li><a class="dropdown-item" href="#"><i class="bi bi-gear me-2"></i>Settings</a></li>
        <li>
          <hr class="dropdown-divider">
        </li>
        <li><a class="dropdown-item text-danger" href="#"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</div>
<!-- End Header Section -->


<style>
  /* ---------- Header Base ---------- */
  .header {
    background: #ffffff;
    border-bottom: 1px solid #e5e7eb;
    animation: fadeIn 0.6s ease;
    position: relative;
    z-index: 10;
  }

  /* ---------- Welcome Text ---------- */
  .welcome-text {
    font-size: 16px;
    font-weight: 500;
    color: #374151;
  }

  .welcome-text-highlight {
    font-weight: 600;
    color: #2563eb;
  }

  /* ---------- User Info Card ---------- */
  .last-login-box {
    background: linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
    border: 1px solid rgba(229, 231, 235, 0.9);
    border-radius: 10px;
    transition: all 0.3s ease;
    font-size: 13px;
    min-width: 210px;
  }

  .last-login-box:hover {
    background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
    box-shadow: 0 3px 12px rgba(59, 130, 246, 0.15);
    transform: translateY(-1px);
  }

  /* ---------- Clock Animation ---------- */
  .pulse-icon {
    animation: pulse 1.8s infinite;
  }

  @keyframes pulse {
    0% {
      opacity: 0.7;
      transform: scale(1);
    }

    50% {
      opacity: 1;
      transform: scale(1.2);
      color: #2563eb;
    }

    100% {
      opacity: 0.7;
      transform: scale(1);
    }
  }

  /* ---------- Hover Icon (Settings) ---------- */
  .hover-icon {
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .hover-icon:hover {
    color: #2563eb !important;
    transform: rotate(30deg);
  }

  /* ---------- User Image ---------- */
  .user-icon {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border: 2px solid #e5e7eb;
    object-fit: cover;
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  .user-icon:hover {
    transform: scale(1.05);
    box-shadow: 0 0 8px rgba(37, 99, 235, 0.3);
  }

  /* ---------- Animation ---------- */
  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(-5px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/includes/header.blade.php ENDPATH**/ ?>
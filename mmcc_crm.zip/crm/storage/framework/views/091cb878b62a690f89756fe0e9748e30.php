<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Outward Payment</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <!-- Flatpickr JS -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <!-- Page Header -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Create Outward Payment</h5>
                        <div>
                            <a href="<?php echo e(route('outward-payments')); ?>" class="btn btn-primary">
                                <i class="bi bi-gear me-1"></i> Manage Outward Payments
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <?php if(session('success')): ?>
            <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger mt-3"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <!-- Form Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="<?php echo e(route('store-payment')); ?>" method="POST" novalidate>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="payment_type" value="outward">

                            <div class="row g-4 mb-4">
                                <!-- Company Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Name <span
                                            class="text-danger">*</span></label>
                                    <select name="company_id" class="form-select" required>
                                        <option value="">Select Company</option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($company->id); ?>" <?php echo e(old('company_id') == $company->id ? 'selected' : ''); ?>>
                                                <?php echo e($company->company_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Vendor Name -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Vendor Name <span
                                            class="text-danger">*</span></label>
                                    <select name="vendor_id" class="form-select" required>
                                        <option value="">Select Vendor</option>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($vendor->id); ?>" <?php echo e(old('vendor_id') == $vendor->id ? 'selected' : ''); ?>>
                                                <?php echo e($vendor->business_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['vendor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Total -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Total Amount</label>
                                    <input type="number" step="0.01" id="totalAmount" name="total_amount"
                                        value="<?php echo e(old('total_amount')); ?>" class="form-control"
                                        placeholder="Enter total amount">
                                </div>

                                <!-- Discount -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Discount</label>
                                    <input type="number" step="0.01" id="discountAmount" name="discount"
                                        value="<?php echo e(old('discount')); ?>" class="form-control"
                                        placeholder="Enter discount amount">
                                </div>

                                <!-- Paid -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Paid Amount <span
                                            class="text-danger">*</span></label>
                                    <input type="number" step="0.01" id="paidAmount" name="paid_amount"
                                        value="<?php echo e(old('paid_amount')); ?>" class="form-control"
                                        placeholder="Enter paid amount" required>
                                    <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Balance -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Balance Amount</label>
                                    <input type="number" step="0.01" id="balanceAmount" name="balance_amount"
                                        value="<?php echo e(old('balance_amount')); ?>" class="form-control"
                                        placeholder="Balance will auto-calculate" readonly>
                                </div>

                                <!-- Payment Date
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" name="payment_date" value="<?php echo e(old('payment_date')); ?>"
                                        class="form-control" required>
                                    <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> -->

                                <!-- Payment Date -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Date <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="paymentDate" name="payment_date"
                                        value="<?php echo e(old('payment_date')); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Payment Mode -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Mode <span
                                            class="text-danger">*</span></label>
                                    <select name="payment_mode" class="form-select" required>
                                        <option value="">Select Mode</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="bank_transfer">Bank Transfer</option>
                                        <option value="upi">UPI</option>
                                    </select>
                                    <?php $__errorArgs = ['payment_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Reference Number -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Reference Number</label>
                                    <input type="text" name="reference_number" value="<?php echo e(old('reference_number')); ?>"
                                        class="form-control" placeholder="Enter reference ID">
                                </div>

                                <!-- Remarks -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Remarks</label>
                                    <textarea name="remarks" rows="2" class="form-control"
                                        placeholder="Enter remarks"><?php echo e(old('remarks')); ?></textarea>
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status <span
                                            class="text-danger">*</span></label>
                                    <select name="status" class="form-select" required>
                                        <option value="">Select Status</option>
                                        <option value="pending">Pending</option>
                                        <option value="completed">Completed</option>
                                        <option value="failed">Failed</option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
                                <button type="submit" class="btn btn-primary px-4">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- 🧮 Auto Balance Calculation -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const totalInput = document.getElementById('totalAmount');
            const discountInput = document.getElementById('discountAmount');
            const paidInput = document.getElementById('paidAmount');
            const balanceInput = document.getElementById('balanceAmount');

            function calculateBalance() {
                const total = parseFloat(totalInput.value) || 0;
                const discount = parseFloat(discountInput.value) || 0;
                const paid = parseFloat(paidInput.value) || 0;
                const balance = total - discount - paid;
                balanceInput.value = balance >= 0 ? balance.toFixed(2) : 0;
            }

            totalInput.addEventListener('input', calculateBalance);
            discountInput.addEventListener('input', calculateBalance);
            paidInput.addEventListener('input', calculateBalance);
        });
        // ✅ Flatpickr JS Date Picker
        document.addEventListener("DOMContentLoaded", function () {
            flatpickr("#paymentDate", {
                dateFormat: "d/m/Y",
                allowInput: true,
                maxDate: "today"
            });
        });
    </script>
</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/add_outwordpayment.blade.php ENDPATH**/ ?>
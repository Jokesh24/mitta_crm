<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>CRM Dashboard - Add Invoice</title>

  <!-- Header Links -->
  <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body>
  <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


  <div class="content">
    <!-- Page Header -->
    <div class="row mb-3">
      <div class="col-lg-12">
        <div class="card border-0">
          <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
            <h5 class="mb-0 fw-semibold text-dark">Create New Invoice</h5>
            <div>
              <a href="<?php echo e(route('manage-invoice')); ?>" class="btn btn-primary">
                <i class="bi bi-receipt-cutoff me-1"></i> Manage Invoices
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Invoice Form -->
    <div class="row">
      <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
          <div class="card-body">
            <form action="#" novalidate>
              <div class="row g-4 mb-4">

                <!-- Invoice Number -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Invoice Number <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter invoice number" required>
                </div>

                <!-- Invoice Date -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Invoice Date <span class="text-danger">*</span></label>
                  <input type="date" class="form-control" required>
                </div>

                <!-- Due Date -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Due Date</label>
                  <input type="date" class="form-control">
                </div>

                <!-- Customer Name -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Customer Name <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter customer name" required>
                </div>

                <!-- Customer Mobile -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Customer Mobile <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter mobile number" required>
                </div>

                <!-- Customer Email -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Customer Email</label>
                  <input type="email" class="form-control" placeholder="Enter email address">
                </div>

                <!-- Company Name -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Company Name</label>
                  <input type="text" class="form-control" placeholder="Enter company name">
                </div>

                <!-- GST Number -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">GST Number</label>
                  <input type="text" class="form-control" placeholder="Enter GST number">
                </div>

                <!-- Payment Mode -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Payment Mode <span class="text-danger">*</span></label>
                  <select class="form-select" required>
                    <option value="">Select Payment Mode</option>
                    <option>Cash</option>
                    <option>Bank Transfer</option>
                    <option>UPI</option>
                    <option>Cheque</option>
                  </select>
                </div>

                <!-- Subtotal -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Subtotal (₹) <span class="text-danger">*</span></label>
                  <input type="number" class="form-control" placeholder="Enter subtotal" required>
                </div>

                <!-- Tax (GST %) -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Tax (GST %)</label>
                  <input type="number" class="form-control" placeholder="Enter tax percentage">
                </div>

                <!-- Total Amount -->
                <div class="col-md-4">
                  <label class="form-label fw-semibold">Total Amount (₹) <span class="text-danger">*</span></label>
                  <input type="number" class="form-control" placeholder="Enter total amount" required>
                </div>

                <!-- Notes -->
                <div class="col-12">
                  <label class="form-label fw-semibold">Notes / Description</label>
                  <textarea class="form-control" rows="3" placeholder="Enter any notes or remarks"></textarea>
                </div>
              </div>

              <!-- Buttons -->
              <div class="mt-4 d-flex justify-content-end gap-2">
                <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
                <button type="submit" class="btn btn-primary px-4">Save Invoice</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- =================== INVOICE ITEMS TABLE =================== -->
    <div class="table-responsive mt-4">
      <table class="table table-bordered align-middle" id="invoiceTable">
        <thead style="background-color: #7a8b12; color: #fff;">
          <tr class="text-center">
            <th style="width: 5%;">#</th>
            <th>Item name</th>
            <th>HSN/SAC</th>
            <th>Size</th>
            <th style="width: 12%;">Quantity</th>
            <th>Unit</th>
            <th>Price/Unit</th>
            <th>GST</th>
            <th>Amount</th>
            <th style="width: 8%;">Action</th>
          </tr>
        </thead>
        <tbody id="invoiceTableBody">
          <tr>
            <td class="text-center">1</td>
            <td><input type="text" class="form-control" placeholder="Item name"></td>
            <td><input type="text" class="form-control text-center" placeholder="HSN/SAC"></td>
            <td><input type="text" class="form-control text-center" placeholder="Size"></td>
            <td class="text-center">
              <div class="d-flex align-items-center justify-content-center">
                <button type="button" class="btn btn-sm btn-outline-secondary px-2 minus-btn">-</button>
                <input type="text" class="form-control text-center mx-1 qty-input" style="width: 60px;" value="1">
                <button type="button" class="btn btn-sm btn-outline-secondary px-2 plus-btn">+</button>
              </div>
            </td>
            <td><input type="text" class="form-control text-center" placeholder="Unit"></td>
            <td><input type="text" class="form-control text-end" placeholder="₹0.00"></td>
            <td><input type="text" class="form-control text-center" placeholder="GST %"></td>
            <td><input type="text" class="form-control text-end" placeholder="₹0.00"></td>
            <td class="text-center">
              <button type="button" class="btn btn-danger btn-sm delete-row"><i class="bi bi-trash"></i></button>
            </td>
          </tr>
        </tbody>
      </table>

      <div class="mt-3">
        <button type="button" class="btn btn-primary" id="addRowBtn">
          <i class="bi bi-plus-lg me-1"></i> Add New
        </button>
      </div>
    </div>

    <!-- =================== SUMMARY SECTION =================== -->
    <div class="row justify-content-end mt-4">
      <div class="col-md-4">
        <div class="p-3 border rounded bg-light">
          <div class="mb-3 d-flex justify-content-between align-items-center">
            <label class="fw-semibold mb-0">Sub Total</label>
            <input type="text" class="form-control text-end" value="0.00" style="width: 130px;">
          </div>

          <div class="mb-3 d-flex justify-content-between align-items-center">
            <label class="fw-semibold mb-0">Estimated Tax (12.5%)</label>
            <input type="text" class="form-control text-end" value="0.00" style="width: 130px;">
          </div>

          <div class="mb-3 d-flex justify-content-between align-items-center">
            <label class="fw-semibold mb-0">Discount</label>
            <input type="text" class="form-control text-end" value="0.00" style="width: 130px;">
          </div>

          <div class="d-flex justify-content-between align-items-center bg-success text-white p-2 rounded">
            <label class="fw-semibold mb-0">Total</label>
            <input type="text" class="form-control text-end fw-bold border-0 bg-success text-white" value="Rs.0.00"
              readonly style="width: 130px;">
          </div>
        </div>
      </div>
    </div>

    <!-- =================== JAVASCRIPT FOR ADD/REMOVE ROW =================== -->
    <script>
      document.addEventListener('DOMContentLoaded', function () {
        const addRowBtn = document.getElementById('addRowBtn');
        const tableBody = document.getElementById('invoiceTableBody');

        // Add New Row
        addRowBtn.addEventListener('click', function () {
          const newRow = document.createElement('tr');
          const rowCount = tableBody.querySelectorAll('tr').length + 1;

          newRow.innerHTML = `
      <td class="text-center">${rowCount}</td>
      <td><input type="text" class="form-control" placeholder="Item name"></td>
      <td><input type="text" class="form-control text-center" placeholder="HSN/SAC"></td>
      <td><input type="text" class="form-control text-center" placeholder="Size"></td>
      <td class="text-center">
        <div class="d-flex align-items-center justify-content-center">
          <button type="button" class="btn btn-sm btn-outline-secondary px-2 minus-btn">-</button>
          <input type="text" class="form-control text-center mx-1 qty-input" style="width: 60px;" value="1">
          <button type="button" class="btn btn-sm btn-outline-secondary px-2 plus-btn">+</button>
        </div>
      </td>
      <td><input type="text" class="form-control text-center" placeholder="Unit"></td>
      <td><input type="text" class="form-control text-end" placeholder="₹0.00"></td>
      <td><input type="text" class="form-control text-center" placeholder="GST %"></td>
      <td><input type="text" class="form-control text-end" placeholder="₹0.00"></td>
      <td class="text-center">
        <button type="button" class="btn btn-danger btn-sm delete-row"><i class="bi bi-trash"></i></button>
      </td>
    `;
          tableBody.appendChild(newRow);
        });

        // Delegate Minus/Plus/Delete Buttons
        tableBody.addEventListener('click', function (e) {
          if (e.target.closest('.delete-row')) {
            e.target.closest('tr').remove();
            updateRowNumbers();
          }

          if (e.target.closest('.plus-btn')) {
            const input = e.target.closest('tr').querySelector('.qty-input');
            input.value = parseInt(input.value) + 1;
          }

          if (e.target.closest('.minus-btn')) {
            const input = e.target.closest('tr').querySelector('.qty-input');
            if (parseInt(input.value) > 1) input.value = parseInt(input.value) - 1;
          }
        });

        // Update row numbering after delete
        function updateRowNumbers() {
          const rows = tableBody.querySelectorAll('tr');
          rows.forEach((row, index) => {
            row.querySelector('td').textContent = index + 1;
          });
        }
      });
    </script>

  </div>

  <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/add_invoice.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Edit Outward Payment</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Edit Outward Payment</h5>
                        <div>
                            <a href="<?php echo e(route('outward-payments')); ?>" class="btn btn-primary">
                                <i class="bi bi-chevron-left me-1"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Card -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form action="<?php echo e(route('update-outward-payment', $payment->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="payment_type" value="outward">

                            <div class="row g-4 mb-4">
                                <!-- Company -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Company Name <span
                                            class="text-danger">*</span></label>
                                    <select name="company_id" class="form-select" required>
                                        <option value="">Select Company</option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($company->id); ?>" <?php echo e($payment->company_id == $company->id ? 'selected' : ''); ?>>
                                                <?php echo e($company->company_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <!-- Vendor -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Vendor Name <span
                                            class="text-danger">*</span></label>
                                    <select name="vendor_id" class="form-select" required>
                                        <option value="">Select Vendor</option>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($vendor->id); ?>" <?php echo e($payment->vendor_id == $vendor->id ? 'selected' : ''); ?>>
                                                <?php echo e($vendor->business_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Total Amount</label>
                                    <input type="number" step="0.01" id="totalAmount" name="total_amount"
                                        value="<?php echo e($payment->total_amount); ?>" class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Discount</label>
                                    <input type="number" step="0.01" id="discountAmount" name="discount"
                                        value="<?php echo e($payment->discount); ?>" class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Paid Amount <span
                                            class="text-danger">*</span></label>
                                    <input type="number" step="0.01" id="paidAmount" name="paid_amount"
                                        value="<?php echo e($payment->paid_amount); ?>" class="form-control" required>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Balance Amount</label>
                                    <input type="number" step="0.01" id="balanceAmount" name="balance_amount"
                                        value="<?php echo e($payment->balance_amount); ?>" class="form-control" readonly>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Date <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="paymentDate" name="payment_date"
                                        value="<?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('d/m/Y')); ?>"
                                        class="form-control" required>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Payment Mode</label>
                                    <select name="payment_mode" class="form-select" required>
                                        <option value="cash" <?php echo e($payment->payment_mode == 'cash' ? 'selected' : ''); ?>>Cash
                                        </option>
                                        <option value="cheque" <?php echo e($payment->payment_mode == 'cheque' ? 'selected' : ''); ?>>
                                            Cheque</option>
                                        <option value="bank_transfer" <?php echo e($payment->payment_mode == 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                                        <option value="upi" <?php echo e($payment->payment_mode == 'upi' ? 'selected' : ''); ?>>UPI
                                        </option>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Reference Number</label>
                                    <input type="text" name="reference_number" value="<?php echo e($payment->reference_number); ?>"
                                        class="form-control">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Remarks</label>
                                    <textarea name="remarks" rows="2"
                                        class="form-control"><?php echo e($payment->remarks); ?></textarea>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Status</label>
                                    <select name="status" class="form-select" required>
                                        <option value="pending" <?php echo e($payment->payment_status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                        <option value="completed" <?php echo e($payment->payment_status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                                        <option value="failed" <?php echo e($payment->payment_status == 'failed' ? 'selected' : ''); ?>>Failed</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('outward-payments')); ?>"
                                    class="btn btn-outline-secondary px-4">Cancel</a>
                                <button type="submit" class="btn btn-primary px-4">Update Payment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const totalInput = document.getElementById('totalAmount');
            const discountInput = document.getElementById('discountAmount');
            const paidInput = document.getElementById('paidAmount');
            const balanceInput = document.getElementById('balanceAmount');

            function calculateBalance() {
                const total = parseFloat(totalInput.value) || 0;
                const discount = parseFloat(discountInput.value) || 0;
                const paid = parseFloat(paidInput.value) || 0;
                balanceInput.value = (total - discount - paid).toFixed(2);
            }

            [totalInput, discountInput, paidInput].forEach(i => i.addEventListener('input', calculateBalance));
            flatpickr("#paymentDate", { dateFormat: "d/m/Y", allowInput: true });
        });
    </script>
</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/edit_outwardpayment.blade.php ENDPATH**/ ?>
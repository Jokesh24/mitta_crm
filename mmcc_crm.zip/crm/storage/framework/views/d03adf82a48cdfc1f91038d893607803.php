<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>CRM Dashboard - Vendor Form</title>

  <!-- Header Links -->
  <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body>
  <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


  <div class="content">
    <!-- Page Header -->
    <div class="row mb-3">
      <div class="col-lg-12">
        <div class="card border-0">
          <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
            <h5 class="mb-0 fw-semibold text-dark">Add New Vendor</h5>
            <div>
              <a href="<?php echo e(route('manage-vendor')); ?>" class="btn btn-primary">
                <i class="bi bi-gear me-1"></i> Manage Vendors
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php if(session('success')): ?>
      <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
      <div class="alert alert-danger mt-3"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <!-- Vendor Form -->
    <div class="row">
      <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
          <div class="card-body">
            <form action="<?php echo e(route('store-vendor')); ?>" method="POST" novalidate>
              <?php echo csrf_field(); ?>
              <div class="row g-4 mb-4">

                <div class="col-md-4">
                  <label class="form-label fw-semibold">Business Name <span class="text-danger">*</span></label>
                  <input type="text" name="business_name" class="form-control" value="<?php echo e(old('business_name')); ?>"
                    placeholder="Enter business name">
                  <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                  <label class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                  <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>"
                    placeholder="Enter email address">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                  <label class="form-label fw-semibold">Mobile Number <span class="text-danger">*</span></label>
                  <input type="text" name="mobile_number" class="form-control" value="<?php echo e(old('mobile_number')); ?>"
                    placeholder="Enter mobile number">
                  <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                  <label class="form-label fw-semibold">GST Number</label>
                  <input type="text" name="gst_number" class="form-control" value="<?php echo e(old('gst_number')); ?>"
                    placeholder="Enter GST number">
                </div>

                <div class="col-md-4">
                  <label class="form-label fw-semibold">PAN Number</label>
                  <input type="text" name="pan_number" class="form-control" value="<?php echo e(old('pan_number')); ?>"
                    placeholder="Enter PAN number">
                </div>

                <div class="col-md-4">
                  <label class="form-label fw-semibold">Vendor Type <span class="text-danger">*</span></label>
                  <select name="vendor_type" class="form-select">
                    <option value="">Select Type</option>
                    <option value="Inward" <?php echo e(old('vendor_type') == 'Inward' ? 'selected' : ''); ?>>Inward</option>
                    <option value="Outward" <?php echo e(old('vendor_type') == 'Outward' ? 'selected' : ''); ?>>Outward</option>
                  </select>
                  <?php $__errorArgs = ['vendor_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                  <label class="form-label fw-semibold">Address <span class="text-danger">*</span></label>
                  <textarea name="address" class="form-control" rows="3"
                    placeholder="Enter full address"><?php echo e(old('address')); ?></textarea>
                  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                  <label class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                  <select name="status" class="form-select">
                    <option value="">Select Status</option>
                    <option value="active" <?php echo e(old('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e(old('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                  </select>
                  <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

              </div>

              <div class="mt-4 d-flex justify-content-end gap-2">
                <button type="reset" class="btn btn-outline-secondary px-4">Cancel</button>
                <button type="submit" class="btn btn-primary px-4">Submit</button>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/add_vendor.blade.php ENDPATH**/ ?>
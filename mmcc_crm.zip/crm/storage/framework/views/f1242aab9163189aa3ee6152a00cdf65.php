<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - Corporate View</title>
    <!-- Your existing header links (Bootstrap, etc.) -->
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <div class="content">
        <!-- Page Header -->
        <div class="row  mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">Payments</h5>

                        <div class="d-flex align-items-center gap-2">
                            <a href="javascript:history.back()" class="btn btn-primary" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Back">
                                <i class="bi bi-chevron-double-left me-1"></i> </a>
                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                                    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                        return new bootstrap.Tooltip(tooltipTriggerEl);
                                    });
                                });
                            </script>

                            <!-- Custom CSS for tooltip -->
                            <!-- Export Dropdown -->
                            <div class="dropdown me-1 ">
                                <a href="javascript:void(0);"
                                    class="dropdown-toggle btn btn-white border-1 d-inline-flex align-items-center"
                                    data-bs-toggle="dropdown">
                                    <i class="bi bi-file-earmark-arrow-down me-1"></i> Export
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end p-2">
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-pdf me-1"></i> Export as PDF
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="dropdown-item rounded-1">
                                            <i class="bi bi-file-earmark-excel me-1"></i> Export as Excel
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Add New Company Button -->
                            <a href="<?php echo e(route('add-inward-payment')); ?>" class="btn btn-primary">
                                <i class="bi bi-plus me-1"></i> Add Inword Payment
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="card shadow-sm border-bottom mt-3 company">
            <!-- HEADER -->
            <div class="border-bottom ">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">

                        <!-- Title -->
                        <h5 class="fw-semibold mb-0">Inward Payment </h5>

                        <!-- Filters Section -->
                        <!-- Filters Section -->
                        <div class="d-flex align-items-center flex-wrap justify-content-end gap-2">
                            <input type="text" id="searchCompany" class="form-control"
                                placeholder="Search by Company Name" style="width:210px;">
                            <input type="text" id="searchVendor" class="form-control"
                                placeholder="Search by Vendor Name" style="width:210px;">

                            <!-- Payment Status -->
                            <select id="searchStatus" class="form-select" style="width:160px;">
                                <option value="">All Payment Status</option>
                                <option value="pending">Pending</option>
                                <option value="completed">Completed</option>
                                <option value="failed">Failed</option>
                            </select>

                            <button class="btn btn-light border-1" id="resetFilter"><i
                                    class="bi bi-arrow-clockwise"></i></button>
                        </div>

                    </div>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger mt-3"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <!-- TABLE -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th><input type="checkbox" class="form-check-input"></th>
                                <th>Company</th>
                                <th>Vendor Name</th>
                                <th>Total</th>
                                <th>Paid</th>
                                <th>Discount</th>
                                <th>Balance</th>
                                <th>Due Date</th>
                                <th>Payment Status</th>

                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="paymentTableBody">
                            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><input type="checkbox" class="form-check-input"></td>
                                    <td><?php echo e($payment->company->company_name ?? '-'); ?></td>
                                    <td><?php echo e($payment->vendor->business_name ?? '-'); ?></td>
                                    <td>₹<?php echo e(number_format($payment->total_amount, 2)); ?></td>
                                    <td>₹<?php echo e(number_format($payment->paid_amount, 2)); ?></td>
                                    <td>₹<?php echo e(number_format($payment->discount, 2)); ?></td>
                                    <td>₹<?php echo e(number_format($payment->balance_amount, 2)); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('d/m/Y')); ?></td>
                                    <td>
                                        <?php if($payment->payment_status == 'completed'): ?>
                                            <span class="badge bg-success">Completed</span>
                                        <?php elseif($payment->payment_status == 'pending'): ?>
                                            <span class="badge bg-warning text-dark">Pending</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Failed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <!-- Edit -->
                                        <a href="<?php echo e(route('edit-inward-payment', $payment->id)); ?>"
                                            class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <!-- Delete (with confirmation) -->
                                        <button type="button" class="btn btn-sm btn-outline-danger me-1 delete-btn"
                                            data-id="<?php echo e($payment->id); ?>" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>

                                        <!-- View -->
                                        <a href="<?php echo e(route('view-inward-payment', $payment->id)); ?>"
                                            class="btn btn-sm btn-outline-info" title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>

                                        <!-- Notification Placeholder -->
                                        <button class="btn btn-sm btn-outline-danger" title="Notify">
                                            <i class="bi bi-bell"></i>
                                        </button>

                                        <!-- Dropdown -->
                                        <div class="dropdown d-inline">
                                            <a href="#" class="text-secondary" id="moreDropdown" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                                <i class="bi bi-three-dots"></i>
                                            </a>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="moreDropdown">
                                                <li><a class="dropdown-item" href="#">Action 1</a></li>
                                                <li><a class="dropdown-item" href="#">Action 2</a></li>
                                                <li><a class="dropdown-item" href="#">Action 3</a></li>
                                            </ul>
                                        </div>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="11" class="text-center text-muted">No payments found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>

                    </table>

                </div>


                <!-- Pagination -->
                <nav aria-label="Invoice table pagination">
                    <ul class="pagination justify-content-end mt-3">
                        <li class="page-item disabled">
                            <a class="page-link" href="#"><i class="bi bi-chevron-left"></i></a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#"><i class="bi bi-chevron-right"></i></a>
                        </li>
                    </ul>
                </nav>
            </div>

        </div>
    </div>
    <!-- ================= RECORD PAYMENT MODAL ================= -->
    <div class="modal fade" id="recordPaymentModal" tabindex="-1" aria-labelledby="recordPaymentModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header text-white" style="background:#946d1e;">
                    <h5 class="modal-title" id="recordPaymentModalLabel"><i class="bi bi-cash-coin me-2"></i>Record
                        Payment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <form action="#" method="POST" id="recordPaymentForm">
                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Total Amount</label>
                                <input type="text" class="form-control" value="Rs 1001" readonly>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Balance Amount</label>
                                <input type="text" class="form-control" value="Alpha Tech Pvt Ltd" readonly>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Enter Paying Amount <span
                                        class="text-danger">*</span></label>
                                <input type="number" class="form-control" placeholder="Enter Paying Amount" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Payment Type <span
                                        class="text-danger">*</span></label>
                                <select class="form-select" required>
                                    <option value="">Select Payment Type</option>
                                    <option>Cash</option>
                                    <option>Cheque</option>
                                    <option>Bank Transfer</option>
                                    <option>UPI</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">In Advance</label>
                                <input type="number" class="form-control" placeholder="Enter Advance Amount">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Payment Date <span
                                        class="text-danger">*</span></label>
                                <input type="date" class="form-control" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Received By</label>
                                <input type="text" class="form-control" placeholder="Enter Receiver Name">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Upload Payment Proof</label>
                                <input type="file" class="form-control">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-semibold">Note</label>
                                <textarea class="form-control" rows="3" placeholder="Enter remarks or notes"></textarea>
                            </div>

                        </div>
                    </form>
                </div>


                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" form="recordPaymentForm" class="btn btn-primary">Save Payment</button>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll(".delete-btn").forEach(btn => {
            btn.addEventListener("click", function () {
                const paymentId = this.getAttribute("data-id");

                Swal.fire({
                    title: "Are you sure?",
                    text: "This payment will be moved to trash.",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#BE3117",
                    cancelButtonColor: "#6c757d",
                    confirmButtonText: "Yes, delete it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = `/inward-payment/delete/${paymentId}`;
                    }
                });
            });
        });
    });
</script>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        const searchCompany = document.getElementById("searchCompany");
        const searchVendor = document.getElementById("searchVendor");
        const searchStatus = document.getElementById("searchStatus");
        const resetFilter = document.getElementById("resetFilter");
        const rows = document.querySelectorAll("#paymentTableBody tr");

        function filterTable() {
            const companyVal = searchCompany.value.toLowerCase();
            const vendorVal = searchVendor.value.toLowerCase();
            const statusVal = searchStatus.value.toLowerCase();

            rows.forEach(row => {
                const company = row.cells[2]?.innerText.toLowerCase() || "";
                const vendor = row.cells[3]?.innerText.toLowerCase() || "";
                const status = row.cells[9]?.innerText.toLowerCase() || "";

                const match =
                    (!companyVal || company.includes(companyVal)) &&
                    (!vendorVal || vendor.includes(vendorVal)) &&
                    (!statusVal || status.includes(statusVal));

                row.style.display = match ? "" : "none";
            });
        }

        searchCompany.addEventListener("input", filterTable);
        searchVendor.addEventListener("input", filterTable);
        searchStatus.addEventListener("change", filterTable);
        resetFilter.addEventListener("click", () => {
            searchCompany.value = "";
            searchVendor.value = "";
            searchStatus.value = "";
            filterTable();
        });
    });
</script><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/inward_payment.blade.php ENDPATH**/ ?>
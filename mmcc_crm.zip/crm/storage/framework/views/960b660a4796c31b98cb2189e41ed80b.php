<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CRM Dashboard - View Outward Payment</title>
    <?php echo $__env->make('super_admin.includes.header_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('super_admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('super_admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content">
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold text-dark">View Outward Payment</h5>
                        <div>
                            <a href="<?php echo e(route('outward-payments')); ?>" class="btn btn-primary">
                                <i class="bi bi-chevron-left me-1"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="row g-4 mb-4">
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Company Name</label>
                                <input type="text" class="form-control"
                                    value="<?php echo e($payment->company->company_name ?? '-'); ?>" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Vendor Name</label>
                                <input type="text" class="form-control"
                                    value="<?php echo e($payment->vendor->business_name ?? '-'); ?>" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Total Amount</label>
                                <input type="text" class="form-control"
                                    value="₹<?php echo e(number_format($payment->total_amount, 2)); ?>" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Discount</label>
                                <input type="text" class="form-control"
                                    value="₹<?php echo e(number_format($payment->discount, 2)); ?>" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Paid Amount</label>
                                <input type="text" class="form-control"
                                    value="₹<?php echo e(number_format($payment->paid_amount, 2)); ?>" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Balance Amount</label>
                                <input type="text" class="form-control"
                                    value="₹<?php echo e(number_format($payment->balance_amount, 2)); ?>" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Payment Date</label>
                                <input type="text" class="form-control"
                                    value="<?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('d/m/Y')); ?>"
                                    readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Payment Mode</label>
                                <input type="text" class="form-control" value="<?php echo e(ucfirst($payment->payment_mode)); ?>"
                                    readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Reference Number</label>
                                <input type="text" class="form-control" value="<?php echo e($payment->reference_number ?? '-'); ?>"
                                    readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Remarks</label>
                                <textarea class="form-control" rows="2"
                                    readonly><?php echo e($payment->remarks ?? '-'); ?></textarea>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Payment Status</label><br>
                                <?php if($payment->payment_status == 'completed'): ?>
                                    <span class="badge bg-success px-3 py-2">Completed</span>
                                <?php elseif($payment->payment_status == 'pending'): ?>
                                    <span class="badge bg-warning text-dark px-3 py-2">Pending</span>
                                <?php else: ?>
                                    <span class="badge bg-danger px-3 py-2">Failed</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mt-4 d-flex justify-content-end gap-2">
                            <a href="<?php echo e(route('edit-outward-payment', $payment->id)); ?>"
                                class="btn btn-primary px-4">Edit Payment</a>
                            <a href="<?php echo e(route('outward-payments')); ?>" class="btn btn-outline-secondary px-4">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('super_admin.includes.footer_links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\crm\resources\views/super_admin/view_outwardpayment.blade.php ENDPATH**/ ?>